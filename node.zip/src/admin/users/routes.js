'use strict';

// const multipart = require('connect-multiparty');
// const multipartMiddleware =   multipart();


// npm modules
const express = require('express'),
    validator = require('express-joi-validator');

// router
const router = express.Router();
const requireAuthentication = require('../../../passport').authenticateAdmin;

// local modules
const controller = require('./controller'),
    routeValidators = require('./validator');



router.get('/list_users', requireAuthentication, controller.list_users);
router.post('/add_update_user',[requireAuthentication, validator(routeValidators.add_update_user)],controller.add_update_user);

router.get('/active_inactive',requireAuthentication,controller.active_inactive_users);
router.get('/verify_unverify',requireAuthentication,controller.verify_users);
router.get('/user/:id',requireAuthentication,controller.get_user)

router.delete('/delete_users',[requireAuthentication, validator(routeValidators.users_delete)], controller.delete_users);
router.get('/list_reported_users', [requireAuthentication, validator(routeValidators.list_reported_blocked_users)], controller.list_reported_blocked_users);
router.get('/list_blocked_users', [requireAuthentication, validator(routeValidators.list_reported_blocked_users)], controller.list_reported_blocked_users);
router.delete('/delete_reported_blocked_user',[requireAuthentication, validator(routeValidators.delete_reported_blocked_user)], controller.delete_reported_blocked_user);

router.get('/reported_user',requireAuthentication,controller.getReportList)
router.delete('/reported_user_delete' ,requireAuthentication, controller.delete_reported_user);

module.exports = router;

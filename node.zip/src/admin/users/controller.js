'use strict';
// momentTimezone = require('moment-timezone');
// const is = require("is_js");
const UniversalFunction = require('../../../utils/universal-functions');
const Constants = require('../../../config/appConstants');
// const paymentStatuses = require('./paymentStatuses.js')
// const schedule = require('node-schedule');
const Models = require('../../../models'),
    sendResponse = require('../../sendResponse'),
    RESPONSE_MESSAGES = require('../../../config/response-messages');

// local modules
// const Models = require('../../../models'),
//     Dao = require('../../../dao').queries,
//     controllerUtil = require('./controllerUtil'),
//     APP_CONSTANTS = require('../../../config/appConstants'),
//     RESPONSE_MESSAGES = require('../../../config/response-messages'),
//     UniversalFunctions = require('../../../utils').universalFunctions,
//     commonFunctions = require('../../../utils').commonController,
//     NotificationManager = require('../../../Lib/NotificationManager'),
//     CommonController = require('../../commonController'),
//     sendResponse = require('../../sendResponse'),
//     paymentGateway = require('../../paymentGateway');


module.exports = {

    add_update_user: async (req, res) => {
        try {

            var payload = req.body;
            console.log("payload =========== ", payload)
            const options = { "upsert": true };
            const criteriaToMatch = { "email": payload.email ? payload.email : '0' };
            // const dataToUpdate = { "name": payload.name };
            var criteria = { "name": payload.name };
            console.log("000000000000")
            if (payload._id && payload._id != "") {
                console.log("8888888888888")
                criteriaToMatch._id = { $ne: payload._id }
                criteria = { "_id": ObjectId(payload._id) };
            }
            delete payload._id;
            Models.Users.findOne(criteriaToMatch, function (err, result) {
                if (err) {
                    console.log("1111111111")
                    return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
                } else if (result && result != "") {
                    console.log("2222222222")
                    return sendResponse.sendErrorMessage(403, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.EMAIL_ALREADY_EXISTS, res);
                } else {
                    console.log("3333333333333")
                    payload.role = (payload.role) ? payload.role : "0";
                    payload.isActive = "1";
                    if (payload.hasOwnProperty('password') && payload.password) {
                        payload.password = UniversalFunction.bcryptHash(payload.password);
                    }
                    Models.Users.updateOne(criteria, payload, options, function (err, result) {
                        if (err) {
                            console.log("44444444444444", err)
                            return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
                        } else {
                            return sendResponse.sendSuccessData({}, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
                        }
                    })
                }
            })
        } catch (err) {
            console.log("err --- ", err)
            return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
        }
    },

    list_users: (req, res) => {
        try {
            var keyword = req.query.q ? req.query.q : '';
            // var criteria = {"role": req.query.role};
            var criteria = { "role": { $ne: 1 } };
            if (keyword != "") {
                criteria.name = { '$regex': ".*" + keyword + ".*", '$options': 'i' }
            }

            Models.Users.find(criteria).sort({ _id: -1 })
                // .populate('moods', '_id name image')
                .exec(function (err, result) {
                    if (err) {
                        console.log(err)
                        return sendResponse.sendErrorMessageData(400, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.DEFAULT, err, res);
                    } else {
                        return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
                    }
                });

        } catch (err) {
            console.log("err ------------ ", err)
            return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
        }
    },

    get_user: async (req, res) => {
        try {
            const result = await Models.Users.findById(req.params.id)
            return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);

        } catch (err) {
            return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
        }
    },


    active_inactive_users: async (req, res) => {
        try {


            let data = await Models.Users.findOne({ "_id": req.query.id }, { status: 1 })

            var updatestatus = '1'

            if (data.status == '1') {
                updatestatus = '0'
            }
            let update_status = await Models.Users.updateOne({ "_id": req.query.id }, { "status": updatestatus }, function (err, result) {
                console.log(err, " ******************* ", result)
                if (err) {
                    return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
                }
                else {
                    return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
                }
            })

        } catch (err) {
            return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
        }
    },

    verify_users: async (req, res) => {
        console.log('hiiiiiiiiiiiiiiiiiii');
        try {
            let data = await Models.Users.findOne({ "_id": req.query.id })
            // console.log(data,'>>>>>>>>>>>>>>>>>>>>>..data');
            var updateIsVerify = '0'
            if (data.isVerify == '0') {
                updateIsVerify = '1'
            }
            let update_status = await Models.Users.updateOne({ "_id": req.query.id }, { "isVerify": updateIsVerify }, function (err, result) {
                console.log(err, " ******************* ", result)
                if (err) {
                    return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
                }
                else {
                    return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
                }
            })

        } catch (err) {
            return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
        }
    },


    delete_users: async (req, res) => {
        try {
            //     let data = await Models.Users.findOne({ "_id": req.query.id })


            //   if (data.isDeleted = 'false') {
            //     var update = 'true'
            //   }

            //Models.Users.updateOne({ "_id": req.query.id }, { "isDeleted": update }, 
            Models.Users.deleteOne({ "_id": ObjectId(req.query.id) }, function (err, result) {
                if (err) {
                    return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
                }
                else {
                    return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
                }
            })

        } catch (err) {
            return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
        }

    },
    list_reported_blocked_users: (req, res) => {
        try {
            let criteria = { type: req.query.type }
            Models.ReportedBlockedUsers.find(criteria)
                .populate('byUser', '_id name image email')
                .populate('userId', '_id name image email')
                .exec(function (err, result) {
                    console.log(err, " ---------------------- ", result)
                    if (err) {
                        return sendResponse.sendErrorMessageData(400, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.DEFAULT, errDelete, res);
                    } else {
                        return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
                    }
                });

        } catch (err) {
            console.log("err ------------ ", err)
            return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
        }
    },


    delete_reported_blocked_user: async (req, res) => {
        try {
            Models.ReportedBlockedUsers.deleteOne({ "_id": ObjectId(req.query.id) }, function (err, result) {
                if (err) {
                    return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
                }
                else {
                    return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
                }
            })

        } catch (err) {
            return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
        }

    },

    getReportList: async (req, res) => {
        try {
            // const reports = await Models.Report.find().populate([
            //     { path: 'user_id', model: 'Users' },
            //     { path: 'report_by', model: 'Users'  }
            //   ]);

              const reports = await Models.Report.aggregate([
                {
                  $lookup: {
                    from: 'users',
                    localField: 'user_id',
                    foreignField: '_id',
                    as: 'user'
                  }
                },
                {
                  $lookup: {
                    from: 'users',
                    localField: 'report_by',
                    foreignField: '_id',
                    as: 'report_by'
                  }
                },
                {
                  $unwind: {
                    path: '$user',
                    preserveNullAndEmptyArrays: true
                  }
                },
                {
                  $unwind: {
                    path: '$report_by',
                    preserveNullAndEmptyArrays: true
                  }
                },
                {
                  $match: {
                    user: { $ne: null },
                    report_by: { $ne: null }
                  }
                }
              ]);

            // Send report data in response
            res.status(200).json({ 
                status:true,
                body:reports
             });
        } catch (err) {
            console.error(err);
            return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
        }
    },

    delete_reported_user : async (req, res) => {
        try {
          Models.Report.deleteOne({ "_id": ObjectId(req.query.id) }, function (err, result) {
            if (err) {
              return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
            }
            else {
              return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
            }
          })
    
        } catch (err) {
          return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
        }
      },

};

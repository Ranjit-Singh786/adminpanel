'use strict';

// const multipart = require('connect-multiparty');
// const multipartMiddleware =   multipart();


// npm modules
const express = require('express'),
    validator = require('express-joi-validator');

// router
const router = express.Router();
const requireAuthentication = require('../../../passport').authenticateAdmin;

// local modules
const controller = require('./controller'),
    routeValidators = require('./validator');



router.get('/list_group', requireAuthentication, controller.list_group);
router.post('/add_update_group',[requireAuthentication, validator(routeValidators.add_update_user)],controller.add_update_group);
router.get('/group/:id',requireAuthentication,controller.get_group)


router.delete('/delete_group',[requireAuthentication, validator(routeValidators.users_delete)], controller.delete_group);

router.get('/reported_group' ,requireAuthentication, controller.getReportList);


router.delete('/delete_reported_group' ,requireAuthentication, controller.delete_reported_group);


// router.get('/list_reported_users', [requireAuthentication, validator(routeValidators.list_reported_blocked_users)], controller.list_reported_blocked_users);
// router.get('/list_blocked_users', [requireAuthentication, validator(routeValidators.list_reported_blocked_users)], controller.list_reported_blocked_users);
// router.delete('/delete_reported_blocked_user',[requireAuthentication, validator(routeValidators.delete_reported_blocked_user)], controller.delete_reported_blocked_user);


module.exports = router;

let mongoose = require('mongoose');
let Schema = mongoose.Schema;

let SettingsSchema = new Schema({
    key: { type: String, index: true, default: "" },
    value: { type: String, default: "" },
}, { timestamps: true });

module.exports = mongoose.model('Settings', SettingsSchema);




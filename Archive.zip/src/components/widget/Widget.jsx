import "./widget.scss";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import SportsBarIcon from '@mui/icons-material/SportsBar';
import GroupsIcon from '@mui/icons-material/Groups';
import SportsBaseballIcon from '@mui/icons-material/SportsBaseball';
import ApiClass from "../../api/api.js";
import { useEffect, useState } from "react";
import { Link } from 'react-router-dom';

const Widget = ({ type }) => {
  const [datas, setDatas] = useState({})
  let data;
  const count_data = async () => {
    let data = await ApiClass.getNodeRequest("total_count", false);
      setDatas(data.data.body);
  }
  console.log(datas,'data is here')
  useEffect(() => {
    count_data();
  }, []);
   
  //temporary
  let amount;
  const diff = 20;
  switch (type) {
    case "user":
      amount = datas.total_users;
      data = {
        title: "USERS",
        isMoney: false,
        link: "See all users",
        route: "/users",
        icon: (
          <PersonOutlinedIcon
            className="icon"
            style={{
              color: "crimson",
              backgroundColor: "rgba(255, 0, 0, 0.2)",
            }}
          />
        ),
      };
      break;
    case "order":
      amount = datas.total_sports;
      data = {
        title: "Sports",
        isMoney: false,
        link: "View all teams",
        route: "/sports",
        icon: (
          <GroupsIcon
            className="icon"
            style={{
              backgroundColor: "rgba(218, 165, 32, 0.2)",
              color: "goldenrod",
            }}
          />
        ),
      };
      break;
    case "earning":
      amount = datas.total_teams;
      data = {
        title: "Teams",
        isMoney: false,
        link: "View all sports",
        route: "/teams",
        icon: (
          <SportsBaseballIcon
            className="icon"
            style={{ backgroundColor: "rgba(0, 128, 0, 0.2)", color: "green" }}
          />
        ),
      };
      break;
    case "balance":
      amount = datas.total_bars;
      data = {
        title: "Bars",
        isMoney: false,
        link: "See bars",
        route: "/bars",
        icon: (
          <SportsBarIcon
            className="icon"
            style={{
              backgroundColor: "rgba(128, 0, 128, 0.2)",
              color: "purple",
            }}
          />
        ),
      };
      break;
    default:
      break;
  }

  return (
    <div className="widget">
      <div className="left">
        <span className="title">{data.title}</span>
        <span className="counter">
          {data.isMoney && "$"} {amount}
        </span>
        <Link to={data.route} className="link">{data.link}</Link>
      </div>
      <div className="right">
        <div className="percentage positive">
          <KeyboardArrowUpIcon />
          {diff} %
        </div>
        {data.icon}
      </div>
    </div>
  );
};

export default Widget;

const mongoose = require("mongoose");

const groupchatSchema = new mongoose.Schema(
  {
    groupId: { type: mongoose.Schema.Types.ObjectId, ref: "Group" },
    users: [String]

  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("GroupChat", groupchatSchema);

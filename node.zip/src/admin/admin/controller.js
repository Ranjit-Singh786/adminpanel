'use strict';
const async = require('async'),
	moment = require('moment');
// momentTimezone = require('moment-timezone');
// const is = require("is_js");
const path = require('path');
const Joi = require('joi');
const UniversalFunction = require('../../../utils/universal-functions');
var jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const Constants = require('../../../config/appConstants');
// const paymentStatuses = require('./paymentStatuses.js')
// const schedule = require('node-schedule');
const Models = require('../../../models'),
	sendResponse = require('../../sendResponse'),
	RESPONSE_MESSAGES = require('../../../config/response-messages');
const { ObjectId } = require('mongoose');

// local modules
// const Models = require('../../../models'),
//     Dao = require('../../../dao').queries,
//     controllerUtil = require('./controllerUtil'),
//     APP_CONSTANTS = require('../../../config/appConstants'),
//     RESPONSE_MESSAGES = require('../../../config/response-messages'),
//     UniversalFunctions = require('../../../utils').universalFunctions,
//     commonFunctions = require('../../../utils').commonController,
//     NotificationManager = require('../../../Lib/NotificationManager'),
//     CommonController = require('../../commonController'),
//     sendResponse = require('../../sendResponse'),
//     paymentGateway = require('../../paymentGateway');


module.exports = {

	login: async (req, res) => {
		try {
			var payload = req.body;
			console.log("payload =========== ", payload)

			let data = await Models.Users.findOne({ "email": payload.email })

			if (data) {
				const match = await bcrypt.compare(payload.password, data.password)

				let userData = {
					_id: data._id,
					email: data.email
				};

				if (match) {
					let token = jwt.sign(userData, Constants.SERVER.JWT_SECRET_KEY_ADMIN, {
						expiresIn: Constants.SERVER.TOKEN_EXPIRATION
					});
					Models.Users.updateOne({ "_id": data._id }, { "accessToken": token }, function (err, result) { })
					console.log(token, "============token123")
					data.accessToken = token
					return sendResponse.sendSuccessData(data, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.LOGIN_SUCCESS, res);
				}
				else {
					console.log("555555555555555555555555555")
					return sendResponse.sendSuccessData({}, 403, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.LOGIN_ERROR, res);
				}
			}
			else {
				console.log("666666666666666666666666")
				return sendResponse.sendSuccessData({}, 403, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.LOGIN_ERROR, res);
			}


		} catch (err) {
			console.log(err)
			//return res.status(500).json({status: 0, message: err.message});
			return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
		}
	},

	edit_profile: (req, res) => {
		try {
			let payload = req.body
			payload.image = typeof payload.image === "string" ? JSON.parse(payload.image) : payload.image;

			Models.Users.updateOne({ "_id": req.admin._id }, { "name": payload.name, "profilePic": payload.image, "phone": payload.phone, "countryCode": payload.countryCode }, function (err, result) {
				if (err) {
					console.log("err --- ", err)
					return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
				} else {
					return sendResponse.sendSuccessData({}, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
				}
			});
		} catch (err) {
			console.log("err ------------ ", err)
			//return res.status(500).json({status: 0, message: err.message});
			return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
		}
	},


	change_password: async (req, res) => {
		try {
			//console.log("1452638444 ............ criteria----------------");
			let data = await Models.Users.findOne({ "_id": req.admin._id })

			const match = await bcrypt.compare(req.body.password, data.password)
			if (match) {
				const salt = bcrypt.genSaltSync(10);
				let hash = bcrypt.hashSync(req.body.new_password, salt);
				console.log(hash, "==============data")
				if (req.body.confirm_password == req.body.new_password) {
					await Models.Users.updateOne({ "_id": req.admin._id }, {
						"password": hash
					})
					return sendResponse.sendSuccessData({}, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.CHANGE_PASSWORD_SUCCESS, res);
				}
				else {
					return sendResponse.sendSuccessData({}, 400, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.INCORRECT_CONFIRM_PASSWORD, res);
				}
			}
			else {
				return sendResponse.sendSuccessData({}, 400, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.INCORRECT_OLD_PASSWORD, res);
			}
		} catch (err) {
			//return res.status(500).json({status: 0, message: err.message});
			return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
		}
	},


	admin_counters: async (req, res) => {
		try {
			const usersCount = await Models.Users.countDocuments({ role: '0' })
			const pageCount = await Models.Pages.countDocuments()
			const groupCount = await Models.Group.countDocuments()
			var counts = {
				usersCount: usersCount,
				pageCount:pageCount,
				groupCount:groupCount

			}

			console.log(counts,"$$$$$$$$$$$$$")
			return sendResponse.sendSuccessData(counts, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);            

		} catch (err) {
			console.log("err ------------ ", err)
			//return res.status(500).json({status: 0, message: err.message});
			return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
		}
	},



	getCommission: (req, res) => {
		try {
			Models.Commission.find()
				.exec(function (err, result) {
					if (err) {
						return sendResponse.sendErrorMessageData(400, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.DEFAULT, errDelete, res);
					} else {
						return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
					}
				});
			// return sendResponse.sendSuccessData({},200,req.headers.language,RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT,res);
		} catch (err) {
			return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
		}
	},

	// getCommissionByid:(req,res)=>{
	// 	try {
	//         Models.Commission.findById({_id:req.params.id})
	//         .exec(function (err, result) {
	//             if (err) {
	//                 return sendResponse.sendErrorMessageData(400,req.headers.language,RESPONSE_MESSAGES.STATUS_MSG.ERROR.DEFAULT,errDelete,res);
	//             } else {
	//                 return sendResponse.sendSuccessData(result,200,req.headers.language,RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT,res);
	//             }
	//         });            
	//         // return sendResponse.sendSuccessData({},200,req.headers.language,RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT,res);
	//     } catch (err) {
	//         return sendResponse.sendErrorMessage(500,req.headers.language,RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR,res);
	//     }
	// },



	updateCommission: async (req, res) => {
		try {
			const id = req.body.id
			const result = await Models.Commission.findByIdAndUpdate(id, { commission: req.body.commission }, { new: true })
				.exec(function (err, result) {
					if (err) {
						return sendResponse.sendErrorMessageData(400, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.DEFAULT, {}, res);
					} else {
						return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
					}
				});
			// return sendResponse.sendSuccessData({},200,req.headers.language,RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT,res);
		} catch (err) {
			return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
		}
	},


	active_inactive_commission: async (req, res) => {
		try {
			let data = await Models.Commission.findOne({ "_id": req.query.id }, { status: 1 })
			var updatestatus = '1'
			if (data.status == '1') {
				updatestatus = '0'
			}
			let update_status = await Models.Commission.updateOne({ "_id": req.query.id }, { "status": updatestatus }, function (err, result) {
				console.log(err, " ******************* ", result)
				if (err) {
					return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
				}
				else {
					return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
				}
			})

		} catch (err) {
			return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
		}
	},
};

import AdminModel from "../App/Models/Admin.js";
import helper from "../Common/helper.js";
import jwt from "jsonwebtoken";

export default {
  async authenticateToken(req, res, next) {
    console.log(req.headers, 'headers is here');
    const authHeader = req.headers['authorization'];

    const token = authHeader && authHeader.split(' ')[1];

    if (token == null) {
      return helper.failed(res, 'Token required', {}, 401);
    }

    try {
      // console.log('Verifying token:', process.env.JWT_SECRET);
      const user = jwt.verify(token, process.env.JWT_SECRET);
      console.log('Decoded user:', user);

      const data = await AdminModel.findOne({
        _id: user.id,
        userRole: 0, // Only allow users with userRole = 0
      });

      if (!data) {
        return helper.failed(
          res,
          "The user belonging to this token does no longer exist",
          {},
          401
        );
      }

      req.user = data;
      next();
    } catch (error) {
      console.error('Token verification error:', error);
      return helper.failed(res, 'Invalid token', {}, 403);
    }
  }
};

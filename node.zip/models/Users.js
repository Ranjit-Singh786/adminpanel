let mongoose = require('mongoose');
const Decimal = require('decimal.js');
// let async = require('async'),
// randomstring = require("randomstring"),
// user_plugin = require("../plugins").userPlugin;         // import mongo plugin for pre save hook

let Schema = mongoose.Schema;

let Userschema = new Schema(
  {
    userName: { type: String, index: true, default: "" },
    firstName: { type: String },
    lastName: { type: String },
    phone: { type: String, default: "", index: true },
    email: { type: String, index: true, default: "" },
    password: { type: String, default: "" },
    countryCode: { type: String, default: "" },
    deviceType: { type: String, enum: ["IOS", "ANDROID"], default: "IOS" },
    deviceToken: { type: String, default: "" },
    accessToken: { type: String, trim: true, default: "" },
    socialType: {
      type: Number,//enum 0=facebook,1.google ,2.apple
    },
    socialId: {
      type: String,
    },
    location: {
      type: { type: String },
      coordinates: [],
      //index: "2dsphere",
      //sparse: true,
    }, //[long, lat]
    address: { type: String, default: "" },
    failOtp: { type: Number },
    type: { 
      type: Number,
      get: obfuscate,
    },
    otp: { type: Number },
    is_verify: { type: Number, default: 0 },
    otptime: { type: String },
    role: { type: String, enum: ["0", "1"], default: "0" }, // 1 - admin, 0 - user
    image: {
      original: { type: String, default: "" },
      thumbnail: { type: String, default: "" },
    },
    isOnline: { type: String },
    socketId: { type: String },
    userLastSeen: { type : Date},
    status: { type: Number, enum: [0, 1], default: 1 },
  },
  { timestamps: true },
  { toJSON: { getters: true } }
);
//0-off  , 1-on

function obfuscate(type) {
    console.log(type);
    let conversion =  new Decimal(type).toNumber();;
    return conversion;
  }

Userschema.pre('remove',{ query: true, document: true }, async function (){
	console.log('filter',this.getFilter()._id);

	// REMOVE USER VIDEOS
       let success = await Video.remove({user: this.getFilter()._id}).exec();
	   console.log('POST REMOVED',success);

	//    REMOVE USER TAGS & REPORTS

	let deletedNotifications = await Notifications.remove({user: this.getFilter()._id}).exec();

	  let s =  await Video.updateMany(
		   {},
		   {
			   $pull: { tagged_users: this.getFilter()._id, reported_by: { user: this.getFilter()._id } }	
		   },
		   {multi: true}
	   )

	   console.log(s);

})
// Userschema.plugin(user_plugin, {tempCode: randomstring.generate(5)});

const user = mongoose.model('Users', Userschema);
user.syncIndexes({alter:true});
module.exports = user;

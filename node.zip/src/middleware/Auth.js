let JWT=require('jsonwebtoken');
const Model = require("../../models");


const secretcryptokey = "huffduff_secretcryptokey";
let {Validator}=require('node-input-validator');
const { failed } = require('../../config/helper');


 async function authenticateToken(req, res, next) {

    const authHeader = req.headers['authorization']


    const token = authHeader && authHeader.split(' ')[1]
   

    if (token == null) {
        return failed(res,'token required')}

      

      let user= JWT.verify(token,"csfAuthSecret");

      

     let data= await Model.Users.findOne({
            _id:user.id
     })
     
        req.user = data

        next()
    
}

module.exports = {
    authenticateToken,
    header_keys:async(req,res,next)=>{
        try {

            const v = new Validator(req.headers, {
                secret_key: 'required',
                publish_key: 'required'
              });

            
              v.check().then((matched) => {
                if (!matched) {
                 return res.status(422).send(v.errors);
                }else{
    
                    var sk = CryptoJS.AES.decrypt(req.headers.secret_key, secretcryptokey);
                    sk = sk.toString(CryptoJS.enc.Utf8);
                    var pk = CryptoJS.AES.decrypt(req.headers.publish_key, secretcryptokey);
                    pk = pk.toString(CryptoJS.enc.Utf8);

if(global.secret_key!=sk){
    return failed(res,"Secret key Not Matched")
}
else if(global.publish_key!=pk){
    return failed(res,"Publish key Not Matched")
}

   next()

                }
              });
        } catch (error) {
          console.log(error)  
          return helper.failed(res,'error',error)
        }
      
    
    }
    
}



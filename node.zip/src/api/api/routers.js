const apiController = require('./apiController')

const router = require('express').Router()

const Auth=require('../../middleware/Auth').authenticateToken



router.post('/signup',apiController.signup)
router.post('/login',apiController.login)
router.post('/change_password',Auth,apiController.change_password)
router.post('/logout',Auth,apiController.logout)
router.post('/forgetpassword',apiController.forgetpassword)
router.post('/verify_otp',apiController.verify_otp)
router.post('/social_login',apiController.sociallogin)
router.post('/verify_otp_number',apiController.verify_otp_number)
router.post('/resend_otp',apiController.resend_otp)
router.post('/resend_otp_number',apiController.resend_otp_number)
router.post('/newpassword',apiController.NewPassword)
router.post('/profileUpdated', Auth, apiController.profileUpdated)
router.post('/notificationStatus',Auth,apiController.notificationStatus)
router.post("/accept_group_invite", Auth, apiController.acceptgroupinvite);
router.post("/change_tracking_status", Auth, apiController.tracking_status);
router.get("/get_tracking", Auth, apiController.get_tracking_with_status);
router.post("/change_sos_status", Auth, apiController.sos_status);
router.put("/group_update", Auth, apiController.group_update);
router.get("/get_notification_list", Auth, apiController.getNotificationList);
router.get('/pages/:page',apiController.getPages)
router.get('/allpages',apiController.getAllPages)
router.post('/create_pages',apiController.createPage)
router.post('/group_create',Auth, apiController.group_create)
router.get('/get_group', Auth, apiController.getGroup)
router.get('/get_tracking_history', Auth, apiController.group_tracking_history);
router.get('/group_chat_history', Auth, apiController.group_chat_history);
router.get('/get_messages_type_location', Auth, apiController.get_all_messages_loaction);
router.post("/upload_file", Auth, apiController.uploadFile);
router.post('/remove-user', Auth, apiController.removeUser)
router.post('/leave-group', Auth, apiController.leaveGroup)
router.post('/report-user', Auth, apiController.ReportUser)
router.post("/report-group", Auth, apiController.ReportGroup);
router.post('/delete-group', Auth, apiController.deleteGroup);
router.get("/get_chat/:group_chat_id", Auth, apiController.getChatById);
router.get('/getdetail',apiController.getdetail);
router.get('/online_user_in_group',Auth,apiController.online_user_in_group)


//invitation api
router.get('/invitation',apiController.verify_invitation);







module.exports = router
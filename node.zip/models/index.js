

module.exports = {
  Users: require("./Users"),
  Pages: require("./Pages"),
  Group: require("./Group"),
  Report: require("./Report"),
  Message: require("./Message"),
  Location: require("./LocationTrack"),
  Socket_User: require("./Socket_User"),
  GroupChat: require("./GroupChat"),
  Notification: require("./Notification"),
  ReportGroup: require("./ReportGroup"),
};


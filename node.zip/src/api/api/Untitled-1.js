// group_tracking_history:async(req,res)=>{
//   // console.log(req,'chcek')
//   const messages = await Model.Message.aggregate([
//     {
//       $match: { type: "location" }
//     },
//     {
//       $lookup: {
//         from: "groups",
//         localField: "group_chat_id",
//         foreignField: "group_chat_id",
//         as: "group"
//       }
//     },
//     {
//       $unwind: "$group"
//     },
//     {
//       $unwind: "$group.members"
//     },
    
//     {
//       $lookup: {
//         from: "users",
//         localField: "group.members.user_id",
//         foreignField: "_id",
//         as: "group.members.user"
//       }
//     },
//     {
//       $project: {
//         "group.members.user.password": 0,
//         "group.members.user.createdAt": 0,
//         "group.members.user.updatedAt": 0,
//         "group.members.user.__v": 0,
//         "group.members.user.socketId": 0
//       }
//     },
//     {
//       $unwind: "$group.members.user"
//     },
//     {
//       $project: { 
//         type: 1,
//         sender: 1,
//         group: {
//           _id: "$group._id",
//           image: "$group.image",
//           destination_location: "$group.destination_location",
//           group_name: "$group.group_name",
//           members: "$group.members",
//           destination_address: "$group.destination_address",
//           group_chat_id: "$group.group_chat_id"
//         }
//       }
//     }
//   ]).project({ "location": 0, "message": 0, "_id": 0, "group_chat_id": 0 });

//   // const groups = [];
// //only that groups data which all type at message saved in location
//   // for (let i = 0; i < messages.length; i++) {
//   //   const group = messages[i].group;
//   //   groups.push(group);
//   // }
// return sendResponse.sendSuccessData(
//   messages ,
//   APP_CONSTANTS.STATUSCODE.SUCCESS,
//   req.headers.language,
//   RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
//   res
// );
// },






///second way to get data


// group_tracking_history:async(req,res)=>{
//   // console.log(req,'chcek')
//   const messages = await Model.Message.aggregate([
//     {
//       $match: { type: "location" }
//     },
//     {
//       $lookup: {
//         from: "groups",
//         localField: "group_chat_id",
//         foreignField: "group_chat_id",
//         as: "group"
//       }
//     },
//     {
//       $unwind: "$group"
//     },
//     {
//       $lookup: {
//         from: "users",
//         localField: "group.members.user_id",
//         foreignField: "_id",
//         as: "group.members.user"
//       }
//     },
//     {
//       $group: {
//         _id: "$group_chat_id",
//         "members": { "$push": "$group.members" },
//         "data": { "$first": "$$ROOT" }
//       }
//     },
//     {
//       $replaceRoot: {
//         newRoot: {
//           $mergeObjects: ["$data", { group: { members: "$members" } }]
//         }
//       }
//     },
//     {
//       $project: {
//         "group.members.user.password": 0,
//         "group.members.user.createdAt": 0,
//         "group.members.user.updatedAt": 0,
//         "group.members.user.__v": 0,
//         "group.members.user.socketId": 0,
//         "group_chat_id": 0,
//         "members": 0
//       }
//     },
//     {
//       $project: { 
//         type: 1,
//         sender: 1,
//         group: {
//           _id: "$group._id",
//           image: "$group.image",
//           destination_location: "$group.destination_location",
//           group_name: "$group.group_name",
//           members: "$group.members",
//           destination_address: "$group.destination_address",
//           group_chat_id: "$group.group_chat_id"
//         }
//       }
//     }
//   ]);
  

  // const groups = [];
//only that groups data which all type at message saved in location
  // for (let i = 0; i < messages.length; i++) {
  //   const group = messages[i].group;
  //   groups.push(group);
  // }


// return sendResponse.sendSuccessData(
//   messages ,
//   APP_CONSTANTS.STATUSCODE.SUCCESS,
//   req.headers.language,
//   RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
//   res
// );
// },



// relation with
// let checkit = await  Model.Users.aggregate([
//   {
//     $match: { _id: ObjectId(data.userid) } // Match the desired user by their user_id
//   },
//   {
//     $lookup: {
//       from: "locations", // Name of the "locations" collection
//       localField: "user_id", // Field in the "users" collection to match
//       foreignField: "id", // Field in the "locations" collection to match
//       as: "location" // Output field containing the matched location(s)
//     }
//   }
// ]);


// if (trackingStatus.modifiedCount > 0) {
//   const isOnline = parseInt(req.body.status) === 1 ? 1 : 0;
//   const userUpdateResult = await Model.Users.updateOne(
//     { _id: req.body.user_id },
//     { $set: { isOnline } }
//   );

//   console.log('User update result:', userUpdateResult);
// } else {
//   console.log('Group update failed. Group not found or user not a member.');
// }




///new code with created at

// const cron = require("node-cron");
// const Model = require("./models/Model");

// Function to create a group message for a user
// const createGroupMessage = async (user) => {
//   // Your code to create a group message for the user
//   // ...
//   console.log(`Creating group message for user: ${user.userName}`);
// };

// Schedule the cron job to run every minute
// cron.schedule("* * * * *", async () => {
//   try {
//     const group = await Model.Group.aggregate([
//       { $unwind: "$members" },
//       { $match: { "members.sos_status": 1 } },
//       {
//         $lookup: {
//           from: "users",
//           localField: "members.user_id",
//           foreignField: "_id",
//           as: "member_details",
//         },
//       },
//       {
//         $group: {
//           _id: "$_id",
//           group_name: { $first: "$group_name" },
//           members: { $push: { $mergeObjects: ["$members", { $arrayElemAt: ["$member_details", 0] }] } },
//           image: { $first: "$image" },
//           group_chat_id: { $first: "$group_chat_id" },
//           destination_address: { $first: "$destination_address" },
//           destination_location: { $first: "$destination_location" },
//         },
//       },
//     ]);

//     if (group.length === 0) return;

//     for (const groupItem of group) {
//       const members = groupItem.members;

//       for (const member of members) {
//         const latitude = parseFloat(member?.destination_location?.coordinates[0]);
//         const longitude = parseFloat(member?.destination_location?.coordinates[1]);

//         if (isNaN(latitude) || isNaN(longitude)) {
//           console.log("Invalid coordinates");
//           continue;
//         }

//         const updateAt = member.updatedAt.getTime(); // Convert created_at to milliseconds

//         const delay = updateAt + 15 * 60 * 1000 - Date.now(); // Calculate the remaining delay

//         if (delay > 0) {
//           setTimeout(async () => {
//             const data = {
//               group_chat_id: groupItem.group_chat_id,
//               message: "SOS message! Need help.",
//               sender: {
//                 userid: member.user_id,
//                 name: member.userName,
//                 sender_image: member.image?.original,
//               },
//               location: {
//                 type: "point",
//                 coordinates: [latitude, longitude],
//               },
//               type: "sos",
//               destination_address: groupItem.destination_address,
//             };

//             await Model.Message.create(data);
//             console.log(`Created group message for user: ${member.userName}`);

//             // Emit the SOS message event
//             io.emit("sos_listener", data);
//           }, delay);
//         }
//       }
//     }
//   } catch (error) {
//     console.error("Error in cron job:", error);
//   }
// });

// Start the cron job
// cron.start();









//ejs backup datA is here 

// const session = require('express-session');
// const { v4: uuidv4 } = require('uuid');
// const secrekeyforsession = uuidv4();
// var flash = require('express-flash');

// app.set('view engine', 'ejs');
// app.use(flash());

// app.use(session({
//     secret: secrekeyforsession,
//     resave: false,
//     saveUninitialized: false
//   }));


// register user
// register_invitation_user:async(req,res)=>{
//   console.log(req,'req is here')
//       try{
//         console.log(req,'req is here')
//       const userExist = await Model.Users.findOne({
//         email: req.body.email,
//       });
//       if (userExist) {
//         return failed(res, "Email Already Exist");
//       }

//       const phone_find = await Model.Users.findOne({
//         phone: req.body.phone,
//       });
//       if (phone_find) {
//         return failed(res, "Phone Number Already Exist");
//       }
//       const hashPassword = await bcrypt.hash(req.body.password, 12);
//       req.body.password = hashPassword;

//       req.body.image = await helpers.image_upload(req.files && req.files.image);

//       let data = {
//         firstName: req.body.firstName,
//         lastName: req.body.lastName,
//         userName: req.body.userName,
//         countryCode: req.body.countryCode,
//         email: req.body.email,
//         password: req.body.password,
//         confirmPassword: req.body.confirmPassword,
//         phone: req.body.phone,
//         // type: req.body.type,

//         // otp: otp,
//         image: {
//           thumbnail: "",
//           original: req.body.image,
//         },
//         location: {
//           type: "Point",
//           coordinates: [],
//         },
//       };
//       let user = {};
//     // console.log(req.body.type,'chekit')
//     user = await Model.Users.create(data);
//     let member = [
//       {
//         user_id: user._id,
//         tracking: 0,
//         sos_status: 0,
//         onlineStatus: 0,
//         destination_location: {
//           type: "Point",
//           coordinates: [
//             parseFloat(0),
//             parseFloat(0),
//           ],
//         },
//         current_location: {
//           type: "Point",
//           coordinates: [
//             parseFloat(0),
//             parseFloat(0),
//           ],
//         },
//         is_admin:false,
//         status:0
//       }
//     ];

//     let updatedgroup = await Model.Group.findOneAndUpdate(
//       {  invitation_token: req.body.token },
//       {
//         $push: {
//           members: {
//             $each: member,
//           },
//         },
//       },
//       { new: true }
//     )
//     if(!updatedgroup){
//       return error(res,'Unable added in group');
//     }

//     if(user.modifiedCount!==0 && updatedgroup.modifiedCount!==0){
//       return success(res, "You are requested to install the Huffduff app from the Play Store to participate in group activities. Once you have installed the app, you will be able to engage in group activities and enjoy the features it offers.");
//     }


//   }catch(err){
//       return error(res,err);
//   }
    
    
// }

// verify_invitation:async (req,res)=>{

// const { token } = req.query;
// const invitation = await Model.Group.findOne({ invitation_token:token }); 
// if (!invitation || invitation.invitation_token_expire < Date.now()) {
//   return error(res,'Invalid or expired invitation');
// }
// if (!invitation) {
//   return error(res,'Invalid or expired invitation');
// }
// res.render('registration', { token});
// // success(res,"Link verified successfully")

// },

// route is here

// router.post('/register_invitation_user',apiController.register_invitation_user);









// const messages = await Model.Message.aggregate([
        //   {
        //     $match: { type: "location" ,"sender.userid":ObjectId(user_id)}
        //   },
        //   {
        //     $group: {
        //       _id: {
        //         user_id: "$user_id",
        //         group_chat_id: "$group_chat_id"
        //       },
        //       message: { $first: "$$ROOT" }
        //     }
        //   },
        //   {
        //     $lookup: {
        //       from: "groups",
        //       localField: "message.group_chat_id",
        //       foreignField: "group_chat_id",
        //       as: "group"
        //     }
        //   },
        //   {
        //     $unwind: "$group"
        //   },
        //   {
        //     $unwind: "$group.members"
        //   },
        //   {
        //     $lookup: {
        //       from: "users",
        //       localField: "group.members.user_id",
        //       foreignField: "_id",
        //       as: "group.members.user"
        //     }
        //   },
        //   {
        //     $project: {
        //       "group.members.user.password": 0,
        //       "group.members.user.createdAt": 0,
        //       "group.members.user.updatedAt": 0,
        //       "group.members.user.__v": 0,
        //       "group.members.user.socketId": 0
        //     }
        //   },
        //   {
        //     $unwind: "$group.members.user"
        //   },
        //   {
        //     $group: {
        //       _id: "$group.group_chat_id",
        //       group: { $first: "$group" },
        //       members_array: { $push: "$group.members" }
        //     }
        //   },
        //   {
        //     $project:  {
        //       group_chat_id: "$_id",
        //       group: {
        //         _id: 1,
        //         image: 1,
        //         destination_location: 1,
        //         group_name: 1,
        //         destination_address: 1,
        //         members_array: "$members_array"
        //       }
            
        //     }
        //   }
        // ]);


        // const groups = [];
     //only that groups data which all type at message saved in location
        // for (let i = 0; i < messages.length; i++) {
        //   const group = messages[i].group;
        //   groups.push(group);
        // }







        //25 may
        // const groups = await Model.Group.aggregate([
        //   {
        //     $match: {
        //       tracking_status: true,
        //       "members.user_id": mongoose.Types.ObjectId(req.user._id)
        //     }
        //   },
        //   {
        //     $addFields: {
        //       members_array: {
        //         $map: {
        //           input: {
        //             $filter: {
        //               input: "$members",
        //               as: "member",
        //               cond: { $eq: ["$$member.user_id", mongoose.Types.ObjectId(req.user._id)] }
        //             }
        //           },
        //           as: "member",
        //           in: {
        //             $mergeObjects: [
        //               "$$member",
        //               {
        //                 user: {
        //                   $arrayElemAt: [
        //                     {
        //                       $filter: {
        //                         input: "$members",
        //                         as: "m",
        //                         cond: { $eq: ["$$m.user_id", mongoose.Types.ObjectId(req.user._id)] }
        //                       }
        //                     },
        //                     0
        //                   ]
        //                 }
        //               }
        //             ]
        //           }
        //         }
        //       }
        //     }
        //   },
        //   {
        //     $project: {
        //       members: 0
        //     }
        //   }
        // ]);


        //25 may leave group api
        // leaveGroup: async (req, res) => {
        //   let request = req.body;
        //   let group_id = request.group_id;
        //   let user_id = req.user.id;
      
        //   const v = new Validator(request, {
        //     group_id: "required",
        //   });
      
        //   const errorResponse = await checkValidation(v);
        //   if (errorResponse) {
        //     return failed(res, errorResponse);
        //   }
      
        //   let idPresent = await Model.Group.findOne({
        //     _id: group_id,
        //     members: {
        //       $elemMatch: { user_id: user_id },
        //     },
        //   });
      
        //   //Check if whether admin is being deleted
      
        //   let adminobj = idPresent?.members.find((o) => o.user_id == user_id);
          
        //   //get random user with is_admin false
      
        //   let isadminfalse = idPresent?.members.find((o) => o.is_admin == false);
        //   // console.log(idPresent.members,'checkit')
        //   const membersWithStatusOne = idPresent.members?.filter(member => member.status==1);
        //   // return;
        //   const group = await Model.Group.findById(group_id);
        //   console.log(group.members.length,'chedksfsdhf')
        //   if(group.members.length === 1){
        //      await Model.Group.updateOne(
        //       { _id: group_id },
        //       {
        //         $pull: {
        //           members: { user_id: user_id },
        //         },
        //       }
        //     );
        //    return sendResponse.sendSuccessData(
        //       group,
        //       APP_CONSTANTS.STATUSCODE.SUCCESS,
        //       req.headers.language,
        //       RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
        //       res
        //     ); 
        //   }
        //   if (membersWithStatusOne.length < 2) return  failed(res, "You can't leave the group. At least two members must be added. ");
        //   if (isadminfalse && adminobj) {
        //     console.log(isadminfalse,">>>>>>>>>>>>>>");
        //     const result = await Model.Group.updateOne(
        //       {
        //         _id: group_id,
        //         members: {
        //           $elemMatch: { status: 1, is_admin: false },
        //         },
        //       },
        //       {
        //         $set: { "members.$.is_admin": true },
        //       }
        //     );
            
        //     if (result.acknowledged && result.modifiedCount > 0) {
        //       console.log("Admin updated successfully.");
        //     } else {
        //       console.log("Failed to update admin.");
        //     }
            
        //     // console.log(isadmin.modifiedCount,'count is here')
        //   }
      
        //   if (!idPresent) {
        //     return sendResponse.sendErrorMessage(
        //       400,
        //       req.headers.language,
        //       RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
        //       res
        //     );
        //   }
      
        //   await Model.Group.updateOne(
        //     { _id: group_id },
        //     {
        //       $pull: {
        //         members: { user_id: user_id },
        //       },
        //     }
        //   );
      
        //   let groups = await Model.Group.findById(group_id);
      
        //   if (!groups) {
        //     return sendResponse.sendErrorMessage(
        //       400,
        //       req.headers.language,
        //       RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
        //       res
        //     );
        //   }
      
        //   return sendResponse.sendSuccessData(
        //     groups,
        //     APP_CONSTANTS.STATUSCODE.SUCCESS,
        //     req.headers.language,
        //     RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
        //     res
        //   );
        // },




        //socket.js

//         const Model = require("../../../models");
// const {
//   sendNotification
// } = require("../../../config/helper");
// var cron = require('node-cron');
// const mongoose = require('mongoose');
// var _ = require('lodash');
// const socketResponse = require('../../../config/socketResponse');
// const nodeCron = require("node-cron");
// module.exports = function (io) {
// const job = nodeCron.schedule("*/15 * * * *", async() => { 
//   let timeouts = [];
    
//   const group = await Model.Group.aggregate([
// { $unwind: "$members" },
// { $match: { "members.sos_status": 1 } }, 
// {
//   $lookup: {
//     from: "users",
//     localField: "members.user_id",
//     foreignField: "_id",
//     as: "member_details",
//   },
// },
// {
//   $group: {
//     _id: "$_id",
//     group_name: { $first: "$group_name" },
//     members: { $push: { $mergeObjects: ["$members", { $arrayElemAt: ["$member_details", 0] }] } },
//     image: { $first: "$image" },
//     group_chat_id: { $first: "$group_chat_id" },
//     destination_address: { $first: "$destination_address" },
//     destination_location: { $first: "$destination_location" },
//   },
// },
// ]);

// if(group.length===0) return;
// for(let i in group){
// const members = group[i].members;
// for(let j in members){
//   console.log("dskfhjksdhfjkhs")
//   console.log(group[i].destination_location.coordinates[0])
//   let latitude = parseFloat(members[j]?.destination_location?.coordinates[0]);
//   let longitude = parseFloat(members[j]?.destination_location?.coordinates[1]);
//   console.log(members[j],members[j]?.updated_at,"tu kithe jana ithe hi aana")
//   if(isNaN(latitude) || isNaN(longitude)){
//     console.log('Invalid coordinates');
//     continue; 
//   }
//   const updateAt = members[j]?.updated_at.getTime(); // Convert created_at to milliseconds
//    console.log(members[j],'updateAt')
//   const delay = updateAt + 15 * 60 * 1000 - Date.now(); // Calculate the remaining delay
//   console.log(delay,'delay')

//   clearTimeout(timeouts[j]); // Clear the previous timeout
//   if (delay > 0) {
//     // console.log("check condition")
//     timeouts[j] = setTimeout(async () => {
//               let data ={
//                 group_chat_id: group[i].group_chat_id,
//                 message: "SOS message !Need a help.",
//                 sender: {
//                   userid: members[j].user_id,
//                   name: members[j].userName,
//                   sender_image: members[j].image?.original,
//                 },
//                 location:  { 
//                   type: "point",
//                   coordinates: [latitude,longitude],
//                 },
//                 type: "sos",
//                 destination_address:group[i].destination_address

//             }
//          console.log(data,'checkit')
//     // console.log(data.location,group[i].group_chat_id,'sdjflsdhflkdhsfjkgdskjfgdjksgfjhgsdfhjgdhjsfg')
//     await Model.Message.create(data);
//     io.emit("sos_listener",data);
//     // Update member's updated_at field
//    let updateval =  await Model.Group.updateOne(
//       {
//         _id: group[i]._id,
//         "members.user_id": members[j].user_id
//       },
//       {
//         $set: {
//           "members.$.updated_at": new Date() // Set updated_at to current date/time
//         }
//       }
//     );
//     console.log(updateval.modifiedCount)
//   }, delay);
// }
//     // console.log(datacheck,'yes i am working')
  
// }
// }
// });

//     io.on("connection", async (socket) => {
//       // console.log(socket.handshake.secure,'checkit')
//       socket.on("connect-user", async (data) => {
//         console.log("user connected hai tension nal lo")
//         await Model.Users.updateOne(
//           { _id: data.userid },
//           {
//             $set: {
//               socketId: socket.id,
//               // isOnline: 1,
//             },
//           }
//         );
//         io.emit("connect-user", data);
        
//       });
//       socket.on("group-message", async (data) => {
//          let finduser = await Model.Users.findOne({_id:data.sender.userid});
//          if(!finduser) return socketResponse.error("user not found",socket,"group-message");
//         if (data.type == "image" || data.type == "location" || data.type=="sos") {
//           await Model.Message.create(data);
//           io.emit("group-message", data);         
//            let user_id = data.sender.userid;
//           // console.log(user_id, 'checkit');
//            //send notification
//           let group = await Model.Group.findOne({ group_chat_id: mongoose.Types.ObjectId(data.group_chat_id) }).populate('members.user_id');
//           console.log(group,'group is herer')
//           // return;
//           let onlyforReciever = [];
//           let notificationmsg = data.type === 'sos'
//                     ? `User ${data.sender.name} Start Sos for group ${group?.group_name}`
//                     : data.type === 'location'
//                       ? `User ${data.sender.name} sent location for group ${group?.group_name}`
//                       : data.type === 'image'
//                         ? `User ${data.sender.name} sent an image for group ${group?.group_name}`
//                         : '';
//           //  console.log(notificationmsg)
//            group?.members.map((member) => {
//             if (member.user_id && member.user_id._id && member.user_id._id.toString() !== user_id.toString() && member.status ==1) {
//               // console.log(member.user_id.deviceToken, 'checkmember');
//               let o = {};
//               o.receiver_id = member.user_id._id;
//               o.group_id = group._id;
//               o.notification = notificationmsg;
//               onlyforReciever.push(o);
          
//               io.to(member.user_id._id).emit("Notification_sent", o);
//               sendNotification(member.user_id.deviceToken, notificationmsg);
//             }
//           });

//           // console.log(onlyforReciever, 'chekit');
//           //notifications sends only that user who's not sender type image or location
//           await Model.Notification.insertMany(onlyforReciever);
//         } else {
//           // console.log("hey here am i")
//           await Model.Message.create(data);
//           io.emit("group-message", data);
          

//         }

//       });
//       socket.on("location-track", async (data) => {
//         try {
//             console.log(data,'data ishere')
//           // Check if a location entry already exists for the same user_id
//           const existingLocation = await Model.Location.findOne({ user_id: data?.user_id });

//           if (existingLocation) {
//             // If an existing location entry is found, delete it
//             let check = await Model.Location.findByIdAndDelete(existingLocation._id);
//             console.log(check, "deleted data")
//           }
//           // Create a new location entry with the received data
//           let locationData = await Model.Location.create(data);
//           let newobj = {}
//           newobj.longitude = locationData.location.coordinates[0].toString();
//           newobj.latitude = locationData.location.coordinates[1].toString();
//           newobj._id = locationData._id;
//           newobj.user_id = locationData.user_id;
//           newobj.group_id = locationData.group_id;

//           let group_modal = await Model.Group.findById(newobj.group_id);
//           if (!group_modal) {
//             // Handle the case where the group is not found
//             return socketResponse.error("group not found",socket,"location-track");
//           } 
//           const members = group_modal.members;
//           // console.log(members,newobj.user_id,'user_id checkit here')
//           const member = members.find((m) =>m.user_id.toString() === newobj.user_id.toString());
//           // console.log(member,'checkit')
//           if (!member) {
//             // Handle the case where the member is not found
//             return socketResponse.error("Member not found",socket,"location-track");
//           }
//           member.current_location = {
//             type: "point",
//             coordinates: [parseFloat(newobj.longitude),parseFloat(newobj.latitude)],
//           },
//           member.destination_location = {
//             type: "point",
//             coordinates: [parseFloat(newobj.longitude),parseFloat(newobj.latitude)],
//           },

//           // console.log(member.current_location,'checkit')
//           await group_modal.save();
//           socketResponse.success(socket, "location-track", "lacation fetched successfully", newobj)

//         } catch (error) {
//           console.error(error);
//           io.emit("location-track", { error: "Failed to save location" });
//         }
//       });

//       //get location where user go and changed the location
//       socket.on("get_location_track", async (data) => {
//         try {
//           let userid = data.userid;
//           let groupid = data.group_id;
//           var fetchdata = await Model.Location.find({ user_id: userid, group_id: groupid });
//         } catch (err) {
//           console.log(err, 'error is here')
//         }

//         io.emit("get_location_track", fetchdata);
//       })

//       socket.on("offline", async () => {
//         /* … */
//         console.log(new Date().toISOString());
//         await Model.Users.updateOne(
//           { socketId: socket.id },
//           {
//             $set: {
//               userLastSeen: new Date().toISOString(),
//               isOnline: 0,
//             },
//           }
//         );

//         io.emit("offline");
//       });

//       socket.on("get-group-chat", async (data) => {
//         let groupchat = await Model.Message.find({
//           group_chat_id: data.group_chat_id,
//         });

//         io.emit("get-group-chat", groupchat);
//       });
//       socket.on("stop_sos", async (data) => {
//         // Define the keys to validate
//         let keysToValidate = ['userid', 'latitude', 'longitude','group_id'];
//         const validatedData = {};
//         // All keys exist
//         keysToValidate.forEach(key => {
//           if (_.has(data, key)) {
//             validatedData[key] = data[key];
//           } else {

//             io.emit("stop_sos", { error: `Key '${key}' does not exist.` });
//           }
//         });
//         if (Object.keys(validatedData).length === keysToValidate.length) {
//           // All keys exist
//           console.log('All keys exist:', validatedData);
//           try {
//             let trackingStatus = await Model.Group.updateOne(
//               // $elemMatch finds docs containing an array with a matching element
//               {
//                 _id: validatedData.group_id,
//                 members: {
//                   $elemMatch: { user_id: validatedData.userid },
//                 },
//               },
//               // Positional operator $ is a placeholder for the first matching array element
//               {
//                 $set: { "members.$.sos_status": parseInt(0) },
//               }
//             );
//             let updateUserloc;
//             if (trackingStatus.modifiedCount !== 0) {
//               updateUserloc = await Model.Users.updateOne({ _id: validatedData.userid },
//                 {
//                   $set: {
//                     location: {
//                       type: "Point",
//                       coordinates: [
//                         parseFloat(validatedData.longitude),
//                         parseFloat(validatedData.latitude),
//                       ],
//                     },
//                   }
//                 })
//             }
//             // console.log(updateUserloc, 'user updated long,lat')
//             let groupallMember = await Model.Group.findById(validatedData.group_id).populate("members.user_id");
//             let user =  await Model.Users.findById(validatedData.userid)

//       // console.log(groupallMember,'checkit')
//       let notificationmsg2 = `${user?.userName} has stopped SOS ${groupallMember?.group_name} group`;
//       let newaddedmemberarr =[];
//       groupallMember.members.map((id) => {
//         if(id.user_id && id.user_id._id.toString() !== user._id.toString()){
//           let o = {};
//           o.receiver_id = id.user_id._id;
//           o.group_id = groupallMember._id;
//           o.type = 4;
//           o.notification = notificationmsg2;
//           newaddedmemberarr.push(o);
//           sendNotification(id.user_id.deviceToken,notificationmsg2)
//         }
//         });
        
//         await Model.Notification.insertMany(newaddedmemberarr);
//             let group = await Model.Group.findById(validatedData.group_id, {
//               members: 0,
//             });
//             io.emit("stop_sos", data);

//           } catch (err) {
//             console.error(err);
//           }


//         } else {
//           // Some keys are missing
//           console.error('Some keys are missing.');
//         }


//       });

//       socket.on("location-change", async (data) => {
//         //console.log("this is message", data);
//         await Model.Users.updateOne(
//           { _id: data.user_id },
//           {
//             location: [data.longitude, data.latitude],
//           }
//         );
//         sendNotification(data.token, "location changed for user");
//         io.to(data.group_id).emit("location-change", data);
//       });

//       socket.on("disconnect", function () {
//         console.log("user disconneced")
//       })

//       // We can write our socket event listeners in here...
//     });

// }


//accept group invite api here

// acceptgroupinvite: async (req, res) => {
//   try {
//     const v = new Validator(req.body, {
//       group_id: "required",
//       user_id: "required",
//       type: "required",
//     });

//     const errorResponse = await checkValidation(v);
//     if (errorResponse) {
//       return failed(res, errorResponse);
//     }
   
//     if (req.body.type == 1) {
//       let groupInvite = await Model.Group.updateOne(
//         // $elemMatch finds docs containing an array with a matching element
//         {
//           _id: req.body.group_id,
//           members: {
//             $elemMatch: { user_id: req.body.user_id, is_admin: false },
//           },
//         },

//         // Positional operator $ is a placeholder for the first matching array element
//         {
//           $set: { "members.$.status": 1 },
//         }
//       );
//     } else {
//       await Model.Group.updateOne(
//         { _id: req.body.group_id },
//         {
//           $pull: {
//             members: { user_id: req.body.user_id },
//           },
//         }
//       );
//     }

//     //Send Notifications to other users except this user
//     let group = await Model.Group.findById(req.body.group_id).populate('members.user_id');
//     let user = await Model.Users.findOne({ _id: req.body.user_id });

//     let idarrwthoutuserwhoaccepted = [];

//     let notificationmsg = req.body.type==1?`User ${user.userName} Accepted the group invite for group ${group.group_name}`:`User ${user.userName} Rejected the group invite for group ${group.group_name}`;

//     group.members.map((member) => {
//       if (member.user_id && member.user_id._id) {
//         let o = {};
//         o.receiver_id = member.user_id._id;
//         o.group_id = group._id;
//         o.type = 2;
//         o.deviceToken = member.user_id.deviceToken;
//         o.notification = notificationmsg;
//         if (member.is_admin === true) {
//           idarrwthoutuserwhoaccepted.push(o);
//           sendNotification(o.deviceToken, notificationmsg);
//         }
//       }
//     });
    

//     //notifications types 1.Group Create 2.Accept Reject Group Invite
//     if (req.body.type == 1) {
//       await Model.Notification.insertMany(idarrwthoutuserwhoaccepted);
//     }

//     //remove accept reject notification from DB
//     await Model.Notification.deleteOne({
//       group_id: req.body.group_id,
//       receiver_id: req.body.user_id,
//       type: 1,
//     });

//     if (req.body.type == 1) {
//       return success(res, "Group Invite Accepted Successfully ", group);
//     } else {
//       return success(res, "Group Invite Rejected", group);
//     }
//   } catch (error) {
//     res.status(400).send(error.message);
//   }
// },

//29 may backup socket.js
// const Model = require("../../../models");
// const {
//   sendNotification
// } = require("../../../config/helper");
// var cron = require('node-cron');
// const mongoose = require('mongoose');
// var _ = require('lodash');
// const socketResponse = require('../../../config/socketResponse');
// const nodeCron = require("node-cron");
// module.exports = function (io) {
// const job = nodeCron.schedule("*/7 * * * *", async() => {
//   let timeouts = {};
    
//   const group = await Model.Group.aggregate([
// { $unwind: "$members" },
// { $match: { "members.sos_status": 1 } }, 
// {
//   $lookup: {
//     from: "users",
//     localField: "members.user_id",
//     foreignField: "_id",
//     as: "member_details",
//   },
// },
// {
//   $group: {
//     _id: "$_id",
//     group_name: { $first: "$group_name" },
//     members: { $push: { $mergeObjects: ["$members", { $arrayElemAt: ["$member_details", 0] }] } },
//     image: { $first: "$image" },
//     group_chat_id: { $first: "$group_chat_id" },
//     destination_address: { $first: "$destination_address" },
//     destination_location: { $first: "$destination_location" },
//   },
// },
// ]);

// if(group.length===0) return;
// for(let i in group){
// const members = group[i].members;
// for(let j in members){
//   // console.log("dskfhjksdhfjkhs")
//   // console.log(group[i].destination_location.coordinates[0])
//   let latitude = parseFloat(members[j]?.destination_location?.coordinates[0]);
//   let longitude = parseFloat(members[j]?.destination_location?.coordinates[1]);
//   console.log(members[j],members[j]?.updated_at,"tu kithe jana ithe hi aana")
//   if(isNaN(latitude) || isNaN(longitude)){
//     console.log('Invalid coordinates');
//     continue; 
//   }
//   const updateAt = members[j]?.updated_at.getTime(); // Convert created_at to milliseconds
//    console.log(members[j],'updateAt')
//   const delay = updateAt + 15 * 60 * 1000 - Date.now(); // Calculate the remaining delay 15 minutes

//   console.log(delay,'delay')

//   const timeoutKey = `${group[i]._id}_${members[j].user_id}`;
//       clearTimeout(timeouts[timeoutKey]);
//   if (delay > 0) {
//     // console.log("check condition")
//     timeouts[timeoutKey] = setTimeout(async () => {
//       clearTimeout(timeouts[timeoutKey]);
//               let data ={
//                 group_chat_id: group[i].group_chat_id,
//                 message: "SOS message !Need a help.",
//                 sender: {
//                   userid: members[j].user_id,
//                   name: members[j].userName,
//                   sender_image: members[j].image?.original,
//                 },
//                 location:  { 
//                   type: "point",
//                   coordinates: [latitude,longitude],
//                 },
//                 type: "sos",
//                 // destination_address:group[i].destination_address

//             }
//         //  console.log(data,'checkit')
//     // console.log(data.location,group[i].group_chat_id,'sdjflsdhflkdhsfjkgdskjfgdjksgfjhgsdfhjgdhjsfg')
//     await Model.Message.create(data);
//     io.emit("sos_listener",data);
//     // Update member's updated_at field
//    let updateval =  await Model.Group.updateOne(
//       {
//         _id: group[i]._id,
//         "members.user_id": members[j].user_id
//       },
//       {
//         $set: {
//           "members.$.updated_at": new Date() // Set updated_at to current date/time
//         }
//       }
//     );
//      // After sending the SOS message, clear the timeout
//     //  clearTimeout(timeouts[timeoutKey]);
//     //  delete timeouts[timeoutKey];
//     // console.log(updateval.modifiedCount)
//   }, delay);
// }
//     // console.log(datacheck,'yes i am working')
  
// }
// }
// });

//     io.on("connection", async (socket) => {
//       // console.log(socket.handshake.auth.token,'checkit')
//       socket.on("connect-user", async (data) => {
//         console.log("user connected hai tension nal lo")
//         await Model.Users.updateOne(
//           { _id: data.userid },
//           {
//             $set: {
//               socketId: socket.id,
//               // isOnline: 1,
//             },
//           }
//         );
//         io.emit("connect-user", data);
        
//       });
//       socket.on("group-message", async (data) => {
//          let finduser = await Model.Users.findOne({_id:data.sender.userid});
//          if(!finduser) return socketResponse.error("user not found",socket,"group-message");
//         if (data.type == "image") {
//           await Model.Message.create(data);
//           io.emit("group-message", data);         
//            let user_id = data.sender.userid;
//           // console.log(user_id, 'checkit');
//            //send notification
//           let group = await Model.Group.findOne({ group_chat_id: mongoose.Types.ObjectId(data.group_chat_id) }).populate('members.user_id');
//           console.log(group,'group is herer')
//           // return;
//           let onlyforReciever = [];
//           let notificationmsg = `User ${data.sender.name} sent an image for group ${group?.group_name}`;              
//           //  console.log(notificationmsg)
//            group?.members.map((member) => {
//             if (member.user_id && member.user_id._id && member.user_id._id.toString() !== user_id.toString() && member.status ==1) {
//               // console.log(member.user_id.deviceToken, 'checkmember');
//               let o = {};
//               o.receiver_id = member.user_id._id;
//               o.group_id = group._id;
//               o.notification = notificationmsg;
//               onlyforReciever.push(o);
//               io.to(member.user_id._id).emit("Notification_sent", o);
//               sendNotification(member.user_id.deviceToken, notificationmsg);
//             }
//           });
//           // console.log(onlyforReciever, 'chekit');
//           //notifications sends only that user who's not sender type image or location
//           await Model.Notification.insertMany(onlyforReciever);
//         } else {
//           // console.log("hey here am i")
//           await Model.Message.create(data);
//           io.emit("group-message", data);
          

//         }

//       });
//       socket.on("location-track", async (data) => {
//         try {
//             console.log(data,'data ishere')
//           // Check if a location entry already exists for the same user_id
//           const existingLocation = await Model.Location.findOne({ user_id: data?.user_id });

//           if (existingLocation) {
//             // If an existing location entry is found, delete it
//             let check = await Model.Location.findByIdAndDelete(existingLocation._id);
//             console.log(check, "deleted data")
//           }
//           // Create a new location entry with the received data
//           let locationData = await Model.Location.create(data);
//           let newobj = {}
//           newobj.longitude = locationData.location.coordinates[0].toString();
//           newobj.latitude = locationData.location.coordinates[1].toString();
//           newobj._id = locationData._id;
//           newobj.user_id = locationData.user_id;
//           newobj.group_id = locationData.group_id;

//           let group_modal = await Model.Group.findById(newobj.group_id);
//           if (!group_modal) {
//             // Handle the case where the group is not found
//             return socketResponse.error("group not found",socket,"location-track");
//           } 
//           const members = group_modal.members;
//           // console.log(members,newobj.user_id,'user_id checkit here')
//           const member = members.find((m) =>m.user_id.toString() === newobj.user_id.toString());
//           // console.log(member,'checkit')
//           if (!member) {
//             // Handle the case where the member is not found
//             return socketResponse.error("Member not found",socket,"location-track");
//           }
//           member.current_location = {
//             type: "point",
//             coordinates: [parseFloat(newobj.longitude),parseFloat(newobj.latitude)],
//           },
//           member.destination_location = {
//             type: "point",
//             coordinates: [parseFloat(newobj.longitude),parseFloat(newobj.latitude)],
//           },

//           // console.log(member.current_location,'checkit')
//           await group_modal.save();
//           socketResponse.success(socket, "location-track", "lacation fetched successfully", newobj)

//         } catch (error) {
//           console.error(error);
//           io.emit("location-track", { error: "Failed to save location" });
//         }
//       });

//       //get location where user go and changed the location
//       socket.on("get_location_track", async (data) => {
//         try {
//           let userid = data.userid;
//           let groupid = data.group_id;
//           var fetchdata = await Model.Location.find({ user_id: userid, group_id: groupid });
//         } catch (err) {
//           console.log(err, 'error is here')
//         }

//         io.emit("get_location_track", fetchdata);
//       })

//       socket.on("offline", async (data) => {
//         /* … */
//         console.log(new Date().toISOString());
//         await Model.Users.updateOne(
//           { socketId: socket.id },
//           {
//             $set: {
//               userLastSeen: new Date().toISOString(),
//               isOnline: 0,
//             },
//           }
//         );
//        // Convert data.userid to ObjectId
//        const userId = ObjectId(data.userid);
//         const groups = await Model.Group.find({ members: { $elemMatch: { user_id: userId,tracking: 1} } });
//         // console.log(groups.length,'chcekit')
//         // return;
//         if (groups.length == 0) return;
//          // Update tracking field in group members
//         for (const group of groups) {
//           // Find the index of the member with the given user ID
//           const member = group.members.find((m) => m.user_id.equals(userId));
//           // console.log(member,'chekit')
//           if (member) {
//             // Update the tracking field to 0 for the member
//             member.tracking = 0;
      
//             // Save the updated group
//             await group.save();
//           }
//         }

//         io.emit("offline",data);
//       });

//       socket.on("get-group-chat", async (data) => {
//         let groupchat = await Model.Message.find({
//           group_chat_id: data.group_chat_id,
//         });

//         io.emit("get-group-chat", groupchat);
//       });
//       socket.on("stop_sos", async (data) => {
//         // Define the keys to validate
//         let keysToValidate = ['userid', 'latitude', 'longitude','group_id'];
//         const validatedData = {};
//         // All keys exist
//         keysToValidate.forEach(key => {
//           if (_.has(data, key)) {
//             validatedData[key] = data[key];
//           } else {

//             io.emit("stop_sos", { error: `Key '${key}' does not exist.` });
//           }
//         });
//         if (Object.keys(validatedData).length === keysToValidate.length) {
//           // All keys exist
//           console.log('All keys exist:', validatedData);
//           try {
//             let trackingStatus = await Model.Group.updateOne(
//               // $elemMatch finds docs containing an array with a matching element
//               {
//                 _id: validatedData.group_id,
//                 members: {
//                   $elemMatch: { user_id: validatedData.userid },
//                 },
//               },
//               // Positional operator $ is a placeholder for the first matching array element
//               {
//                 $set: { "members.$.sos_status": parseInt(0) },
//               }
//             );
//             let updateUserloc;
//             if (trackingStatus.modifiedCount !== 0) {
//               updateUserloc = await Model.Users.updateOne({ _id: validatedData.userid },
//                 {
//                   $set: {
//                     location: {
//                       type: "Point",
//                       coordinates: [
//                         parseFloat(validatedData.longitude),
//                         parseFloat(validatedData.latitude),
//                       ],
//                     },
//                   }
//                 })
//             }
//             // console.log(updateUserloc, 'user updated long,lat')
//             let groupallMember = await Model.Group.findById(validatedData.group_id).populate("members.user_id");
//             let user =  await Model.Users.findById(validatedData.userid)

//       // console.log(groupallMember,'checkit')
//       let notificationmsg2 = `${user?.userName} has stopped SOS ${groupallMember?.group_name} group`;
//       let newaddedmemberarr =[];
//       groupallMember.members.map((id) => {
//         if(id.user_id && id.user_id._id.toString() !== user._id.toString() && id.status==1){
//           let o = {};
//           o.receiver_id = id.user_id._id;
//           o.group_id = groupallMember._id;
//           o.type = 4;
//           o.notification = notificationmsg2;
//           newaddedmemberarr.push(o);
//           sendNotification(id.user_id.deviceToken,notificationmsg2)
//         }
//         });
        
//         await Model.Notification.insertMany(newaddedmemberarr);
//             let group = await Model.Group.findById(validatedData.group_id, {
//               members: 0,
//             });
//             io.emit("stop_sos", data);

//           } catch (err) {
//             console.error(err);
//           }


//         } else {
//           // Some keys are missing
//           console.error('Some keys are missing.');
//         }


//       });

//       socket.on("location-change", async (data) => {
//         //console.log("this is message", data);
//         await Model.Users.updateOne(
//           { _id: data.user_id },
//           {
//             location: [data.longitude, data.latitude],
//           }
//         );
//         sendNotification(data.token, "location changed for user");
//         io.to(data.group_id).emit("location-change", data);
//       });

//       socket.on("disconnect", function () {
//         console.log("user disconneced")
//       })

//       // We can write our socket event listeners in here...
//     });

// }


//socket.js nearest find 15 minutes
// const job = nodeCron.schedule("*/7 * * * *", async () => {
//   let timeouts = {};

//   const group = await Model.Group.aggregate([
//     { $unwind: "$members" },
//     { $match: { "members.sos_status": 1 } },
//     {
//       $lookup: {
//         from: "users",
//         localField: "members.user_id",
//         foreignField: "_id",
//         as: "member_details",
//       },
//     },
//     {
//       $group: {
//         _id: "$_id",
//         group_name: { $first: "$group_name" },
//         members: {
//           $push: { $mergeObjects: ["$members", { $arrayElemAt: ["$member_details", 0] }] },
//         },
//         image: { $first: "$image" },
//         group_chat_id: { $first: "$group_chat_id" },
//         destination_address: { $first: "$destination_address" },
//         destination_location: { $first: "$destination_location" },
//       },
//     },
//   ]);

//   if (group.length === 0) return;

//   for (let i in group) {
//     const members = group[i].members;
//     let nearestMember = null;
//     let nearestDelay = Infinity;

//     for (let j in members) {
//       let latitude = parseFloat(members[j]?.destination_location?.coordinates[0]);
//       let longitude = parseFloat(members[j]?.destination_location?.coordinates[1]);

//       if (isNaN(latitude) || isNaN(longitude)) {
//         console.log("Invalid coordinates");
//         continue;
//       }

//       const updateAt = members[j]?.updated_at.getTime();
//       const delay = updateAt + 15 * 60 * 1000 - Date.now();

//       if (delay <= 0) {
//         console.log("Delay has passed for member:", members[j].user_id);
//         continue;
//       }

//       if (delay < nearestDelay) {
//         nearestDelay = delay;
//         nearestMember = members[j];
//       }
//     }

//     if (nearestMember) {
//       const timeoutKey = `${group[i]._id}_${nearestMember.user_id}`;
//       if (timeouts[timeoutKey]) {
//         clearTimeout(timeouts[timeoutKey]);
//       }

//       timeouts[timeoutKey] = setTimeout(async () => {
//         let data = {
//           group_chat_id: group[i].group_chat_id,
//           message: "SOS message! Need help.",
//           sender: {
//             userid: nearestMember.user_id,
//             name: nearestMember.userName,
//             sender_image: nearestMember.image?.original,
//           },
//           location: {
//             type: "point",
//             coordinates: [
//               parseFloat(nearestMember.destination_location.coordinates[0]),
//               parseFloat(nearestMember.destination_location.coordinates[1]),
//             ],
//           },
//           type: "sos",
//         };

//         await Model.Message.create(data);
//         io.emit("sos_listener", data);

//         // Update member's updated_at field
//         await Model.Group.updateOne(
//           {
//             _id: group[i]._id,
//             "members.user_id": nearestMember.user_id,
//           },
//           {
//             $set: {
//               "members.$.updated_at": new Date(), // Set updated_at to current date/time
//             },
//           }
//         );

//         // After sending the SOS message, clear the timeout
//         clearTimeout(timeouts[timeoutKey]);
//         delete timeouts[timeoutKey];
//       }, nearestDelay);
//     }
//   }
// });













import mongoose from 'mongoose';
// let async = require('async'),
// randomstring = require("randomstring"),
// user_plugin = require("../plugins").userPlugin;         // import mongo plugin for pre save hook

let Schema = mongoose.Schema;

const AdminSchema = new Schema(
  {
    userName: { type: String, index: true, default: "" },
    firstName: { type: String },
    lastName: { type: String },
    phone: { type: String, default: "", index: true },
    email: { type: String, index: true, default: "" },
    password: { type: String, default: "" },
    countryCode: { type: String, default: "" },
    deviceType: { type: String, enum: ["IOS", "ANDROID"], default: "IOS" },
    deviceToken: { type: String, default: "" },
    accessToken: { type: String, trim: true, default: "" },
    socialType: {
      type: Number,//enum 0=facebook,1.google ,2.apple
    },
    socialId: {
      type: String,
    },
    location: {
      type: { type: String },
      coordinates: [],
      //index: "2dsphere",
      //sparse: true,
    }, //[long, lat]
    address: { type: String, default: "" },
    failOtp: { type: Number },
    type: { 
      type: Number,
    },
    otp: { type: Number },
    is_verify: { type: Number, default: 0 },
    otptime: { type: String },
    role: { type: String, enum: ["0", "1"], default: "0" }, // 1 - admin, 0 - user
    image: {
      original: { type: String, default: "" },
      thumbnail: { type: String, default: "" },
    },
    isOnline: { type: String },
    socketId: { type: String },
    userLastSeen: { type : Date},
    status: { type: Number, enum: [0, 1], default: 1 },
  },
  { timestamps: true },
  { toJSON: { getters: true } }
);
//0-off  , 1-on
const AdminModel = mongoose.model('Users', AdminSchema);
AdminModel.syncIndexes();
export default AdminModel;

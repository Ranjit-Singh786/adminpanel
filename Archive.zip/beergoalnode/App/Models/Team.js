import mongoose from 'mongoose';
// let async = require('async'),
// randomstring = require("randomstring"),
// user_plugin = require("../plugins").userPlugin;         // import mongo plugin for pre save hook

let Schema = mongoose.Schema;

const TeamSchema = new Schema(
  {
    teamname: { type: String, index: true, default: "" },
    phone: { type: String, default: "", index: true },
    email: { type: String, index: true, default: "" },
    country: { type: String, default: "" },
    location: {
      type: { type: String },
      coordinates: [],
      //index: "2dsphere",
      //sparse: true,
    }, //[long, lat]
    address: { type: String, default: "" },
    image: {
      original: { type: String, default: "" },
      thumbnail: { type: String, default: "" },
    },
    sports_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Sport', // Replace 'Sport' with the actual name of your sports model
        required: true
      },
  },
  { timestamps: true }
);
//0-off  , 1-on
const TeamModal = mongoose.model('Teams', TeamSchema);
TeamModal.syncIndexes();
export default TeamModal;

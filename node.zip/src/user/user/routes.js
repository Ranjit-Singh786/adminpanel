'use strict';

// const multipart = require('connect-multiparty');
// const multipartMiddleware =   multipart();


// npm modules
const express = require('express')
    // validator = require('express-joi-validator');

// router
const router = express.Router();

// auth in router
// require('../../auth').auth_Fn(router);

// local modules
const controller = require('./controller')
//     routeValidators = require('./validator');


// appointment routes
router.post('/userprofle', controller.create);
// router.get('/appointment', validator(routeValidators.get), controller.get);

const UserController = require('./UserController.js');
router.get('/get-user',  UserController.getUser);



module.exports = router;

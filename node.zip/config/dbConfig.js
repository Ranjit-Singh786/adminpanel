'use strict';

let mongoURI = "";

console.log(process.env.NODE_ENV,'process.env.NODE_ENV')

if (process.env.NODE_ENV === "test") {
  mongoURI = `mongodb://${process.env.mongo_test_user}:${process.env.mongo_test_password}@localhost:27017/${process.env.mongo_test_db}`;
} else if (process.env.NODE_ENV === "dev") {
  // mongoURI = `mongodb+srv://whim:1Sde1qo8uPDzVBOq@cluster0.7ieqs.mongodb.net/acne?retryWrites=true&w=majority`
  mongoURI = process.env.MONGO_DB_CON_URL;
} else if (process.env.NODE_ENV === "local") {
  mongoURI = `mongodb://localhost:27017/acne`;
}
console.log("1111111111111111111111")
console.log("2222222222222222222222222222", mongoURI)
console.log("33333333333333333333333333333333", process.env.NODE_ENV)

module.exports = {
  mongo: mongoURI
};


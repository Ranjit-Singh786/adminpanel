const mongoose = require('mongoose')

const locationSchema = new mongoose.Schema(
  {
   
        user_id: { type: mongoose.Schema.Types.ObjectId, ref: "Users" },
        status: { type: Number },
        location:{
          type: { type: String },
          coordinates: [],
        }, //[long, lat]
       group_id: { type: mongoose.Schema.Types.ObjectId, ref: "Group" },
  },
  {
    timestamps: true,
  }
);


module.exports = mongoose.model('Location', locationSchema);
const Models = require('../../../models');
const sendResponse = require('../../sendResponse.js');
const APP_CONSTANTS = require('../../../config/appConstants.js');
const RESPONSE_MESSAGES = require('../../../config/response-messages.js');
const Validator = require('validatorjs');

function firstError(validation) {
    let first_key = Object.keys(validation.errors.errors)[0];
    return validation.errors.first(first_key);
}


module.exports = {
     //old api
    // async getUser(req, res) {

    // let user_id = req.query.user_id;
    // let user ;
    //     if (user_id) {
    //         user = await Models.Users.findById(user_id);

            
    //     }else{
    //         user = await Models.Users.find({role: 0});
    //      "console.log(hhjhjhjhhjhjhjh"   
    //     }

    //     if (!user) {
    //         return sendResponse.sendErrorMessage( 400,req.headers.language,RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,res);
    //     }


    //     return sendResponse.sendSuccessData(user, APP_CONSTANTS.STATUSCODE.SUCCESS,req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS, res);
    // },

    //modified api
    async getUser(req, res) {
        try {
          const { user_id } = req.query;
      
          let user;
      
          if (user_id) {
            user = await Models.Users.findById(user_id);
          } else {
            user = await Models.Users.find({ role: 0 });
          }
      
          if (!user) {
            return sendResponse.sendErrorMessage(
              400,
              req.headers.language,
              RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
              res
            );
          }
      
          return sendResponse.sendSuccessData(
            user,
            APP_CONSTANTS.STATUSCODE.SUCCESS,
            req.headers.language,
            RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
            res
          );
        } catch (error) {
          console.log(error);
          return sendResponse.sendErrorMessage(
            500,
            req.headers.language,
            RESPONSE_MESSAGES.STATUS_MSG.ERROR.INTERNAL_SERVER_ERROR,
            res
          );
        }
      }
      

    // async updateProfile(){

    // }




}
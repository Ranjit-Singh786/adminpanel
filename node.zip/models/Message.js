const mongoose = require('mongoose')

const messageSchema = new mongoose.Schema(
  {
    sender: {
      userid: { type: mongoose.Schema.Types.ObjectId, ref: "Users" },
      name: { type: String },
      sender_image: { type: String },
    },
    type: { type: String },
    image: { type: String },
    video: {type: String},
    link:{type: String},
    group_chat_id: { type: mongoose.Schema.Types.ObjectId, ref: "Group" },
    message: { type: String },
    location: {
      type: { type: String },
      coordinates: [],
      //index: "2dsphere",
      //sparse: true,
    },
    destination_address:{
      type:String
    }
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Message", messageSchema);
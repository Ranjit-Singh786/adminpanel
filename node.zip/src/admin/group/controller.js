'use strict';
// momentTimezone = require('moment-timezone');
// const is = require("is_js");
const UniversalFunction = require('../../../utils/universal-functions');
const APP_CONSTANTS = require('../../../config/appConstants');
// const paymentStatuses = require('./paymentStatuses.js')
// const schedule = require('node-schedule');
const Models = require('../../../models'),
  sendResponse = require('../../sendResponse'),
  RESPONSE_MESSAGES = require('../../../config/response-messages');

// local modules
// const Models = require('../../../models'),
//     Dao = require('../../../dao').queries,
//     controllerUtil = require('./controllerUtil'),
//     APP_CONSTANTS = require('../../../config/appConstants'),
//     RESPONSE_MESSAGES = require('../../../config/response-messages'),
//     UniversalFunctions = require('../../../utils').universalFunctions,
//     commonFunctions = require('../../../utils').commonController,
//     NotificationManager = require('../../../Lib/NotificationManager'),
//     CommonController = require('../../commonController'),
//     sendResponse = require('../../sendResponse'),
//     paymentGateway = require('../../paymentGateway');


module.exports = {

  add_update_group: async (req, res) => {
    try {

      var payload = req.body;
      console.log("payload =========== ", payload)
      const options = { "upsert": true };
      const criteriaToMatch = { "email": payload.email ? payload.email : '0' };
      // const dataToUpdate = { "name": payload.name };
      var criteria = { "name": payload.name };
      console.log("000000000000")
      if (payload._id && payload._id != "") {
        console.log("8888888888888")
        criteriaToMatch._id = { $ne: payload._id }
        criteria = { "_id": ObjectId(payload._id) };
      }
      delete payload._id;
      Models.Users.findOne(criteriaToMatch, function (err, result) {
        if (err) {
          console.log("1111111111")
          return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
        } else if (result && result != "") {
          console.log("2222222222")
          return sendResponse.sendErrorMessage(403, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.EMAIL_ALREADY_EXISTS, res);
        } else {
          console.log("3333333333333")
          payload.role = (payload.role) ? payload.role : "0";
          payload.isActive = "1";
          if (payload.hasOwnProperty('password') && payload.password) {
            payload.password = UniversalFunction.bcryptHash(payload.password);
          }
          Models.Users.updateOne(criteria, payload, options, function (err, result) {
            if (err) {
              console.log("44444444444444", err)
              return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
            } else {
              return sendResponse.sendSuccessData({}, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
            }
          })
        }
      })
    } catch (err) {
      console.log("err --- ", err)
      return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
    }
  },

  list_group: (req, res) => {
    try {
      Models.Group.find().populate('users')
        .exec(function (err, result) {
          if (err) {
            console.log(err)
            return sendResponse.sendErrorMessageData(400, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.DEFAULT, err, res);
          } else {
            return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
          }
        });

    } catch (err) {
      return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
    }
  },

  get_group: async (req, res) => {
    let group_id = req.params.id;
    let groups;
    let query = [
      { $unwind: "$members" }, // unwind the members array
      //{ $match: { "members.status": 1, "members.user_id": req.user._id } },
      {
        $lookup: {
          // join with the users collection to get the user details
          from: "users",
          localField: "members.user_id",
          foreignField: "_id",
          pipeline: [
            // Exclude some unwanted fields from the right side of the join
            {
              $unset: [
                "password",
                "countryCode",
                "deviceType",
                "deviceToken",
                "accessToken",
                "is_verify",
                "role",
                "status",
                "firstName",
                "lastName",
                "type",
                "otp",
                "createdAt",
                "updatedAt",
              ],
            },
          ],
          as: "userdetail",
        },
      },

      { $unwind: "$userdetail" }, // unwind the userdetail array
      {
        $group: {
          // group the objects back together with the new userdetail field
          _id: "$_id",
          image: { $first: "$image" },
          group_name: { $first: "$group_name" },
          group_chat_id: { $first: "$group_chat_id" },
          createdAt: { $first: "$createdAt" },
          updatedAt: { $first: "$updatedAt" },
          __v: { $first: "$__v" },
          members_array: {
            $push: {
              _id: "$members._id",
              user_id: "$members.user_id",
              is_admin: "$members.is_admin",
              status: "$members.status",
              tracking: "$members.tracking",
              userdetail: "$userdetail",
            },
          },
        },
      },
      /*{
        $project: {
          members_array: {
            $filter: {
              input: "$members_array",
              as: "item",
              cond: { $eq: ["$$item.status", 1] },
            },
          },
        },
      },*/
    ];

    if (group_id) {
      query.push({ $match: { _id: ObjectId(group_id) } });
      // query[2] = { $match: { _id: ObjectId(group_id) } };
      groups = await Models.Group.aggregate(query);
      if (groups.length) {
        groups = groups[0];
      }

      if (groups.length == 0) {
        groups = {};
        return sendResponse.sendErrorMessage(
          400,
          req.headers.language,
          RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
          res
        );
      }
    } else {
      query.unshift({ $match: { "members.user_id": req.user._id } });
      query.push({ $sort: { createdAt: -1 } });
      groups = await Models.Group.aggregate(query);
    }

    if (!groups) {
      return sendResponse.sendErrorMessage(
        400,
        req.headers.language,
        RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
        res
      );
    }

    return sendResponse.sendSuccessData(
      groups,
      APP_CONSTANTS.STATUSCODE.SUCCESS,
      req.headers.language,
      RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
      res
    );
  },


  // active_inactive_group: async (req, res) => {
  //     try {


  //         let data = await Models.Users.findOne({ "_id": req.query.id }, { isActive: 1 })

  //         var updateIsActive = '1'

  //         if (data.isActive == '1') {
  //             updateIsActive = '0'
  //         }
  //         let update_status = await Models.Users.updateOne({ "_id": req.query.id }, { "isActive": updateIsActive }, function (err, result) {
  //             console.log(err, " ******************* ", result)
  //             if (err) {
  //                 return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
  //             }
  //             else {
  //                 return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
  //             }
  //         })

  //     } catch (err) {
  //         return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
  //     }
  // },




  delete_group: async (req, res) => {
    try {
      Models.Group.deleteOne({ "_id": ObjectId(req.query.id) }, function (err, result) {
        if (err) {
          return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
        }
        else {
          return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
        }
      })

    } catch (err) {
      return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
    }

  },


  delete_reported_group : async (req, res) => {
    try {
      Models.ReportGroup.deleteOne({ "_id": ObjectId(req.query.id) }, function (err, result) {
        if (err) {
          return sendResponse.sendErrorMessage(403, req.headers.language, err, res);
        }
        else {
          return sendResponse.sendSuccessData(result, 200, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.DEFAULT, res);
        }
      })

    } catch (err) {
      return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
    }
  },


  getReportList: async (req, res) => {
    try {
      const reportedGroups = await Models.ReportGroup.aggregate([
        {
          $lookup: {
            from: 'groups',
            localField: 'group_id',
            foreignField: '_id',
            as: 'group'
          }
        },
        {
          $lookup: {
            from: 'users',
            localField: 'report_by',
            foreignField: '_id',
            as: 'report_by'
          }
        },
        {
          $unwind: {
            path: '$group',
            preserveNullAndEmptyArrays: true
          }
        },
        {
          $unwind: {
            path: '$report_by',
            preserveNullAndEmptyArrays: true
          }
        },
        {
          $match: {
            group: { $ne: null },
            report_by: { $ne: null }
          }
        }
      ]);

      // Send report data in response
      res.status(200).json({
        status: true,
        body: reportedGroups
      });
    } catch (err) {
      console.error(err);
      return sendResponse.sendErrorMessage(500, req.headers.language, RESPONSE_MESSAGES.STATUS_MSG.ERROR.APP_ERROR, res);
    }
  }


};

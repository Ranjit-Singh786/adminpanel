const mongoose = require('mongoose')
const memberSchema = new mongoose.Schema(
  {
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: "Users" },
    is_admin: { type: Boolean },
    status: { type: Number },
    tracking: { type: Number },
    sos_status: { type: Number },
    onlineStatus: { type: Number },
    destination_location: {
      type: { type: String },
      coordinates: [],
    },
    current_location: {
      type: { type: String },
      coordinates: [],
    },
  },
  {
    timestamps: { createdAt: "created_at", updatedAt: "updated_at" },
  }
);

const groupSchema = new mongoose.Schema(
  {
    group_name: { type: String },
    members: [memberSchema],
    image: {
      original: { type: String, default: "" },
      thumbnail: { type: String, default: "" },
    },
    group_chat_id: { type: mongoose.Schema.Types.ObjectId, ref: "Group" },
    // destination_address: { type: String },
    invitation_link:{type:String},
    invitation_token:{type:String},
    invitation_token_expire:{type: Date},
    tracking_status:{type:Boolean , default : 0}
    // destination_location:{
    //   type: { type: String },
    //   coordinates: [],
      //index: "2dsphere",
      //sparse: true,
    // }, //[long, lat]
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model('Group', groupSchema);
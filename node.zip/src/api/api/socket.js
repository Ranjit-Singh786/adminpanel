const Model = require("../../../models");
const {
  sendNotification
} = require("../../../config/helper");
var cron = require('node-cron');
const mongoose = require('mongoose');
var _ = require('lodash');
const socketResponse = require('../../../config/socketResponse');
const nodeCron = require("node-cron");
// const { promisify } = require('util');
module.exports = function (io) {
   //new updated code
  //  const job = nodeCron.schedule("*/7 * * * *", async () => {
  //   const timeout = {};
  
  //   const groups = await Model.Group.aggregate([
  //     { $unwind: "$members" },
  //     { $match: { "members.sos_status": 1 } },
  //     {
  //       $lookup: {
  //         from: "users",
  //         localField: "members.user_id",
  //         foreignField: "_id",
  //         as: "member_details",
  //       },
  //     },
  //     {
  //       $group: {
  //         _id: "$_id",
  //         group_name: { $first: "$group_name" },
  //         members: { $push: { $mergeObjects: ["$members", { $arrayElemAt: ["$member_details", 0] }] } },
  //         image: { $first: "$image" },
  //         group_chat_id: { $first: "$group_chat_id" },
  //         destination_address: { $first: "$destination_address" },
  //         destination_location: { $first: "$destination_location" },
  //       },
  //     },
  //   ]);
  
  //   if (groups.length === 0) return;
  
  //   const currentTimestamp = new Date().getTime();
  
  //   for (const group of groups) {
  //     const members = group.members;
  
  //     let nextMember = null;
  //     let nextMemberDelay = Infinity;
  //     let nextMemberUpdatedAt = null;
  //     for (const member of members) {
  //       console.log(member,'iterate member is here')
  //       const latitude = parseFloat(member?.destination_location?.coordinates?.[0]);
  //       const longitude = parseFloat(member?.destination_location?.coordinates?.[1]);
  
  //       if (isNaN(latitude) || isNaN(longitude)) {
  //         console.log("Invalid coordinates for user:", member.user_id);
  //         continue;
  //       }
  
  //       const updatedAt = member?.updated_at?.getTime(); // Convert updated_at to milliseconds
  //       // console.log(updatedAt,"updated at")
  //       // console.log(typeof updatedAt,"updated at")
  
  //       if (!updatedAt) {
  //         console.log("Invalid updated_at for user:", member.user_id);
  //         continue;
  //       }
  //       const delay = updatedAt + 15 * 60 * 1000 - currentTimestamp; // Calculate the remaining delay (15 minutes)
  
  //       if (delay <= 0) {
  //         console.log("Delay has passed for user:", member.user_id);
  //         continue;
  //       }
  
  //       if (delay < nextMemberDelay) {
  //         nextMember = member;
  //         nextMemberDelay = delay;
  //         nextMemberUpdatedAt = updatedAt;
  //       }
  //     }
  //     if (nextMember) {
  //       const timeoutKey = `${group._id}_${nextMember.user_id}`;
  //       clearTimeout(timeout[timeoutKey]);
  
  //       const currentTime = Date.now();
  //       const remainingDelay = nextMemberDelay - (currentTime - nextMemberUpdatedAt) + 15 * 60 * 1000;
  //       timeout[timeoutKey] = setTimeout(async () => {
  //         const latitude = parseFloat(nextMember?.destination_location?.coordinates?.[0]);
  //         const longitude = parseFloat(nextMember?.destination_location?.coordinates?.[1]);
  
  //         const data = {
  //           group_chat_id: group.group_chat_id,
  //           message: "SOS message! Need help.",
  //           sender: {
  //             userid: nextMember.user_id,
  //             name: nextMember.userName,
  //             sender_image: nextMember.image?.original,
  //           },
  //           location: {
  //             type: "point",
  //             coordinates: [latitude, longitude],
  //           },
  //           type: "sos",
  //         };
  
  //         await Model.Message.create(data);
  //         io.emit("sos_listener", data);
  
  //         // Update member's updated_at field
  //         await Model.Group.updateOne(
  //           {
  //             _id: group._id,
  //             "members.user_id": nextMember.user_id,
  //           },
  //           {
  //             $set: {
  //               "members.$.updated_at": new Date(), // Set updated_at to current date/time

  //             },
  //           }
  //         );
  
  //         console.log("SOS message sent for user:", nextMember.user_id);
  
  //         clearTimeout(timeout[timeoutKey]);
  //         delete timeout[timeoutKey];
  //       }, remainingDelay);
  
  //       timeout[timeoutKey] = timeout;
  //     }
  //   }
  // });

  //this code lastlatest wokring
  nodeCron.schedule("*/7 * * * *", async () => {
    const timeout = {};
  
    const groups = await Model.Group.aggregate([
      { $unwind: "$members" },
      { $match: { "members.sos_status": 1 } },
      {
        $lookup: {
          from: "users",
          localField: "members.user_id",
          foreignField: "_id",
          as: "member_details",
        },
      },
      {
        $group: {
          _id: "$_id",
          group_name: { $first: "$group_name" },
          members: {
            $push: { $mergeObjects: ["$members", { $arrayElemAt: ["$member_details", 0] }] },
          },
          image: { $first: "$image" },
          group_chat_id: { $first: "$group_chat_id" },
          destination_address: { $first: "$destination_address" },
          destination_location: { $first: "$destination_location" },
        },
      },
    ]);
  
    if (groups.length === 0) return;
  
    const currentTimestamp = new Date().getTime(); // Update current timestamp retrieval method
  
    for (const group of groups) {
      const members = group.members;
  
      for (const member of members) {
        const latitude = parseFloat(member?.destination_location?.coordinates?.[0]);
        const longitude = parseFloat(member?.destination_location?.coordinates?.[1]);
  
        if (isNaN(latitude) || isNaN(longitude)) {
          console.log("Invalid coordinates for user:", member.user_id);
          continue;
        }
  
        const updatedAt = member?.updated_at?.getTime(); // Convert updated_at to milliseconds
  
        if (!updatedAt) {
          console.log("Invalid updated_at for user:", member.user_id);
          continue;
        }
  
        const delay = updatedAt + 15 * 60 * 1000 - currentTimestamp; // Calculate the remaining delay (15 minutes)
  
        if (delay <= 0) {
          console.log("Delay has passed for user:", member.user_id);
          continue;
        }
  
        const timeoutKey = `${group._id}_${member.user_id}`;
        clearTimeout(timeout[timeoutKey]);
  
        const remainingDelay = delay;
  
        timeout[timeoutKey] = setTimeout(async () => {
          const userTimeout = timeout[timeoutKey];
          clearTimeout(userTimeout);
          const latitude = parseFloat(member?.destination_location?.coordinates?.[0]);
          const longitude = parseFloat(member?.destination_location?.coordinates?.[1]);
  
          const data = {
            group_chat_id: group.group_chat_id,
            message: "SOS message! Need help.",
            sender: {
              userid: member.user_id,
              name: member.userName,
              sender_image: member.image?.original,
            },
            location: {
              type: "point",
              coordinates: [latitude, longitude],
            },
            type: "sos",
          };
  
          await Model.Message.create(data);
          io.emit("sos_listener", data);
  
          // Update member's updated_at field
          await Model.Group.updateOne(
            {
              _id: group._id,
              "members.user_id": member.user_id,
            },
            {
              $set: {
                "members.$.updated_at": new Date(), // Set updated_at to current date/time
              },
            }
          );
  
          console.log("SOS message sent for user:", member.user_id);
  
          clearTimeout(timeout[timeoutKey]);
          delete timeout[timeoutKey];
        }, remainingDelay);
  
        timeout[timeoutKey] = timeout;
      }
    }
  });
// const job = nodeCron.schedule("*/7 * * * *", async() => {
//   let timeouts = {};
    
//   const group = await Model.Group.aggregate([
// { $unwind: "$members" },
// { $match: { "members.sos_status": 1 } }, 
// {
//   $lookup: {
//     from: "users",
//     localField: "members.user_id",
//     foreignField: "_id",
//     as: "member_details",
//   },
// },
// {
//   $group: {
//     _id: "$_id",
//     group_name: { $first: "$group_name" },
//     members: { $push: { $mergeObjects: ["$members", { $arrayElemAt: ["$member_details", 0] }] } },
//     image: { $first: "$image" },
//     group_chat_id: { $first: "$group_chat_id" },
//     destination_address: { $first: "$destination_address" },
//     destination_location: { $first: "$destination_location" },
//   },
// },
// ]);

// if(group.length===0) return;
// for(let i in group){
// const members = group[i].members;
// for(let j in members){
//   // console.log("dskfhjksdhfjkhs")
//   // console.log(group[i].destination_location.coordinates[0])
//   let latitude = parseFloat(members[j]?.destination_location?.coordinates[0]);
//   let longitude = parseFloat(members[j]?.destination_location?.coordinates[1]);
//   console.log(members[j],members[j]?.updated_at,"tu kithe jana ithe hi aana")
//   if(isNaN(latitude) || isNaN(longitude)){
//     console.log('Invalid coordinates');
//     continue;
//   }
//   const updateAt = members[j]?.updated_at.getTime(); // Convert created_at to milliseconds
//    console.log(members[j],'updateAt')
//   const delay = updateAt + 15 * 60 * 1000 - Date.now(); // Calculate the remaining delay 15 minutes

//   console.log(delay,'delay')
//   if (delay <= 0) {
//     console.log("Delay has passed for user:", members[j].user_id);
//     continue;
//   }

//   const timeoutKey = `${group[i]._id}_${members[j].user_id}`;
//   clearTimeout(timeouts[timeoutKey]);
//   if(timeouts[timeoutKey]){
//     clearTimeout(timeouts[timeoutKey]);
//   }
//   if (delay > 0) {
//     // console.log("check condition")
//     timeouts[timeoutKey] = setTimeout(async () => { 
//               let data ={
//                 group_chat_id: group[i].group_chat_id,
//                 message: "SOS message !Need a help.",
//                 sender: {
//                   userid: members[j].user_id,
//                   name: members[j].userName,
//                   sender_image: members[j].image?.original,
//                 },
//                 location:  { 
//                   type: "point",
//                   coordinates: [latitude,longitude],
//                 },
//                 type: "sos",
//                 // destination_address:group[i].destination_address
//             }
//          console.log(data,'checkit')
//     // console.log(data.location,group[i].group_chat_id,'sdjflsdhflkdhsfjkgdskjfgdjksgfjhgsdfhjgdhjsfg')
//     await Model.Message.create(data);
//     io.emit("sos_listener",data);
//     // Update member's updated_at field
//      await Model.Group.updateOne(
//       {
//         _id: group[i]._id,
//         "members.user_id": members[j].user_id
//       },
//       {
//         $set: {
//           "members.$.updated_at": new Date() // Set updated_at to current date/time
//         }
//       }
//     );
//      // After sending the SOS message, clear the timeout
//      clearTimeout(timeouts[timeoutKey]);
//      delete timeouts[timeoutKey];
//     // console.log(updateval.modifiedCount)
//   }, delay);
// }
//     // console.log(datacheck,'yes i am working')
// }
// }
// });


      
// const job = nodeCron.schedule("*/7 * * * *", async () => {
//   const group = await Model.Group.aggregate([
//     { $unwind: "$members" },
//     { $match: { "members.sos_status": 1 } },
//     {
//       $lookup: {
//         from: "users",
//         localField: "members.user_id",
//         foreignField: "_id",
//         as: "member_details",
//       },
//     },
//     {
//       $group: {
//         _id: "$_id",
//         group_name: { $first: "$group_name" },
//         members: { $push: { $mergeObjects: ["$members", { $arrayElemAt: ["$member_details", 0] }] } },
//         image: { $first: "$image" },
//         group_chat_id: { $first: "$group_chat_id" },
//         destination_address: { $first: "$destination_address" },
//         destination_location: { $first: "$destination_location" },
//       },
//     },
//   ]);

//   if (group.length === 0) return;

//   for (const groupData of group) {
//     const { members } = groupData;

//     for (const member of members) {
//       const latitude = parseFloat(member?.destination_location?.coordinates[0]);
//       const longitude = parseFloat(member?.destination_location?.coordinates[1]);

//       if (isNaN(latitude) || isNaN(longitude)) {
//         console.log('Invalid coordinates');
//         continue;
//       }

//       const updateAt = member?.updated_at.getTime();
//       const targetTime = new Date(updateAt + 15 * 60 * 1000);
//       const currentTime = new Date();
//       const delay = targetTime - currentTime;
//       console.log(delay,'cechk')
//       if (delay > 0) {
//         const timeoutKey = `${groupData._id}_${member.user_id}`;
//         clearTimeout(timeouts[timeoutKey]);
//         timeouts[timeoutKey] = setTimeout(async () => {
//           const data = {
//             group_chat_id: groupData.group_chat_id,
//             message: "SOS message! Need help.",
//             sender: {
//               userid: member.user_id,
//               name: member.userName,
//               sender_image: member.image?.original,
//             },
//             location: {
//               type: "point",
//               coordinates: [latitude, longitude],
//             },
//             type: "sos",
//           };
//           console.log(data,'data is here');
//           await Model.Message.create(data);
//           io.emit("sos_listener", data);

//           await Model.Group.updateOne(
//             {
//               _id: groupData._id,
//               "members.user_id": member.user_id,
//             },
//             {
//               $set: {
//                 "members.$.updated_at": new Date(),
//               },
//             }
//           );

//           delete timeouts[timeoutKey];
//         }, delay);
//       }
//     }
//   }
// });

    io.on("connection", async (socket) => {
      // console.log(socket.id,'checkit')
      socket.on("connect-user", async (data) => {
        console.log("user connected hai tension na lo")
        await Model.Users.updateOne(
          { _id: data.userid },
          {
            $set: {
              socketId: socket.id,
              // isOnline: 1,
            },
          }
        );
        io.emit("connect-user", data);
        
      });
      socket.on("group-message", async (data) => {
         let finduser = await Model.Users.findOne({_id:data.sender.userid});
         if(!finduser) return socketResponse.error("user not found",socket,"group-message");
        if (data.type == "image") {
          await Model.Message.create(data);
          io.emit("group-message", data);         
           let user_id = data.sender.userid;
          // console.log(user_id, 'checkit');
           //send notification
          let group = await Model.Group.findOne({ group_chat_id: mongoose.Types.ObjectId(data.group_chat_id) }).populate('members.user_id');
          console.log(group,'group is herer')
          // return;
          let onlyforReciever = [];
          let notificationmsg = `User ${data.sender.name} sent an image for group ${group?.group_name}`;              
          //  console.log(notificationmsg)
           group?.members.map((member) => {
            if (member.user_id && member.user_id._id && member.user_id._id.toString() !== user_id.toString() && member.status ==1) {
              // console.log(member.user_id.deviceToken, 'checkmember');
              let o = {};
              o.receiver_id = member.user_id._id;
              o.group_id = group._id;
              o.notification = notificationmsg;
              onlyforReciever.push(o);
          
              io.to(member.user_id._id).emit("Notification_sent", o);
              sendNotification(member.user_id.deviceToken, notificationmsg);
            }
          });

          // console.log(onlyforReciever, 'chekit');
          //notifications sends only that user who's not sender type image or location
          await Model.Notification.insertMany(onlyforReciever);
        } else {
          // console.log("hey here am i")
          await Model.Message.create(data);
          io.emit("group-message", data);

        }
      });
      socket.on("location-track", async (data) => {
        try {
            console.log(data,'data ishere')
          // Check if a location entry already exists for the same user_id
          const existingLocation = await Model.Location.findOne({ user_id: data?.user_id });

          if (existingLocation) {
            // If an existing location entry is found, delete it
            let check = await Model.Location.findByIdAndDelete(existingLocation._id);
            console.log(check, "deleted data")
          }
          // Create a new location entry with the received data
          let locationData = await Model.Location.create(data);
          let newobj = {}
          newobj.longitude = locationData.location.coordinates[0].toString();
          newobj.latitude = locationData.location.coordinates[1].toString();
          newobj._id = locationData._id;
          newobj.user_id = locationData.user_id;
          newobj.group_id = locationData.group_id;

          let group_modal = await Model.Group.findById(newobj.group_id).populate("members.user_id");
          if (!group_modal) {
            // Handle the case where the group is not found
            return socketResponse.error("group not found",socket,"location-track");
          } 
          const members = group_modal.members;
          console.log(members,'check members')
          // console.log(members,newobj.user_id,'user_id checkit here')
          const member = members.find((m) =>m.user_id._id.toString() === newobj.user_id.toString());
          // console.log(member,'checkit')
          if (!member) {
            // Handle the case where the member is not found
            return socketResponse.error("Member not found",socket,"location-track");
          }
          member.current_location = {
            type: "point",
            coordinates: [parseFloat(newobj.longitude),parseFloat(newobj.latitude)],
          },
          member.destination_location = {
            type: "point",
            coordinates: [parseFloat(newobj.longitude),parseFloat(newobj.latitude)],
          },

          // console.log(member.current_location,'checkit')
          await group_modal.save();
          // console.log(socket.id,'check real socket id')
          members.forEach((member) => {
            if (member.user_id._id.toString() !== member.user_id.toString()) {
              console.log(member.user_id.socketId,'check members socket id')
              socketResponse.successTo(socket,member.user_id.socketId,"location-track","lacation fetched successfully",newobj)
            }
          });

          socketResponse.success(socket, "location-track", "lacation fetched successfully", newobj)

        } catch (error) {
          console.error(error);
          io.emit("location-track", { error: "Failed to save location" });
        }
      });
      //get location where user go and changed the location
      socket.on("get_location_track", async (data) => {
        try {
          let userid = data.userid;
          let groupid = data.group_id;
          var fetchdata = await Model.Location.find({ user_id: userid, group_id: groupid });
        } catch (err) {
          console.log(err, 'error is here')
        }

        io.emit("get_location_track", fetchdata);
      })

      socket.on("offline", async (data) => {
        /* … */
        console.log(new Date().toISOString());
        await Model.Users.updateOne(
          { socketId: socket.id },
          {
            $set: {
              userLastSeen: new Date().toISOString(),
              isOnline: 0,
            },
          }
        );
       // Convert data.userid to ObjectId
       const userId = ObjectId(data.userid);
        const groups = await Model.Group.find({ members: { $elemMatch: { user_id: userId,tracking: 1} } });
        // console.log(groups.length,'chcekit')
        // return;
        if (groups.length == 0) return;
         // Update tracking field in group members
        for (const group of groups) {
          // Find the index of the member with the given user ID
          const member = group.members.find((m) => m.user_id.equals(userId));
          // console.log(member,'chekit')
          if (member) {
            // Update the tracking field to 0 for the member
            member.tracking = 0;
      
            // Save the updated group
            await group.save();
          }
        }

        io.emit("offline",data);
      });

      socket.on("get-group-chat", async (data) => {
        let groupchat = await Model.Message.find({
          group_chat_id: data.group_chat_id,
        });

        io.emit("get-group-chat", groupchat);
      });
      socket.on("stop_sos", async (data) => {
        // Define the keys to validate
        let keysToValidate = ['userid', 'latitude', 'longitude','group_id'];
        const validatedData = {};
        // All keys exist
        keysToValidate.forEach(key => {
          if (_.has(data, key)) {
            validatedData[key] = data[key];
          } else {

            io.emit("stop_sos", { error: `Key '${key}' does not exist.` });
          }
        });
        if (Object.keys(validatedData).length === keysToValidate.length) {
          // All keys exist
          console.log('All keys exist:', validatedData);
          try {
            let trackingStatus = await Model.Group.updateOne(
              // $elemMatch finds docs containing an array with a matching element
              {
                _id: validatedData.group_id,
                members: {
                  $elemMatch: { user_id: validatedData.userid },
                },
              },
              // Positional operator $ is a placeholder for the first matching array element
              {
                $set: { "members.$.sos_status": parseInt(0) },
              }
            );
            let updateUserloc;
            if (trackingStatus.modifiedCount !== 0) {
              updateUserloc = await Model.Users.updateOne({ _id: validatedData.userid },
                {
                  $set: {
                    location: {
                      type: "Point",
                      coordinates: [
                        parseFloat(validatedData.longitude),
                        parseFloat(validatedData.latitude),
                      ],
                    },
                  }
                })
            }
            // console.log(updateUserloc, 'user updated long,lat')
            let groupallMember = await Model.Group.findById(validatedData.group_id).populate("members.user_id");
            let user =  await Model.Users.findById(validatedData.userid)

      // console.log(groupallMember,'checkit')
      let notificationmsg2 = `${user?.userName} has stopped SOS ${groupallMember?.group_name} group`;
      let newaddedmemberarr =[];
      groupallMember.members.map((id) => {
        if(id.user_id && id.user_id._id.toString() !== user._id.toString() && id.status===1){
          let o = {};
          o.receiver_id = id.user_id._id;
          o.group_id = groupallMember._id;
          o.type = 4;
          o.notification = notificationmsg2;
          newaddedmemberarr.push(o);
          sendNotification(id.user_id.deviceToken,notificationmsg2)
        }
        });
        
        await Model.Notification.insertMany(newaddedmemberarr);
            let group = await Model.Group.findById(validatedData.group_id, {
              members: 0,
            });
            io.emit("stop_sos", data);

          } catch (err) {
            console.error(err);
          }


        } else {
          // Some keys are missing
          console.error('Some keys are missing.');
        }


      });

      socket.on("location-change", async (data) => {
        //console.log("this is message", data);
        await Model.Users.updateOne(
          { _id: data.user_id },
          {
            location: [data.longitude, data.latitude],
          }
        );
        sendNotification(data.token, "location changed for user");
        io.to(data.group_id).emit("location-change", data);
      });

      socket.on("disconnect", async function () {
        console.log("user disconnected",socket.id);
      
        try {
          const user = await Model.Users.findOneAndUpdate(
            { socketId: socket.id },
            {
              $set: {
                userLastSeen: new Date().toISOString(),
                isOnline: "0",
              },
            },
            { new: true } // Return the updated user document
          );
      
          if (!user) {
            console.log("User not found");
            return;
          }
      
          const userId = user._id;
          const groups = await Model.Group.find({
            members: {
              $elemMatch: { user_id: userId, tracking: 1 },
            },
          });
      
          if (groups.length === 0) {
            console.log("No groups found");
            return;
          }
      
          for (const group of groups) {
            const member = group.members.find((m) => m.user_id.equals(userId));
      
            if (member) {
              member.set("tracking", 0);
              member.set("onlineStatus", 0);
              await group.save();
            }
          }
        } catch (error) {
          console.error("Error occurred during disconnection:", error);
        }
      });
      // We can write our socket event listeners in here...
    });

}
const mongoose = require('mongoose')

const socketUserSchema = new mongoose.Schema({
    userId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'user'
    },
    socketId:{
        type:String
    },  
    isOnline:{
        type:String,
        default:'inactive'
    }
},{
    timestamps:true
})

module.exports = mongoose.model('socket_User',socketUserSchema)
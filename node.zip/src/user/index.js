/**
 * Makes all features available to outer modules.
 */

const express = require('express')
const router = express.Router();
router.use('/', require('./user').Routes);
module.exports = {
   routes : [ router ],
   swagger: [{
       ...require('./user').swagger.paths
   }],
   swaggerSchemas: [{
       ...require('./user').swagger.schemas
   }]
};

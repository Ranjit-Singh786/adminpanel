import mongoose from 'mongoose';
// let async = require('async'),
// randomstring = require("randomstring"),
// user_plugin = require("../plugins").userPlugin;         // import mongo plugin for pre save hook

let Schema = mongoose.Schema;

const BarsOfferSchema = new Schema(
  {
    title: { type: String, index: true, default: "" },
    description: { type: String, default: "", index: true },
    discount: { type: Number, index: true, default: "" },
    barDetail: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Bars', // Replace 'Sport' with the actual name of your sports model
        required: true
      },
  },
  { timestamps: true }
);
//0-off  , 1-on
const BarOfferModal = mongoose.model('BarOffer', BarsOfferSchema);
BarOfferModal.syncIndexes();
export default BarOfferModal;

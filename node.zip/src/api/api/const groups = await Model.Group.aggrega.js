const groups = await Model.Group.aggregate([
  {
    $match: {
      members: {
        $elemMatch: {
          user_id: mongoose.Types.ObjectId(req.user._id)
        }
      },
      tracking_status: true
    }
  },
  {
    $addFields: {
      members_array: {
        $map: {
          input: "$members",
          as: "member",
          in: {
            $mergeObjects: [
              "$$member",
              {
                userdetail: {
                  $let: {
                    vars: {
                      matchedUser: {
                        $arrayElemAt: [
                          {
                            $filter: {
                              input: "$userdetail",
                              as: "user",
                              cond: {
                                $eq: ["$$user._id", "$$member.user_id"]
                              }
                            }
                          },
                          0
                        ]
                      }
                    },
                    in: "$$matchedUser"
                  }
                }
              }
            ]
          }
        }
      }
    }
  },
  {
    $project: {
      members: 0,
      userdetail: 0
    }
  }
]);

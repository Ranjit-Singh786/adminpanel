import "./list.scss";
import Sidebar from "../../components/sidebar/Sidebar";
import Navbar from "../../components/navbar/Navbar";
import Datatable from "../../components/datatable/Datatable";
// import SportDatatable from "../../components/datatable/SportDatatable";
import { useLocation } from "react-router-dom";
import { userColumns,sportColumns } from "../../datatablesource";
const List = () => {
  const location = useLocation();

  return (
    <div className="list">
      <Sidebar />
      <div className="listContainer">
        <Navbar />
        {location.pathname.includes("users") ? (
          <Datatable addroute="users" apiEndpoint="get_users" columns={userColumns}/> // Render the user datatable
        ) : (
          <Datatable addroute="sports" apiEndpoint="get_sports" columns={sportColumns}/> // Render the sport datatable
        )}
      </div>
    </div>
  );
};

export default List;

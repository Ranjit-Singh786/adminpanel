
import React from 'react'

const UserInfo = async(user) => {
    console.log(user,'user data is here')
    // return (
    //     <div className="single">
    //       <Sidebar />
    //       <div className="singleContainer">
    //         <Navbar />
    //         <div className="top">
    //           <div className="left">
    //           <Link to={`/sports/update/${sportsId}`} className="editButton">
    //               Edit
    //             </Link>
    //             <h1 className="title">Information</h1>
    //             <div className="item">
    //               <img
    //                 src={`http://localhost:8000/uploads/user/${sportData?.logo}`}
    //                 alt=""
    //                 className="itemImg"
    //               />
    //               <div className="details">
    //                 <div className="detailItem">
    //                   <span className="itemKey">Sport Name:</span>
    //                   <span className="itemValue">{sportData?.sportname}</span>
    //                 </div>
    //                 {/* Add other sport details here */}
    //               </div>
    //             </div>
    //           </div>
    //           <div className="right">
    //             <Chart aspect={3 / 1} title="User Spending (Last 6 Months)" />
    //           </div>
    //         </div>
    //         <div className="bottom">
    //           <h1 className="title">Last Transactions</h1>
    //           <List />
    //         </div>
    //       </div>
    //     </div>
    //   );
}
export default UserInfo;
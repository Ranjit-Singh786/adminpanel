const mongoose  = require('mongoose')


const AdminCommition = new mongoose.Schema({
    commission:Number,
    name:String,
    status:{type:Number , default:1}
},
{
    timestamps:true
})


module.exports = mongoose.model('adminCommission', AdminCommition)
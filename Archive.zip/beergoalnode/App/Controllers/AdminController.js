
import BarModel from "../Models/Bars.js";
import TeamModel from "../Models/Team.js";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import helper from "../../Common/helper.js";
import { Validator } from 'node-input-validator';
import SportModal from "../Models/Sport.js";
import mongoose from "mongoose";
import BarOfferModal from "../Models/Baroffer.js";
import AdminModel from "../Models/Admin.js";
import CmsModal from "../Models/cms.js";

export default {
  async login(req, res) {
    try {
      const v = new Validator(req.body, {
        email: 'required|email',
        password: "string|required",
      });

      const value = JSON.parse(JSON.stringify(v));
      const errorResponse = await helper.checkValidation(v);
      console.log(errorResponse)
      if (errorResponse) {
        return helper.failed(res, errorResponse);
      }

      const { email, password } = req.body;
        // console.log(email,"echekithdjhfg")
      let user = await AdminModel.findOne({ email });
      console.log(user,'check')
      if (!user) {
        return helper.failed(res,"Please use a registered email",{})
      }

      const isMatch = await bcrypt.compare(password, user.password);

      if (!isMatch) {
        return helper.failed(res,"Please use the correct password",{})
      }
  //  console.log(user._id,'user id is here')
      const payload = {
          id: user._id,
      };
      delete user.password;
      delete user.__v;
      jwt.sign(
        payload,
        process.env.JWT_SECRET,
        { expiresIn: 360000 },
        (err, token) => {
          if (err) throw err;
          helper.success(res,"Login success",{data: { ...user._doc, token }})
        }
      );
    } catch (error) {
      console.error(error.message,'checkit');
      helper.failed(res,"login failed",error)
    }
  },
  async  get_profile(req, res) {
    try {
      // Retrieve the user profile data from the req.user object
      const userProfile = req.user;
  
      // Create a new object without the password field
        delete userProfile.password;
  
      // Send the user profile data as a response
      return helper.success(
        res,
        "Profile fetched successfully",
         userProfile
      );
    } catch (error) {
      console.error('Error retrieving user profile:', error);
      return helper.failed(res, 'Error retrieving user profile');
    }
  },
  async edit_profile(req, res) {
    try {
      // Retrieve the updated profile data from the request body
      const { userName, email } = req.body;
  
      // Retrieve the user profile data from the req.user object
      const userProfile = req.user;
  
      // Update the profile data
      let adminData = await AdminModel.findById(userProfile._id);
      let updateFields = {};
  
      // Check if name is provided in the request body
      if (userName) {
        updateFields.userName = userName;
      }
  
      // Check if email is provided in the request body
      if (email) {
        updateFields.email = email;
      }
  
      // Check if an image file is included in the request
      if (req.files && req.files.image) {
        // Assuming the image is uploaded and the path is saved in req.files.image.path
        console.log("checkit")
        updateFields["image.original"] = await helper.image_upload(req.files && req.files.image);
      }

      if (Object.keys(updateFields).length === 0) {
        return helper.failed(res, "Nothing to update", {});
      }
      // console.log(updateFields,'updateddd')
      // Set the updated fields
      adminData.set(updateFields);
      // Save the updated profile to the database
      await adminData.save();
  
      // Send a success response
      return helper.success(res, "Profile updated successfully", adminData);
    } catch (error) {
      console.error('Error updating user profile:', error);
      return helper.failed(res, 'Error updating user profile');
    }
  },
  async change_password(req, res) {
    try {
      const v = new Validator(req.body, {
        currentPassword: 'string|required',
        newPassword: 'string|required',
        confirmNewPassword: 'string|required|same:newPassword',
      });

      const value = JSON.parse(JSON.stringify(v));
      const errorResponse = await helper.checkValidation(v);
      console.log(errorResponse)
      if (errorResponse) {
        return helper.failed(res, errorResponse);
      }
      const { currentPassword, newPassword, confirmNewPassword } = req.body;
  
      // Retrieve the user profile data from the req.user object
      const userProfile = req.user;
      const adminData = await AdminModel.findById(userProfile._id);
  
      // Check if the current password matches the one in the database
      const isMatch = await bcrypt.compare(currentPassword, adminData.password);
      if (!isMatch) {
        return helper.failed(res, 'Invalid current password');
      }
  
      // Check if the new password and confirm new password match
      if (newPassword !== confirmNewPassword) {
        return helper.failed(res, 'New password and confirm new password do not match');
      }
  
      // Hash the new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);
  
      // Update the password in the adminData object
      adminData.password = hashedPassword;
  
      // Save the updated adminData to the database
      await adminData.save();
  
      // Send a success response
      return helper.success(res, 'Password updated successfully');
    } catch (error) {
      console.error('Error updating password:', error);
      return helper.failed(res, 'Error updating password');
    }
  },
  async  get_users(req, res) {
    try {
      const pageNo = req.query.pageNo ? parseInt(req.query.pageNo) : 1;
      const showData = 10;
      const removeData = (pageNo - 1) * showData;
      const sort = req.query.sort;
      const _id = req.query._id;
  
      if (_id) {
        // Fetch a single user by ID
        const user = await AdminModel.findById(_id);
        if (!user) {
          return helper.failed(res, "User not found.", {});
        }
        return helper.success(res, "User found.", user);
      }
  
      // Fetch multiple users
      const users = await AdminModel.find({ userRole: { $ne: 0 } })
        .sort(sort)
        .skip(removeData)
        .limit(showData);
  
      helper.success(res, "Data found.", users);
    } catch (error) {
      console.error(error.message);
      helper.failed(res, "Server error.", {});
    }
  },
  async get_bars(req, res) {
    try {
      const pageNo = req.query.pageNo ? req.query.pageNo : 1;
      const showData = 10;
      const removeData = (pageNo - 1) * showData;
      const sort = req.query.sort;
      const _id = req.query._id;
  
      if (_id) {
        // Fetch a single user by ID
        const user = await BarModel.findById(_id);
        if (!user) {
          return helper.failed(res, "bars not found.", {});
        }
        return helper.success(res, "bars found.", user);
      }
      const data = await BarModel.find({})
        .sort(sort)
        .skip(removeData)
        .limit(showData);

        helper.success(res,"Data found.",data)
    } catch (error) {
      console.error(error.message);
      helper.failed(res,"server error",error)
    }
  },
  //create sports api
  async create_sports(req, res) {
    // console.log(req.files, "checkit");
      const v = new Validator(req.body, {
        sportname: "string|required",
      });

      const value = JSON.parse(JSON.stringify(v));
      const errorResponse = await helper.checkValidation(v);
      console.log(errorResponse)
      if (errorResponse) {
        return helper.failed(res, errorResponse);
      }
    const { sportname } = req.body;

    if (!sportname) {
      return helper.failed(res, "please enter all required fields");
    }
    let logo = await helper.image_upload(req.files && req.files.logo);
    console.log(logo, "cehcit");
    try {
      let data = {
        sportname: sportname,
        logo: logo,
      };
      const sport = await SportModal.create(data);
      helper.success(res,"data found",sport)
    } catch (errors) {
      console.log(errors, "checkit");
      helper.success(res,"server error",errors)
    }
  },
  async get_sports(req, res) {
    try {
      // const pageNo = req.query.pageNo ? req.query.pageNo : 1;
      // const showData = 10;
      // const removeData = (pageNo - 1) * showData;
      // const sort = req.query.sort;
      const _id = req.query._id;
  
      if (_id) {
        // Fetch a single user by ID
        const user = await SportModal.findById(_id);
        if (!user) {
          return helper.failed(res, "sport not found.", {});
        }
        return helper.success(res, "sport found.", user);
      }
      const data = await SportModal.find({}).sort({ createdAt: -1 });

     helper.success(res,"data fetched successfully",data)
    } catch (error) {
      console.error(error.message);
      helper.failed(res,"server error",error)
    }
  },

  async update_sports(req, res) {
    try {
      const id = req.params.id;
      console.log(id, "chdfhsdg");
  
      // Check if id is a valid MongoDB ObjectId
      if (!mongoose.Types.ObjectId.isValid(id)) {
        return helper.failed(res, "id is invalid");
      }
  
      const { sportname } = req.body;
  
      // Check if the sports document already exists
      const existingSports = await SportModal.findById(id);
      if (!existingSports) {
        return helper.failed(res, "Sports not found");
      }
  
      const updateData = {};
  
      // Check if sportname is provided and different from the existing value
      if (sportname && sportname !== existingSports.sportname) {
        updateData.sportname = sportname;
      }
  
      // Check if logo file is provided
      if (req.files && req.files.logo) {
        updateData.logo = await helper.image_upload(req.files.logo);
      }
  
      // If there are no updates to be made, return an error
      if (Object.keys(updateData).length === 0) {
        return helper.failed(res, "No updates provided");
      }
  
      const updatedSports = await SportModal.findByIdAndUpdate(id, updateData, {
        new: true,
      });
  
      if (!updatedSports) {
        return helper.failed(res, "Sports not found");
      }
  
      return helper.success(res, "Sports updated successfully", updatedSports);
  
    } catch (error) {
      console.error(error);
      return helper.failed(res, "Server error", {}, 500);
    }
  },
  async delete_sports(req, res) {
    try {
      const id = req.params.id;
  
      // Check if id is a valid MongoDB ObjectId
      if (!mongoose.Types.ObjectId.isValid(id)) {
        return helper.failed(res, "id is invalid");
      }
  
      // Check if the sports document exists
      const existingSports = await SportModal.findById(id);
      if (!existingSports) {
        return helper.failed(res, "Sports not found");
      }
  
      // Delete the sports document
      await SportModal.findByIdAndRemove(id);
  
      return helper.success(res, "Sports deleted successfully");
  
    } catch (error) {
      console.error(error);
      return helper.failed(res, "Server error", {}, 500);
    }
  },
  //crud teams
  async create_team(req, res) {
    const v = new Validator(req.body, {
      teamname: "string|required",
      phone: "required",
      email: "string|required",
      country: "string|required",
      lat: "string|required",
      long: "string|required",
      address: "string|required",
      sportid: "string|required",
    });

    const value = JSON.parse(JSON.stringify(v));
    const errorResponse = await helper.checkValidation(v);
    console.log(errorResponse)
    if (errorResponse) {
      return helper.failed(res, errorResponse);
    }
    const {
      teamname,
      phone,
      email,
      country,
      lat,
      long,
      address,
      image,
      sportid,
    } = req.body;
    try {
      let data = {
        teamname: teamname,
        phone: phone,
        email: email,
        country: country,
        address: address,
        image: image,
        location: {
          type: "point",
          coordinates: [lat, long],
        },
        sports_id: sportid,
      };
      // console.log(teamName,'checkit')
      const team = await TeamModel.create(data);
      res.json({
        status_code: 1,
        msg: "Data found.",
        data: team,
      });
    } catch (errors) {
      console.log(errors, "checkit");
      res.status(500).send({
        status_code: 0,
        errors: [
          {
            msg: "Server error",
            param: "server",
            location: "body",
          },
        ],
      });
    }
  },
  async get_teams(req, res) {
    try {
      const pageNo = req.query.pageNo ? req.query.pageNo : 1;
      const showData = 10;
      const removeData = (pageNo - 1) * showData;
      const sort = req.query.sort;
      const data = await TeamModel.find({})
        .sort(sort)
        .skip(removeData)
        .limit(showData);

      res.json({
        status_code: 1,
        msg: "Data found.",
        data: data,
      });
    } catch (error) {
      console.error(error.message);
      res.status(500).send({
        status_code: 0,
        errors: [
          {
            msg: "Server error",
            param: "server",
            location: "body",
          },
        ],
      });
    }
  },
  // Update Team API
  async update_team(req, res) {
    try {
      const teamId = req.params.id;
      // console.log(teamId,)
      if (!mongoose.Types.ObjectId.isValid(teamId)) {
        return helper.failed(res, "Invalid team ID");
      }

      const {
        teamname,
        phone,
        email,
        country,
        lat,
        long,
        address,
        image,
        sportid,
      } = req.body;

      // Check if the team document already exists
      const existingTeam = await TeamModel.findById(teamId);
      if (!existingTeam) {
        return helper.failed(res, "Team not found");
      }

      // Update team data
      existingTeam.teamname = teamname;
      existingTeam.phone = phone;
      existingTeam.email = email;
      existingTeam.country = country;
      existingTeam.address = address;
      existingTeam.image = image;
      existingTeam.location = {
        type: "point",
        coordinates: [lat, long],
      };
      existingTeam.sportid = sportid;

      // Save the updated team
      const updatedTeam = await existingTeam.save();

      return helper.success(res, "Team updated successfully", updatedTeam);
    } catch (error) {
      console.log(error, "checkit");
      return helper.failed(res, "Server error", {}, 500);
    }
  },
  // Delete Team API
  async delete_team(req, res) {
    try {
      const teamId = req.params.id;
      if (!mongoose.Types.ObjectId.isValid(teamId)) {
        return helper.failed(res, "Invalid team ID");
      }

      // Delete the team
      const deletedTeam = await TeamModel.findByIdAndDelete(teamId);
      
      if (!deletedTeam) {
        return helper.failed(res, "Team not found");
      }

      return helper.success(res, "Team deleted successfully");
    } catch (error) {
      console.log(error, "checkit");
      return helper.failed(res, "Server error", {}, 500);
    }
  },
  async bar_offers(req,res){
    try {
      const v = new Validator(req.body, {
        title: "string|required",
        description: "string|required",
        discount: "string|required",
        barDetail:"string|required",
      });
  
      const value = JSON.parse(JSON.stringify(v));
      const errorResponse = await helper.checkValidation(v);
      console.log(errorResponse)
      if (errorResponse) {
        return helper.failed(res, errorResponse);
      }
      const { title, description, discount,barDetail} = req.body;
  
      // Create a new bar offer document
      const newOffer = new BarOfferModal({
        title,
        description,
        discount,
        barDetail
      });
  
      // Save the new offer to the database
      const createdOffer = await newOffer.save();
  
      return helper.success(res, createdOffer);
    } catch (error) {
      console.error('Error creating bar offer:', error);
      return helper.failed(res, 'Error creating bar offer');
    }
  },
  async getbars_with_offers(req, res){
    try {
      // Retrieve all bars with their associated offers
      const barsWithOffers = await BarOfferModal.find().populate('barDetail');
      
      return helper.success(res,"Bar with offers fethed successfully", barsWithOffers);
    } catch (error) {
      console.error('Error retrieving bars with offers:', error);
      return helper.failed(res, 'Error retrieving bars with offers');
    }
  },
  async total_count(req, res) {
    try {
      const usersCount = await AdminModel.countDocuments();
      const barsCount = await BarModel.countDocuments();
      const teamsCount = await TeamModel.countDocuments();
      const sportsCount = await SportModal.countDocuments();
  
      return helper.success(res,"total records fetched successfully" ,{
        total_users: usersCount,
        total_bars: barsCount,
        total_teams: teamsCount,
        total_sports: sportsCount
      });
    } catch (error) {
      console.error('Error retrieving counts:', error);
      return helper.failed(res, 'Error retrieving counts');
    }
  },
  async cms(req, res) {
    try {
      const cmsData = await CmsModal.find();
      return helper.success(res, "CMS data retrieved successfully", cmsData);
    } catch (error) {
      console.error('Error retrieving CMS data:', error);
      return helper.failed(res, 'Error retrieving CMS data');
    }
  },
  async update_cms(req, res) {
    try {
      const { id } = req.params; // Retrieve the id parameter from the URL
      const updateFields = req.body;
      if (Object.keys(updateFields).length === 0) {
        // If req.body is empty, return a failure response
        return helper.failed(res, "No fields provided to update");
      }
  
      if (!mongoose.Types.ObjectId.isValid(id)) {
        return helper.failed(res, "Invalid team ID");
      }
  
      // Find the CMS document by ID
      const cms = await CmsModal.findById(id);
  
      if (!cms) {
        return helper.failed(res, "CMS not found", {},);
      }
  
      // Update the fields with the new values
      Object.assign(cms, updateFields);
      // Save the updated CMS document
      const updatedCms = await cms.save();
      return helper.success(res, "CMS updated successfully", updatedCms);
    } catch (error) {
      console.error('Error updating CMS:', error);
      return helper.failed(res, 'Error updating CMS');
    }
  },
  async delete_cms(req, res) {
    try {
      const { id } = req.params; // Retrieve the id parameter from the URL
      if (!mongoose.Types.ObjectId.isValid(id)) {
        return helper.failed(res, "Invalid team ID");
      }
      // Find the CMS document by ID
      const cms = await CmsModal.findById(id);
      if (!cms) {
        return helper.failed(res, "CMS not found", {});
      }
  
      // Delete the CMS document
      await cms.remove();
  
      return helper.success(res, "CMS deleted successfully", {});
    } catch (error) {
      console.error('Error deleting CMS:', error);
      return helper.failed(res, 'Error deleting CMS');
    }
  }
};

const { Validator } = require("node-input-validator");
const Model = require("../../../models");
const nodemailer = require("nodemailer");

var path = require("path");
//olf
// const accountSid = "AC0529f69727c01e97150a1c0b64f1a222";
//new
const accountSid = "ACbb3ae65253592d714b2afb516523bf3d";
// old
// const authToken = "10592aa023ef5198d90a66821f1cdf0a";
//new
const authToken = "edcd3c698147eba010a4a9976fefdb46";

const client = require("twilio")(accountSid, authToken);
const sendResponse = require("../../sendResponse.js");
const APP_CONSTANTS = require("../../../config/appConstants.js");
const RESPONSE_MESSAGES = require("../../../config/response-messages.js");
const bcrypt = require("bcrypt");
var mongoose = require("mongoose");
const SECRET = "huffduff@1234234321jdh()*()";
const {
  checkValidation,
  error,
  failed,
  file_uploads,
  success,
  sendNotification,
} = require("../../../config/helper");
const { decryptPass, encryptPass } = require("../../../utils/crypto");
const Constants = require("../../../config/appConstants");
const models = require("../../../models");
const { model } = require("mongoose");
const jwt = require("jsonwebtoken");
const helpers = require("../../../config/helper");
const { json } = require("body-parser");
const { db, findById, findByIdAndUpdate } = require("../../../models/Users");
const { required } = require("joi/lib/types/lazy");
const { read } = require("fs-extra");
const helper = require("../../../config/helper");
const ObjectId = require("mongoose").Types.ObjectId;
const nodeCron = require("node-cron");
const { v4: uuidv4 } = require("uuid");

module.exports = {
  signup: async (req, res) => {
    try {
      // type 0 for email  /// type 1 phone number
      const v = new Validator(req.body, {
        firstName: "string|required",
        lastName: "string",
        userName: "string|required",
        countryCode: "string|required",
        email: "string|required|email",
        password: "string|required",
        confirmPassword: "string|required|same:password",
        phone: "required",
        type: "required|integer",
      });
      const value = JSON.parse(JSON.stringify(v));

      const errorResponse = await checkValidation(v);
      if (errorResponse) {
        return failed(res, errorResponse);
      }

      const userExist = await Model.Users.findOne({
        email: value.inputs.email,
      });
      if (userExist) {
        return failed(res, "Email Already Exist");
      }

      const phone_find = await Model.Users.findOne({
        phone: value.inputs.phone,
      });
      if (phone_find) {
        return failed(res, "Phone Number Already Exist");
      }

      var otp = Math.floor(1000 + Math.random() * 9000);

      const hashPassword = await bcrypt.hash(req.body.password, 12);
      req.body.password = hashPassword;

      req.body.image = await helpers.image_upload(req.files && req.files.image);

      let dataObj = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        userName: req.body.userName,
        countryCode: req.body.countryCode,
        email: req.body.email,
        password: req.body.password,
        confirmPassword: req.body.confirmPassword,
        phone: req.body.phone,
        type: req.body.type,
        deviceToken: req.body.deviceToken,
        deviceType: req.body.deviceType,
        otp: otp,
        image: {
          thumbnail: "",
          original: req.body.image,
        },
        location: {
          type: "Point",
          coordinates: [],
        },
      };
      let user = {};
      // console.log(req.body.type,'chekit')
      // console.log(data,'cehck')
      user = await Model.Users.create(dataObj);
      let token = jwt.sign({ id: user._id }, Constants.SERVER.JWT_SECRET_KEY, {
        expiresIn: Constants.SERVER.TOKEN_EXPIRATION,
      });

      let type = req.body.type;
      console.log(type, "checkit");
      if (type == 1) {
        // console.log("type 1 is here")
        const v = new Validator(req.body, {
          phone: "string|required",
        });
        const value = JSON.parse(JSON.stringify(v));
        const errorResponse = await checkValidation(v);
        if (errorResponse) {
          return failed(res, errorResponse);
        }

        const data = await Model.Users.findOne({
          phone: req.body.phone,
        }).select("phone");
        console.log(data);
        if (!data) {
          return failed(res, "User not found");
        }
        var otp = dataObj.otp;
        var otps = await Model.Users.updateOne(
          { phone: req.body.phone },
          {
            $set: {
              otp: otp,
              is_verify: 0,
              type: 1,
            },
          }
        );
        const messageBody = `Hello! Thank you for signing up. Your OTP (One-Time Password) is: ${otp}. Please enter this code to verify your account.`;

        client.messages
          .create({
            body: messageBody,
            from: "+18883017193", // Twilio phone number
            to: req.body.phone, // Phone number to send the message
          })
          .then((message) => console.log(message.sid))
          .catch((error) => console.error(error));
      }
      if (type == 0) {
        // console.log(req.user.id, '=-=-=-=-=-=-=-')
        const v = new Validator(req.body, {
          email: "string|required|email",
        });
        const value = JSON.parse(JSON.stringify(v));
        const errorResponse = await checkValidation(v);
        if (errorResponse) {
          return failed(res, errorResponse);
        }
        console.log("hello world");
        const data = await Model.Users.findOne({
          email: req.body.email,
        }).select("email");
        console.log(data);
        if (!data) {
          return failed(res, "User not found");
        }
        // var otp = Math.floor(Math.random() * 1000000 + 1);
        var otp = dataObj.otp;
        var otps = await Model.Users.updateOne(
          { email: req.body.email },
          {
            $set: {
              otp: otp,
              is_verify: 0,
              type: 0,
            },
          }
        );

        var transporter = nodemailer.createTransport({
          host: "smtp.office365.com",
          port: 587,
          auth: {
            user: "hello@huffduff.app",
            pass: "JWDjws3e#decx",
          },
        });

        // Generate the OTP
        let info = await transporter.sendMail({
          from: "hello@huffduff.app", // sender address
          to: req.body.email, // list of receivers
          subject: "Welcome to Huff Duff ✔", // Subject line
          text: `Hello,\n\nThank you for signing up for Huff Duff! Your account has been successfully created.\n\nYour OTP for verification is: ${otp}\n\nWe are excited to have you on board. If you have any questions or need assistance, feel free to reach out to our support team.\n\nThank you,\nThe Huff Duff Team`, // plain text body
          html: `<p>Hello,</p><p>Thank you for signing up for Huff Duff! Your account has been successfully created.</p><p>Your OTP for verification is: <strong>${otp}</strong></p><p>We are excited to have you on board. If you have any questions or need assistance, feel free to reach out to our support team.</p><p>Thank you,</p><p>The Huff Duff Team</p>`, // html body
        });

        // console.log(info,'chek')
      }

      const newUser = await Model.Users.findByIdAndUpdate(
        user._id,
        { accessToken: token },
        { new: true }
      );

      let resData = {
        user,
        accessToken: token,
      };

      if (user) {
        return success(res, "Signup Successfull", resData);
      }
    } catch (err) {
      console.log(err, "error");
      return error(res, err.message);
    }
  },

  login: async (req, res) => {
    try {
      const v = new Validator(req.body, {
        //    email: "string|email",
        password: "string|required",
        // phone: "string",
        email: "string",
      });

      const value = JSON.parse(JSON.stringify(v));

      const errorResponse = await checkValidation(v);
      if (errorResponse) {
        return failed(res, errorResponse);
      }
      const userExist = await Model.Users.findOne({
        $or: [{ email: req.body.email }, { phone: req.body.email }],
      });

      if (userExist) {
        if (userExist.is_verify == 0) {
          return res.status(202).json({
            success: false,
            code: 202,
            message: "please verify the otp first then login",
            body: { userExist },
          });
        }

        const match = await bcrypt.compare(
          req.body.password,
          userExist.password
        );

        let userdata = {
          id: userExist._id,
          email: userExist.email,
        };
        if (match) {
          let token = jwt.sign(userdata, Constants.SERVER.JWT_SECRET_KEY, {
            expiresIn: Constants.SERVER.TOKEN_EXPIRATION,
          });

          Model.Users.updateOne(
            { _id: userExist._id },
            {
              accessToken: token,
              deviceToken: req.body.deviceToken,
              deviceType: req.body.deviceType,
            },
            function (err, result) {}
          );
          userExist.accessToken = token;
          return success(res, "Login Successfull", userExist);
        } else {
          return failed(res, "Password does not match", {});
        }
      }
      // }
      // if (phone = req.body.phone) {
      //     console.log(phone);
      //     const userExist1 = await Model.Users.findOne({ phone: req.body.phone })

      //     if (userExist1.is_verify == 0) {
      //         return res.status(202).json({
      //             success: false,
      //             code: 202,
      //             message: "please verify the otp first then login",
      //             body: { userExist1 },

      //         })
      //     }

      //     if (userExist1) {

      //         const match = await bcrypt.compare(req.body.password, userExist1.password)

      //         let userdata = {
      //             id: userExist1._id,
      //             email: userExist1.email
      //         }
      //         if (match) {
      //             let token = jwt.sign(userdata, Constants.SERVER.JWT_SECRET_KEY, {
      //                 expiresIn: Constants.SERVER.TOKEN_EXPIRATION
      //             });

      //             Model.Users.updateOne({ "_id": userExist1._id }, { "accessToken": token }, function (err, result) { })
      //             userExist1.accessToken = token
      //             return success(res, "Login Successfull", userExist1);
      //         } else {
      //             return failed(res, "Password does not match", {})
      //         }
      //     }
      // }
      else {
        return failed(res, "User does not match", {});
      }
    } catch (err) {
      return error(res, err.message);
    }
  },

  change_password: async (req, res) => {
    try {
      console.log(req.user.id, "=-=-=-=-=-=-=-");

      let data = await Model.Users.findOne({ _id: req.user.id });

      let match = await bcrypt.compare(req.body.password, data.password);

      if (match) {
        const salt = bcrypt.genSaltSync(12);
        let hash = bcrypt.hashSync(req.body.new_password, salt);

        if (req.body.confirm_Password == req.body.new_password) {
          let updatepassword = await Model.Users.updateOne(
            { _id: req.user.id },
            {
              password: hash,
            }
          );
          return success(res, "passowrd update Successfull", data);
        } else {
          return failed(res, "password does not same", {});
        }
      } else {
        return failed(res, "password does not match to old password", {});
      }
    } catch (err) {
      console.log(err, "error");
      return error(res, err.message);
    }
  },

  sociallogin: async (req, res) => {
    try {
      const socialType = req.body.socialType;
      const v = new Validator(req.body, {
        socialType: "required",
        email: socialType == 2 ? "string" : "required|email",
        socialId: "required",
        userName: socialType == 2 ? "string" : "required|string",
        deviceType: "required",
        deviceToken: "required",
      });

      let errorsResponse = await helper.checkValidation(v);

      if (errorsResponse) {
        return await helper.failed(res, errorsResponse);
      }

      // let socialdata = await Model.Users.findOne({ email: req.body.email});
      let socialdata = await Model.Users.findOne({
        socialId: req.body.socialId,
      });
      // console.log(socialIddata,"HHHHHHHHHHHHHHHHHHHHHH");return
      console.log(socialdata, "Login Suucessfully");
      let time = helper.unixTimestamp();
      if (socialdata) {
        const v = new Validator(req.body, {
          socialId: "required",
        });

        let errorsResponse = await helper.checkValidation(v);

        if (errorsResponse) {
          return await helper.failed(res, errorsResponse);
        }
        await Model.Users.updateOne(
          { _id: socialdata._id },
          {
            deviceType: req.body.deviceType,
            deviceToken: req.body.deviceToken,
            loginTime: time,
          }
        );

        let userdata = await Model.Users.findOne({ _id: socialdata._id });
        let token = jwt.sign(
          { id: userdata._id },
          Constants.SERVER.JWT_SECRET_KEY,
          {
            expiresIn: Constants.SERVER.TOKEN_EXPIRATION,
          }
        );
        // console.log(token,'checkout')
        userdata = JSON.parse(JSON.stringify(userdata));
        userdata.token = token;

        return helper.success(res, " Login Successfully 2 ", userdata);
      }

      if (!socialdata) {
        req.body.imageSocial = await helpers.image_upload(
          req.files && req.files.image
        );

        let time = helper.unixTimestamp();
        let create_user = await Model.Users.create({
          userName: req.body.userName,
          email: req.body.email,
          password: req.body.password,
          phone: req.body.phone || "",
          image: {
            thumbnail: "",
            original: req.body.imageSocial,
          },
          city: req.body.city,
          countryCode: req.body.countryCode || "",
          deviceType: req.body.deviceType,
          deviceToken: req.body.deviceToken,
          socialType: req.body.socialType || "",
          socialId: req.body.socialId || "",
          bio: req.body.bio,
          loginTime: time,
          userType: 1,
          otp: 1111,
          location: {
            type: "path",
            coordinates: [
              parseFloat(req.body.longitude || 0.0),
              parseFloat(req.body.latitude || 0.0),
            ],
            name: req.body.locationName || "",
          },
        });
        //  let social_Data = await users.findByIdAndUpdate({_id:create_user.id});

        console.log("Hello  is okey 1");

        let get_social_data_user = await Model.Users.findOne({
          _id: create_user._id,
        });
        console.log(get_social_data_user, "<<<<<<<<<social data here");

        let token = jwt.sign(
          { id: get_social_data_user._id },
          Constants.SERVER.JWT_SECRET_KEY,
          {
            expiresIn: Constants.SERVER.TOKEN_EXPIRATION,
          }
        );

        // console.log(token,'token is here')
        // let token = jwt.sign({
        //     data: {
        //         _id: get_social_data_user._id,
        //         loginTime: get_social_data_user.loginTime,
        //     }
        // },SECRET);

        get_social_data_user = JSON.parse(JSON.stringify(get_social_data_user));

        get_social_data_user.token = token;
        // delete get_social_data_user.location

        get_social_data_user.status = {
          isRegisterd: 1,
          // isOtpVerifired : get_social_data_user.otp ? 0:1,
          isProfileCompleted: get_social_data_user.description ? 1 : 0,
        };

        return helper.success(
          res,
          "social login  Successfully",
          get_social_data_user
        );

        // return helper.success(res, " Login Successfully ", get_social_data_user)
      }
    } catch (error) {
      console.log(error);
    }
  },

  online_user_in_group: async (req, res) => {
    if (!req.user) return error(res, "unauthenticate");
    const v = new Validator(req.query, {
      group_id: "required",
    });
    v.check().then((match) => {
      if (!match) {
        return res.status(422).send(v.errors);
      }
    });

    // Find the group by its ID
    const onlineMembers = await Model.Group.aggregate([
      { $match: { _id: ObjectId(req.query.group_id) } }, // Match the specific group based on the groupId
      { $unwind: "$members" }, // Unwind the members array
      { $match: { "members.onlineStatus": 1 } }, // Filter for members with onlineStatus 1
      {
        $lookup: {
          from: "users", // Replace "users" with the actual name of the users collection
          localField: "members.user_id",
          foreignField: "_id",
          as: "userDetails",
        },
      },
      {
        $project: {
          "members.user_id": 1, // Include specific fields from the members array
          "members.onlineStatus": 1,
          "members.destination_location": 1,
          "userDetails.userName": 1, // Include specific fields from the userDetails array
          "userDetails.email": 1,
          "userDetails.location": 1,
          "userDetails.image": 1,
          "userDetails.phone": 1,
          // Add more fields as needed
        },
      },
    ]);

    if (!onlineMembers) {
      return error(res, "group not found");
    }
    onlineMembers.forEach((val) => {
      // console.log(val.userDetails[0],'sdfhds')
      val.memberDetail = val.members;
      val.members.start_track = val.members.destination_location;
      val.members.userData = val.userDetails[0];
      delete val.userDetails;
      // delete val.userDetails[0];
      delete val.members?.destination_location;
      delete val.members;
    });
    // The onlineMembers array now contains the group members with online status 1
    // console.log(onlineMembers);
    return success(res, "Online members fetch successfully", onlineMembers);
  },

  logout: async (req, res) => {
    try {
      console.log(req.user.id, "=-=-=-=-=-=-=-");
      const data = await Model.Users.updateOne(
        { _id: req.user.id },
        {
          $set: {
            accessToken: "",
            deviceToken: "",
          },
        }
      );
      if (data) {
        return success(res, "Logout Successfully");
      } else {
        res.status(400);
        throw new Error("User not Found");
      }
    } catch (err) {
      console.log(err);
      return error(res, err.message);
    }
  },

  forgetpassword: async (req, res) => {
    try {
      const v = new Validator(req.body, {
        type: "required",
      });
      v.check().then((match) => {
        if (!match) {
          return res.status(422).send(v.errors);
        }
      });

      if (req.body.type == 1) {
        const v = new Validator(req.body, {
          phone: "string|required",
        });
        const value = JSON.parse(JSON.stringify(v));
        const errorResponse = await checkValidation(v);
        if (errorResponse) {
          return failed(res, errorResponse);
        }

        const data = await Model.Users.findOne({
          phone: req.body.phone,
        }).select("phone");
        console.log(data);
        if (!data) {
          return failed(res, "User not found");
        }
        var otp = Math.floor(1000 + Math.random() * 9000);
        var otps = await Model.Users.updateOne(
          { phone: req.body.phone },
          {
            $set: {
              otp: otp,
              is_verify: 0,
            },
          }
        );

        const messageBody = `Hello! You have requested a password reset. Your OTP (One-Time Password) is: ${otp}. Please enter this code to reset your password.`;
        client.messages
          .create({
            body: messageBody,
            from: "+18883017193", // Twilio phone number
            to: req.body.phone, // Phone number to send the message
          })
          .then((message) => console.log(message.sid))
          .catch((error) => console.error(error));
        return success(res, "otp sent successfully at your mobile", { otp });
      }

      if (req.body.type == 0) {
        // console.log(req.user.id, '=-=-=-=-=-=-=-')
        const v = new Validator(req.body, {
          email: "string|required|email",
        });
        const value = JSON.parse(JSON.stringify(v));
        const errorResponse = await checkValidation(v);
        if (errorResponse) {
          return failed(res, errorResponse);
        }
        const data = await Model.Users.findOne({
          email: req.body.email,
        }).select("email");
        console.log(data);
        if (!data) {
          return failed(res, "User not found");
        }
        // var otp = Math.floor(Math.random() * 1000000 + 1);
        var otp = Math.floor(1000 + Math.random() * 9000);

        var otps = await Model.Users.updateOne(
          { email: req.body.email },
          {
            $set: {
              otp: otp,
              is_verify: 0,
            },
          }
        );

        var transporter = nodemailer.createTransport({
          host: "smtp.office365.com",
          port: 587,
          auth: {
            user: "hello@huffduff.app",
            pass: "JWDjws3e#decx",
          },
        });

        let info = await transporter.sendMail({
          from: "hello@huffduff.app", // sender address
          to: req.body.email, // list of receivers
          subject: "Reset Password ✔", // Subject line
          text: `Hello,\n\nYou have requested to reset your password for your Huff Duff account. Please use the following OTP to proceed:\n\nOTP: ${otp}\n\nIf you did not make this request, you can safely ignore this email.\n\nThank you,\nThe Huff Duff Team`, // plain text body
          html: `<p>Hello,</p><p>You have requested to reset your password for your Huff Duff account. Please use the following OTP to proceed:</p><p><strong>OTP: ${otp}</strong></p><p>If you did not make this request, you can safely ignore this email.</p><p>Thank you,</p><p>The Huff Duff Team</p>`, // html body
        });

        return success(res, "otp sent successfully at your Email", { otp });
      }
    } catch (err) {
      console.log(err);
      return error(res, err.message);
    }
  },

  verify_otp: async (req, res) => {
    try {
      const v = new Validator(req.body, {
        otp: "required",
        email: "required",
      });
      const errorResponse = await checkValidation(v);
      if (errorResponse) {
        return failed(res, errorResponse);
      }

      let data = await Model.Users.findOne({ email: req.body.email });

      if (data.otp == req.body.otp) {
        data.is_verify = 1;
        data.otp = 0;
        data.save();
        return success(res, "otp Matched'", data);
      } else {
        return failed(res, "wrong otp");
      }
    } catch (err) {
      console.log(err, "error");
      return error(res, err.message);
    }
  },

  verify_otp_number: async (req, res) => {
    try {
      // console.log(req.body,"=================");
      // return
      const v = new Validator(req.body, {
        otp: "required",
        phone: "required",
      });
      const errorResponse = await checkValidation(v);
      if (errorResponse) {
        return failed(res, errorResponse);
      }
      let data = await Model.Users.findOne({ phone: req.body.phone });
      // console.log('=dddddddddddddddddddddddddddd',data)
      // return
      if (data.otp == req.body.otp) {
        data.is_verify = 1;
        data.otp = 0;
        data.save();
        return success(res, "otp Matched'", data);
      } else {
        return failed(res, "wrong otp");
      }
    } catch (err) {
      console.log(err, "error");
      return error(res, err.message);
    }
  },
  resend_otp_number: async (req, res) => {
    try {
      const data = await Model.Users.findOne({ phone: req.body.phone }).select(
        "phone"
      );
      console.log(data);
      if (!data) {
        return failed(res, "User not found");
      }
      var otp = Math.floor(1000 + Math.random() * 9000);
      var otps = await Model.Users.updateOne(
        { phone: req.body.phone },
        {
          $set: {
            otp: otp,
            is_verify: 0,
          },
        }
      );
      const messageBody = `Hello! Here's your new OTP (One-Time Password): ${otp}. Please use this code to proceed.`;

      client.messages
        .create({
          body: messageBody,
          from: "+18883017193", // Twilio phone number
          to: req.body.phone, // Phone number to send the message
        })
        .then((message) => console.log(message.sid))
        .catch((error) => console.error(error));
      return success(res, "otp sent successfully at your mobile", {});
    } catch (err) {
      console.log(err, "error");
      return error(res, err.message);
    }
  },

  resend_otp: async (req, res) => {
    try {
      // console.log(req.user.id, '=-=-=-=-=-=-=-')
      const data = await Model.Users.findOne({ email: req.body.email }).select(
        "email"
      );
      console.log(data);
      if (!data) {
        return failed(res, "User not found");
      }
      // var otp = Math.floor(Math.random()* 1000000 + 1);
      var otp = Math.floor(1000 + Math.random() * 9000);
      var otp1 = await Model.Users.updateOne(
        { email: req.body.email },
        {
          otp: otp,
          is_verify: 0,
        }
      );
      var transporter = nodemailer.createTransport({
        host: "smtp.office365.com",
        port: 587,
        auth: {
          user: "hello@huffduff.app",
          pass: "JWDjws3e#decx",
        },
      });

      let info = await transporter.sendMail({
        from: "hello@huffduff.app", // sender address
        to: req.body.email, // list of receivers
        subject: "OTP Resent ✔", // Subject line
        text: `Hello Huff Duff User,\n\nThis is a confirmation that your OTP has been resent. Please use the following OTP to proceed:\n\nOTP: ${otp}\n\nThank you,\nThe Huff Duff Team`, // plain text body
        html: `<p>Hello Huff Duff User,</p><p>This is a confirmation that your OTP has been resent. Please use the following OTP to proceed:</p><p><strong>OTP: ${otp}</strong></p><p>Thank you,</p><p>The Huff Duff Team</p>`, // html body
      });
      return success(res, "otp resend successfully", {});
    } catch (err) {
      console.log(err, "error");
      return error(res, err.message);
    }
  },

  NewPassword: async (req, res) => {
    try {
      if (req.body.type == 0) {
        // console.log(req.user.id, '=-=-=-=-=-=-=-')
        const v = new Validator(req.body, {
          newPassword: "required|string",
          email: "required",
          // confirmPassword: "required|string|same:newPassword",
        });
        const value = JSON.parse(JSON.stringify(v));

        const errorResponse = await checkValidation(v);
        if (errorResponse) {
          return failed(res, errorResponse);
        }

        let hashPassword = await bcrypt.hash(req.body.newPassword, 12);

        const user = await Model.Users.findOne({ email: req.body.email });

        if (user) {
          let token = jwt.sign(
            { id: user._id },
            Constants.SERVER.JWT_SECRET_KEY,
            {
              expiresIn: Constants.SERVER.TOKEN_EXPIRATION,
            }
          );
          user.accessToken = token;
          user.password = hashPassword;
          user.save();
        }
        return success(res, "NewPassword updated by email successfully", user);
      }
      if (req.body.type == 1) {
        const v = new Validator(req.body, {
          newPassword: "required|string",
          phone: "required",
          // confirmPassword: "required|string|same:newPassword",
        });
        const value = JSON.parse(JSON.stringify(v));

        const errorResponse = await checkValidation(v);
        if (errorResponse) {
          return failed(res, errorResponse);
        }

        let hashPassword = await bcrypt.hash(req.body.newPassword, 12);

        const user = await Model.Users.findOne({ phone: req.body.phone });

        if (user) {
          let token = jwt.sign(
            { id: user._id },
            Constants.SERVER.JWT_SECRET_KEY,
            {
              expiresIn: Constants.SERVER.TOKEN_EXPIRATION,
            }
          );
          user.accessToken = token;
          user.password = hashPassword;
          user.save();
        }
        return success(res, "NewPassword updated by phone successfully", user);
      }
    } catch (err) {
      console.log(err, "error");
      return error(res, err.message);
    }
  },
  //new profile updated api
  //  profileUpdated: async (req, res) => {
  //   try {
  //     const userId = req.user.id;
  //     const { userName, address, latitude, longitude, phone, countryCode } = req.body;

  //     const v = new Validator(req.body, {
  //       userName: "required",
  //     });

  //     const validationErrors = await checkValidation(v);
  //     if (validationErrors) {
  //       return failed(res, validationErrors);
  //     }

  //     const data = await Model.Users.findById(userId);
  //     console.log(data.phone,'cc')
  //     if(data.phone===phone){
  //       return res.status(400).json({ error: "Phone number already taken" });
  //     }
  //     let image = data.image.original;

  //     if (data && req.files && req.files.image) {
  //       image = await helpers.image_upload(req.files.image);
  //     }
  //      const updatedFields ={}

  //      updatedFields.userName =userName;
  //      updatedFields.image= {
  //         original: image,
  //         thumbnail: "",
  //       };
  //       updatedFields.address=address,
  //       updatedFields.location= {
  //         type: "Point",
  //         coordinates: [parseFloat(longitude)||0, parseFloat(latitude)||0],
  //       }
  //     if(data.socialType && phone) {
  //       updatedFields.phone = phone;
  //       updatedFields.countryCode = countryCode;
  //     }

  //     // console.log(updatedFields,'checkit')
  //     //  await Model.Users.findByIdAndUpdate({ _id: userId }, { $set: updatedFields });
  //     data.set(updatedFields);
  //     data.save();

  //     return success(res, "Profile Updated Successfully", {});
  //   } catch (error) {
  //     console.log(error, "error");
  //     return failed(res, error.message);
  //   }
  // },
  //old api
  profileUpdated: async (req, res) => {
    try {
      let id = req.user.id;
      const v = new Validator(req.body, {
        userName: "required",
        address: "required",
        latitude: "required",
        longitude: "required",
        address: "required",
      });
      const value = JSON.parse(JSON.stringify(v));

      const errorResponse = await checkValidation(v);
      if (errorResponse) {
        return failed(res, errorResponse);
      }

      let phonexist = await Model.Users.findOne({
        phone: req.body.phone,
      });

      if (phonexist) {
        // a user with this phone number already exists
        res.status(400).json({ error: "Phone number already taken" });
      }

      let data = await Model.Users.findById({ _id: id });

      let image;

      if (data && req.files && req.files.image) {
        image = await helpers.image_upload(req.files && req.files.image);
      } else {
        image = data.image.original;
      }
      //  ifdata.socialType,'chekdata')
      console.log(data);
      // return;
      if (data?.socialType && req.body.phone) {
        // If the user has a socialType and the request body contains a phone field, update the phone field as well
        await Model.Users.findByIdAndUpdate(
          { _id: id },
          {
            $set: {
              userName: req.body.userName,
              image: {
                original: image,
                thumbnail: "",
              },
              address: req.body.address,
              location: {
                type: "Point",
                coordinates: [
                  parseFloat(req.body.longitude),
                  parseFloat(req.body.latitude),
                ],
              },
              phone: req.body.phone,
              countryCode: req.body.countryCode,
            },
          }
        );
        return success(res, "Profile Updated Successfully", {});
      } else {
        // Otherwise, update only the fields specified in the original code
        await Model.Users.findByIdAndUpdate(
          { _id: id },
          {
            $set: {
              userName: req.body.userName,
              image: {
                original: image,
                thumbnail: "",
              },
              address: req.body.address,
              location: {
                type: "Point",
                coordinates: [
                  parseFloat(req.body.longitude),
                  parseFloat(req.body.latitude),
                ],
              },
            },
          }
        );
        return success(res, "Profile Updated Successfully", {});
      }
    } catch (err) {
      console.log(err, "error");
      return error(res, err.message);
    }
  },

  notificationStatus: async (req, res) => {
    try {
      const status = await Model.Users.findOneAndUpdate(
        { _id: req.user._id },
        {
          status: req.body.status,
        }
      );

      return success(res, "Notification Successfully Updated", status);
    } catch (error) {
      res.status(400).send(error.message);
    }
  },

  getNotificationList: async (req, res) => {
    try {
      // const status = 1; // Desired status value
      const ObjectId = mongoose.Types.ObjectId;
      const notifications = await Model.Notification.find({
        receiver_id: ObjectId(req.user._id),
      })
  
      return success(res, "Notification List", notifications);
    } catch (error) {
      console.log(error,'checi')
      return error(res, error.message);
    }
  },
  acceptgroupinvite: async (req, res) => { 
    try {
      const v = new Validator(req.body, {
        group_id: "required",
        user_id: "required",
        type: "required",
      });

      const errorResponse = await checkValidation(v);
      if (errorResponse) {
        return failed(res, errorResponse);
      }
      //Send Notifications to other users except this user
      let group = await Model.Group.findById(req.body.group_id).populate(
        "members.user_id"
      );
      let user = await Model.Users.findOne({ _id: req.body.user_id });

      let idarrwthoutuserwhoaccepted = [];

      let notificationmsg =
        req.body.type == 1
          ? `User ${user.userName} Accepted the group invite for group ${group.group_name}`
          : `User ${user.userName} Rejected the group invite for group ${group.group_name}`;
      if (req.body.type == 1) {
        let groupInvite = await Model.Group.updateOne(
          // $elemMatch finds docs containing an array with a matching element
          {
            _id: req.body.group_id,
            members: {
              $elemMatch: { user_id: req.body.user_id, is_admin: false },
            },
          },

          // Positional operator $ is a placeholder for the first matching array element
          {
            $set: { "members.$.status": 1 },
          }
        );
        group.members.map((member) => {
          if (member.user_id && member.user_id._id) {
            let o = {};
            o.receiver_id = member.user_id._id;
            o.group_id = group._id;
            o.type = 2;
            o.deviceToken = member.user_id.deviceToken;
            o.notification = notificationmsg;
            if (member.is_admin === true) {
              idarrwthoutuserwhoaccepted.push(o);
              sendNotification(o.deviceToken, notificationmsg);
            }
          }
        });
        await Model.Notification.insertMany(idarrwthoutuserwhoaccepted);
      } else {
        await Model.Group.updateOne(
          { _id: req.body.group_id },
          {
            $pull: {
              members: { user_id: req.body.user_id },
            },
          }
        );
        group.members.map((member) => {
          if (member.user_id && member.user_id._id) {
            if (member.is_admin === true) {
              sendNotification(member.user_id.deviceToken, notificationmsg);
            }
          }
        });
      }
      //remove accept reject notification from DB
      await Model.Notification.deleteOne({
        group_id: req.body.group_id,
        receiver_id: req.body.user_id,
        type: 1,
      });

      if (req.body.type == 1) {
        return success(res, "Group Invite Accepted Successfully ", group);
      } else {
        return success(res, "Group Invite Rejected", group);
      }
    } catch (error) {
      res.status(400).send(error.message);
    }
  },

  getPages: async (req, res) => {
    try {
      const { page } = req.params;
      condition = {};
      if (page == 1) {
        condition = { accessor: "terms-conditions" };
      } else if (page == 2) {
        condition = { accessor: "privacy-policy" };
      } else if (page == 3) {
        condition = { accessor: "cookies" };
      }

      let content = await Model.Pages.findOne(condition);
      return success(res, "Get data successfully", content);
    } catch (error) {
      console.log(error);
    }
  },
  getAllPages: async (req, res) => {
    try {
      let content = await Model.Pages.find({});
      return success(res, "Get data successfully", content);
    } catch (error) {
      console.log(error);
    }
  },
  createPage: async (req, res) => {
    try {
      const { accessor, title, content } = req.body;

      // Create a new page document
      const newPage = new Model.Pages({
        accessor: accessor,
        title: title,
        content: content,
      });

      // Save the new page to the database
      await newPage.save();

      return success(res, "Page created successfully", newPage);
    } catch (error) {
      console.log(error);
      return failed(res, "Failed to create page");
    }
  },

  getdetail: async (req, res) => {
    console.log("i am working");
    try {
      // console.log(req.body, '=-=-=-=-=-=-=-')
      const get = await Model.Users.findById({ _id: req.body.id });
      console.log(get, "checkit");
      if (get) {
        return success(res, "get details succesfully", get);
      } else {
        return failed(res, "user not found", {});
      }
    } catch (error) {
      res.status(400).send(error.message);
    }
  },

  group_create: async (req, res) => {
    const host = req.hostname; // Alternatively, you can use req.headers.host
    const port = req.socket.localPort;
    const protocol = req.protocol;
    try {
      const v = new Validator(req.body, {
        group_name: "required|string",
        members: "required",
        admin: "required",
      });
      let value = JSON.parse(JSON.stringify(req.body));

      const errorResponse = await checkValidation(v);
      if (errorResponse) {
        return failed(res, errorResponse);
      }
      req.body.image = await helpers.image_upload(req.files && req.files.image);

      let idsarr = [];

      //array of ids of group members without admin
      let idarrwthoutadmin = [];

      if (req.body.members) {
        if (req.body.members.includes(",")) {
          req.body.members.split(",").map((member) => {
            idsarr.push(member);
            if (member !== req.body.admin) {
              idarrwthoutadmin.push(member);
            }
          });
        } else {
          idsarr.push(req.body.members);
          req.body.members.split(",").map((member) => {
            if (member !== req.body.member) {
              idarrwthoutadmin.push(member);
            }
          });
        }
      }
      const generatedToken = uuidv4();
      let grpobj = {};
      grpobj.image = {};
      grpobj.group_name = req.body.group_name;
      grpobj.image.original = req.body.image;
      grpobj.image.thumbnail = "";
      grpobj.members = [];
      grpobj.tracking_status = parseInt(0);
      grpobj.invitation_token = generatedToken;
      grpobj.invitation_token_expire = new Date(
        Date.now() + 24 * 60 * 60 * 1000
      ); //24 hours expire
      grpobj.invitation_link =
        protocol == "http"
          ? `${protocol}://${host}:${port}/api/invitation?token=${generatedToken}`
          : `${protocol}://${host}/invitation?token=${generatedToken}`;

      // grpobj.destination_address = req.body.destination_address;
      // grpobj.destination_location = {
      //     type: "Point",
      //     coordinates: [
      //       parseFloat(req.body.longitude),
      //       parseFloat(req.body.latitude),
      //     ],
      // }
      let grplen;
      idsarr.map((id) => {
        let o = {};
        o.user_id = id;
        o.tracking = 0;
        o.sos_status = 0;
        o.onlineStatus = 0;
        o.destination_location = {
          type: "Point",
          coordinates: [parseFloat(0), parseFloat(0)],
        };
        o.current_location = {
          type: "Point",
          coordinates: [parseFloat(0), parseFloat(0)],
        };
        if (id === req.body.admin) {
          o.is_admin = true;
          o.status = 1;
        } else {
          o.is_admin = false;
          o.status = 0; //accepted: 1 // pending: 0
        }
        grpobj.members.push(o);
        grplen = grpobj.members.length;
      });
      if (grplen > 10) return error(res, "Only 10 members required");
      console.log(grpobj, "checkit");
      const group = await Model.Group.create(grpobj);

      let groupchat;

      // Create group chat
      if (group) {
        groupchat = await Model.GroupChat.create({
          groupId: group._id,
          users: idsarr,
        });
      }

      //Update Group Chat Id

      await Model.Group.findOneAndUpdate(
        { _id: group._id },
        {
          group_chat_id: groupchat._id,
        }
      );

      let fnlres = {};

      fnlres.members_ids = req.body.members;
      fnlres.admin = req.body.admin;
      fnlres.group_name = group.group_name;
      fnlres.image = group.image;
      fnlres._id = group._id;
      fnlres.group_chat_id = groupchat._id;
      fnlres.createdAt = group.createdAt;
      fnlres.updatedAt = group.updatedAt;
      fnlres.__v = group.__v;

      //SEND NOTIFICATION FOR GROUP INVITE

      //find admin
      let admin = await Model.Users.findOne({
        _id: req.body.admin,
      });

      //find users from ids

      let groupmemberswithoutadmin = await Model.Users.find(
        {
          _id: { $in: idarrwthoutadmin },
        },
        { deviceToken: 1, _id: 0 }
      );

      let groupmemberswithoutadmin2 = await Model.Users.find({
        _id: { $in: idarrwthoutadmin },
      });

      let tokenarr = [];

      groupmemberswithoutadmin.map((o) => {
        tokenarr.push(o.deviceToken);
      });

      let grpnotifiarr = [];

      let notificationmsg = `${admin.userName} has sent you an invitation to join group ${fnlres.group_name}`;

      //notifications types 1.Group Create 2.Accept Reject Group Invite 3. Group Update
      //Store Notification
      console.log(idarrwthoutadmin);
      idarrwthoutadmin.map((id) => {
        let o = {};
        o.receiver_id = id;
        o.group_id = group._id;
        o.type = 1;
        o.notification = notificationmsg;
        grpnotifiarr.push(o);
      });
      // console.log(groupmemberswithoutadmin2,'check the first it')
      groupmemberswithoutadmin2.map((user) => {
        console.log(user, "user is here");
        sendNotification(user.deviceToken, notificationmsg);
      });
      //notifications types 1.Group Create 2.Accept Reject Group Invite
      await Model.Notification.insertMany(grpnotifiarr);

      //helper.sendGroupNotification(tokenarr, notificationmsg);

      if (group) {
        return sendResponse.sendSuccessData(
          fnlres,
          APP_CONSTANTS.STATUSCODE.SUCCESS,
          req.headers.language,
          RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
          res
        );
      }
    } catch (err) {
      console.log(err, "error");
      return error(res, err.message);
    }
  },
  group_update: async (req, res) => {
    try {
      const v = new Validator(req.body, {
        group_id: "required",
        group_name: "required|string",
        // members: "required",
      });

      const errorResponse = await checkValidation(v);
      if (errorResponse) {
        return failed(res, errorResponse);
      }

      //find group
      let group = await Model.Group.findById(req.body.group_id);

      if (!group) {
        return sendResponse.sendErrorMessage(
          400,
          req.headers.language,
          RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
          res
        );
      }

      let image;

      if (req.files) {
        image = await helpers.image_upload(req.files && req.files.image);
      } else {
        image = group.image.original;
      }

      //array of ids for group addition
      let idsarr = [];

      if (req.body.members) {
        if (req.body.members.includes(",")) {
          req.body.members.split(",").map((member) => {
            idsarr.push(member);
          });
        } else {
          if (req.body.members.length > 0) {
            idsarr.push(req.body.members);
          }
        }
      }

      //Check if ids present in other array

      const isFounded = group.members.filter((element) => {
        // console.log(element.user_id._id,'checkit');
        return idsarr.includes(element.user_id.toString());
      });

      if (isFounded.length > 0) {
        return sendResponse.sendErrorMessage(
          400,
          req.headers.language,
          RESPONSE_MESSAGES.STATUS_MSG.ERROR.MEMBER_ALREADY_EXISTS,
          res
        );
      }

      let membersarr = [];

      if (idsarr.length > 0) {
        idsarr.map((id) => {
          // console.log(id,'checkithere')
          let o = {};
          o.user_id = id;
          o.is_admin = false;
          o.status = 0; //accepted: 1 // pending: 0
          membersarr.push(o);
        });
      }

      //Push new data into existing members

      let updatedgroup = await Model.Group.findOneAndUpdate(
        { _id: req.body.group_id },
        {
          group_name: req.body.group_name,
          image: {
            original: image,
          },
          $push: {
            members: {
              $each: membersarr,
            },
          },
        }
      ).populate("members.user_id");

      let grpnotifiarr = [];
      let group_arr = await Model.Group.findById(req.body.group_id).populate(
        "members.user_id"
      );
      // console.log(group_arr,'checkit')
      if (!req.body.members && req.body.group_name) {
        let notificationmsg = `${req.user.userName} has changed group name to ${req.body.group_name}`;

        //Store Notification
        //  console.log(groupcheck.members,'checkmember')
        group_arr.members.map((id) => {
          if (
            id.user_id &&
            id.user_id._id &&
            req.user._id &&
            req.user._id.toString() !== id.user_id._id.toString() &&
            id.user_id._id.toString() !== req.user._id.toString() &&
            id.status === 1
          ) {
            let o = {};
            o.receiver_id = id.user_id._id;
            o.group_id = group._id;
            o.type = 3;
            o.notification = notificationmsg;
            grpnotifiarr.push(o);
            sendNotification(id.user_id.deviceToken, notificationmsg);
          }
        });
        //notifications types 1.Group Create 2.Accept Reject Group Invite 3.Group Name Change
        // 4. New Members Added

        //Send Notification here on group name changed
        await Model.Notification.insertMany(grpnotifiarr);
      } else {
        let newaddedmemberarr = [];

        let notificationmsg2 = `Admin has sent you an invitation to join group ${req.body.group_name}`;
        //Send Notification for added members
        // group.members.map((data) => {
        //   // console.log(data.user_id)
        //   let o = {};
        //   o.receiver_id = data.user_id;
        //   o.group_id = group._id;
        //   o.type = 4;
        //   o.notification = notificationmsg2;
        //   newaddedmemberarr.push(o);
        // });

        //Send Notification for added members in very real case
        group_arr.members.map((id) => {
          if (!id.user_id.is_admin) {
            let o = {};
            o.receiver_id = id.user_id._id;
            o.group_id = group._id;
            o.type = 1;
            o.notification = notificationmsg2;
            newaddedmemberarr.push(o);
            sendNotification(id.user_id.deviceToken, notificationmsg2);
          }
        });
        await Model.Notification.insertMany(newaddedmemberarr);
      }

      let fnlgrp;

      let query = [
        { $unwind: "$members" }, // unwind the members array
        {
          $lookup: {
            // join with the users collection to get the user details
            from: "users",
            localField: "members.user_id",
            foreignField: "_id",
            pipeline: [
              // Exclude some unwanted fields from the right side of the join
              {
                $unset: [
                  "password",
                  "countryCode",
                  "deviceType",
                  "deviceToken",
                  "accessToken",
                  "is_verify",
                  "role",
                  "status",
                  "firstName",
                  "lastName",
                  "type",
                  "otp",
                  "createdAt",
                  "updatedAt",
                ],
              },
            ],
            as: "userdetail",
          },
        },

        { $unwind: "$userdetail" }, // unwind the userdetail array
        {
          $group: {
            // group the objects back together with the new userdetail field
            _id: "$_id",
            image: { $first: "$image" },
            group_name: { $first: "$group_name" },
            group_chat_id: { $first: "$group_chat_id" },
            createdAt: { $first: "$createdAt" },
            updatedAt: { $first: "$updatedAt" },
            __v: { $first: "$__v" },
            members_array: {
              $push: {
                _id: "$members._id",
                user_id: "$members.user_id",
                is_admin: "$members.is_admin",
                status: "$members.status",
                tracking: "$members.tracking",
                userdetail: "$userdetail",
              },
            },
          },
        },
      ];

      query.push({ $match: { _id: ObjectId(req.body.group_id) } });
      // query[2] = { $match: { _id: ObjectId(group_id) } };
      fnlgrp = await Model.Group.aggregate(query);

      return success(res, "Group updated succesfully", fnlgrp[0]);
    } catch (error) {
      console.log(error, "here");
      res.status(400).send(error.message);
    }
  },

  getGroup: async (req, res) => {
    let group_id = req.query.id;
    // console.log(group_id,)
    let groups;
    let query = [
      { $unwind: "$members" }, // unwind the members array
      //{ $match: { "members.status": 1, "members.user_id": req.user._id } },
      {
        $lookup: {
          // join with the users collection to get the user details
          from: "users",
          localField: "members.user_id",
          foreignField: "_id",
          pipeline: [
            // Exclude some unwanted fields from the right side of the join
            {
              $unset: [
                "password",
                "countryCode",
                "deviceType",
                "deviceToken",
                "accessToken",
                "is_verify",
                "role",
                "status",
                "firstName",
                "lastName",
                "type",
                "otp",
                "createdAt",
                "updatedAt",
              ],
            },
          ],
          as: "userdetail",
        },
      },

      { $unwind: "$userdetail" }, // unwind the userdetail array
      {
        $group: {
          // group the objects back together with the new userdetail field
          _id: "$_id",
          image: { $first: "$image" },
          group_name: { $first: "$group_name" },
          invitation_link: { $first: "$invitation_link" },
          destination_address: { $first: "$destination_address" },
          destination_location: { $first: "$destination_location" },
          group_chat_id: { $first: "$group_chat_id" },
          createdAt: { $first: "$createdAt" },
          updatedAt: { $first: "$updatedAt" },
          __v: { $first: "$__v" },
          members_array: {
            $push: {
              _id: "$members._id",
              user_id: "$members.user_id",
              is_admin: "$members.is_admin",
              status: "$members.status",
              onlineStatus: "$members.onlineStatus",
              tracking: "$members.tracking",
              sos_status: "$members.sos_status",
              userdetail: "$userdetail",
            },
          },
        },
      },
      /*{
        $project: {
          members_array: {
            $filter: {
              input: "$members_array",
              as: "item",
              cond: { $eq: ["$$item.status", 1] },
            },
          },
        },
      },*/
    ];

    if (group_id) {
      query.push({ $match: { _id: ObjectId(group_id) } });
      // query[2] = { $match: { _id: ObjectId(group_id) } };
      groups = await Model.Group.aggregate(query);
      if (groups.length) {
        groups = groups[0];
      }

      if (groups.length == 0) {
        groups = {};
        return sendResponse.sendErrorMessage(
          400,
          req.headers.language,
          RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
          res
        );
      }
    } else {
      query.unshift({ $match: { "members.user_id": req.user._id } });
      query.push({ $sort: { createdAt: -1 } });
      groups = await Model.Group.aggregate(query);
    }

    if (!groups) {
      return sendResponse.sendErrorMessage(
        400,
        req.headers.language,
        RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
        res
      );
    }

    return sendResponse.sendSuccessData(
      groups,
      APP_CONSTANTS.STATUSCODE.SUCCESS,
      req.headers.language,
      RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
      res
    );
  },
  //get tracking
  group_tracking_history: async (req, res) => {
    const groups = await Model.Group.aggregate([
      {
        $match: {
          members: {
            $elemMatch: {
              user_id: mongoose.Types.ObjectId(req.user._id),
            },
          },
          tracking_status: true,
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "members.user_id",
          foreignField: "_id",
          as: "userdetail",
        },
      },
      {
        $addFields: {
          members_array: {
            $map: {
              input: "$members",
              as: "member",
              in: {
                $mergeObjects: [
                  "$$member",
                  {
                    userdetail: {
                      $arrayElemAt: [
                        {
                          $filter: {
                            input: "$userdetail",
                            as: "user",
                            cond: {
                              $eq: ["$$user._id", "$$member.user_id"],
                            },
                          },
                        },
                        0,
                      ],
                    },
                  },
                ],
              },
            },
          },
        },
      },
      {
        $project: {
          members: 0,
          userdetail: 0,
        },
      },
    ]);
    if (groups.length == 0) {
      return success(res, "No group found");
    }
    return sendResponse.sendSuccessData(
      groups,
      APP_CONSTANTS.STATUSCODE.SUCCESS,
      req.headers.language,
      RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
      res
    );
  },

  group_chat_history: async (req, res) => {
    let request = req.query;
    // console.log(request,'fjdsklfh')
    const v = new Validator(request, {
      group_chat_id: "required",
    });

    const errorResponse = await checkValidation(v);
    if (errorResponse) {
      return failed(res, errorResponse);
    }
    //  console.log(req.params.group_chat_id ,"o")
    let groupchat = await Model.Message.find({
      type: "location",
      group_chat_id: request.group_chat_id,
    }).sort({ createdAt: 1 });

    // console.log(groupchat,'chdjkfhksdfhksd')
    return sendResponse.sendSuccessData(
      groupchat,
      APP_CONSTANTS.STATUSCODE.SUCCESS,
      req.headers.language,
      RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
      res
    );
  },
  get_all_messages_loaction: async (req, res) => {
    try {
      const messages = await Model.Message.aggregate([
        {
          $match: {
            type: "location",
            group_chat_id: ObjectId(req.query.group_id),
          },
        },
      ]);
      if (messages) {
        return sendResponse.sendSuccessData(
          messages,
          APP_CONSTANTS.STATUSCODE.SUCCESS,
          req.headers.language,
          RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
          res
        );
      } else {
        return sendResponse.sendErrorMessage(
          400,
          req.headers.language,
          RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
          res
        );
      }
    } catch (err) {
      console.error(err);
    }

    // return sendResponse.sendSuccessData(
    //   jsonData,
    //   APP_CONSTANTS.STATUSCODE.SUCCESS,
    //   req.headers.language,
    //   RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
    //   res
    // );
  },

  removeUser: async (req, res) => {
    let request = req.body;
    let group_id = request.group_id;
    let user_id = request.user_id;

    const v = new Validator(request, {
      group_id: "required",
      user_id: "required",
    });

    const errorResponse = await checkValidation(v);
    if (errorResponse) {
      return failed(res, errorResponse);
    }

    let idPresent = await Model.Group.findOne({
      _id: group_id,
      members: {
        $elemMatch: { user_id: user_id },
      },
    });

    if (!idPresent) {
      return sendResponse.sendErrorMessage(
        400,
        req.headers.language,
        RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
        res
      );
    }
    await Model.Group.updateOne(
      { _id: group_id },
      {
        $pull: {
          members: { user_id: user_id },
        },
      }
    );

    let notificationPresent = await Model.Notification.find({
      group_id: group_id,
      receiver_id: user_id,
      type: 1,
    });

    if (notificationPresent) {
      //Remove notification
      await Model.Notification.deleteOne({
        group_id: group_id,
        receiver_id: user_id,
        type: 1,
      });
    }

    let groups = await Model.Group.findById(group_id);

    if (!groups) {
      return sendResponse.sendErrorMessage(
        400,
        req.headers.language,
        RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
        res
      );
    }

    return sendResponse.sendSuccessData(
      groups,
      APP_CONSTANTS.STATUSCODE.SUCCESS,
      req.headers.language,
      RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
      res
    );
  },

  leaveGroup: async (req, res) => {
    let request = req.body;
    let group_id = request.group_id;
    let user_id = req.user.id;

    const v = new Validator(request, {
      group_id: "required",
    });

    const errorResponse = await checkValidation(v);
    if (errorResponse) {
      return failed(res, errorResponse);
    }

    let idPresent = await Model.Group.findOne({
      _id: group_id,
    }).populate("members.user_id");
    if (!idPresent) return failed(res, "group not found");
    //Check if whether admin is being deleted
    let adminobj = idPresent?.members.find((o) => o.user_id._id == user_id);

    const group = await Model.Group.findById(group_id).populate(
      "members.user_id"
    );
    let isadminfalse = idPresent?.members.find((o) => o.is_admin == false);
    // console.log(isadminfalse.length,'checkit')
    //get random user with is_admin false
    let isadmintrue = idPresent?.members.find((o) => o.is_admin == true);
    let notificationmsg2 = `Admin has deleted the group ${idPresent.group_name}`;
    if (isadmintrue) {
      await Model.Notification.deleteMany({ group_id: group_id });
      let newaddedmemberarr = [];
      group.members.map((data) => {
        console.log(data, "chcekdata");
        if (data.is_admin == false && data.status == 1) {
          console.log(data, "under admin false,cdhfhdfhhfhhf");
          let o = {};
          o.receiver_id = data.user_id._id;
          o.group_id = group._id;
          o.type = 4;
          o.notification = notificationmsg2;
          newaddedmemberarr.push(o);
          sendNotification(data.user_id.deviceToken, notificationmsg2);
        }
      });
      // return;
      let groupdel = await Model.Group.deleteOne({ _id: group_id });
      await Model.Notification.insertMany(newaddedmemberarr);
      return success(res, "Admin group leave successfully");
    }

    // console.log(idPresent.members,'checkit')
    const membersWithStatusOne = idPresent.members?.filter(
      (member) => member.status == 1
    );
    // return;
    console.log(group.members.length, "chedksfsdhf");
    if (group.members.length === 1) {
      await Model.Group.updateOne(
        { _id: group_id },
        {
          $pull: {
            members: { user_id: user_id },
          },
        }
      );
      return sendResponse.sendSuccessData(
        group,
        APP_CONSTANTS.STATUSCODE.SUCCESS,
        req.headers.language,
        RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
        res
      );
    }
    if (membersWithStatusOne.length < 2)
      return failed(
        res,
        "You can't leave the group. At least two members must be added. "
      );
    if (isadminfalse && adminobj) {
      console.log(isadminfalse, ">>>>>>>>>>>>>>");
      const result = await Model.Group.updateOne(
        {
          _id: group_id,
          members: {
            $elemMatch: { status: 1, is_admin: false },
          },
        },
        {
          $set: { "members.$.is_admin": true },
        }
      );

      if (result.acknowledged && result.modifiedCount > 0) {
        console.log("Admin updated successfully.");
      } else {
        console.log("Failed to update admin.");
      }

      // console.log(isadmin.modifiedCount,'count is here')
    }

    if (!idPresent) {
      return sendResponse.sendErrorMessage(
        400,
        req.headers.language,
        RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
        res
      );
    }

    await Model.Group.updateOne(
      { _id: group_id },
      {
        $pull: {
          members: { user_id: user_id },
        },
      }
    );

    let groups = await Model.Group.findById(group_id);

    if (!groups) {
      return sendResponse.sendErrorMessage(
        400,
        req.headers.language,
        RESPONSE_MESSAGES.STATUS_MSG.ERROR.DATA_NOT_FOUND,
        res
      );
    }

    return sendResponse.sendSuccessData(
      groups,
      APP_CONSTANTS.STATUSCODE.SUCCESS,
      req.headers.language,
      RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
      res
    );
  },

  //old report user
  ReportUser: async (req, res) => {
    let request = req.body;
    let report_by = req.user._id;
    if (!report_by) return failed(res, "not authorized");
    const v = new Validator(request, {
      group_id: "required",
      user_id: "required",
    });

    const errorResponse = await checkValidation(v);
    if (errorResponse) {
      return failed(res, errorResponse);
    }
    let findreports = await Model.Report.findOne({
      user_id: request.user_id,
      report_by,
    });
    if (findreports) return failed(res, "You have already reported");
    let data = {
      group_id: request.group_id,
      user_id: request.user_id,
      report_by,
    };
    const report = await Model.Report.create(data);
    const group = await Model.Group.findById({
      _id: request.group_id,
    }).populate("members.user_id");

    //notification sends to group admin

    const user = await Model.Users.findOne({ _id: report_by });
    const reportedUser = await Model.Users.findOne({ _id: request.user_id });
    // console.log(user.userName,'checkit')
    let notificationmsg = `User ${user.userName} has reported  ${reportedUser.userName} in group ${group.group_name}`;
    // console.log(notificationmsg,'checkit')
    // return;
    group.members.forEach(async (member) => {
      if (member.is_admin == true) {
        let notification_data = {
          receiver_id: member.user_id._id,
          group_id: request.group_id,
          notification: notificationmsg,
        };
        // console.log(notification_data,'check kr laine aa')
        sendNotification(member.user_id.deviceToken, notificationmsg);
        await Model.Notification.create(notification_data);
      }
    });

    return sendResponse.sendSuccessData(
      report,
      APP_CONSTANTS.STATUSCODE.SUCCESS,
      req.headers.language,
      RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
      res
    );
  },
  //
  //new report user
  //  ReportUser: async (req, res) => {
  //   try {
  //     const request = req.body;
  //     const report_by = req.user._id;

  //     if (!report_by) {
  //       return failed(res, 'Not authorized');
  //     }

  //     const v = new Validator(request, {
  //       group_id: 'required',
  //       user_id: 'required',
  //     });

  //     const errorResponse = await checkValidation(v);
  //     if (errorResponse) {
  //       return failed(res, errorResponse);
  //     }

  //     const existingReport = await Model.Report.findOne({
  //       user_id: request.user_id,
  //       report_by,
  //     });
  //     if (existingReport) {
  //       return failed(res, 'You have already reported');
  //     }

  //     const group = await Model.Group.findById(request.group_id).populate('members.user_id');
  //     if (!group) {
  //       return failed(res, 'Group not found');
  //     }

  //     const user = await Model.Users.findOne({ _id: report_by });
  //     const reportedUser = await Model.Users.findOne({ _id: request.user_id });
  //     if (!user || !reportedUser) {
  //       return failed(res, 'User not found');
  //     }

  //     const notificationmsg = `User ${user.userName} has reported ${reportedUser.userName} in group ${group.group_name}`;

  //     const notificationData = [];
  //     for (const member of group.members) {
  //       if (member.is_admin) {
  //         notificationData.push({
  //           receiver_id: member.user_id._id,
  //           group_id: request.group_id,
  //           notification: notificationmsg,
  //           deviceToken:member.user_id.deviceToken
  //         });
  //       }
  //     }

  //     await Promise.all([
  //       sendNotification(notificationData.map((data) => data.deviceToken), notificationmsg),
  //       Model.Notification.create(notificationData)
  //     ]);

  //     const report = await Model.Report.create({
  //       group_id: request.group_id,
  //       user_id: request.user_id,
  //       report_by,
  //     });

  //     return sendResponse.sendSuccessData(
  //       report,
  //       APP_CONSTANTS.STATUSCODE.SUCCESS,
  //       req.headers.language,
  //       RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
  //       res
  //     );
  //   } catch (error) {
  //     console.log(error);
  //     return failed(res, 'Internal server error');
  //   }
  // },

  //old report group
  ReportGroup: async (req, res) => {
    const v = new Validator(req.body, {
      group_id: "required",
    });

    const errorResponse = await checkValidation(v);
    if (errorResponse) {
      return failed(res, errorResponse);
    }

    let data = {
      group_id: req.body.group_id,
      report_by: req.user._id,
    };
    //  console.log(data,'checkout')
    let findreports = await Model.ReportGroup.findOne({
      group_id: data.group_id,
      report_by: data.report_by,
    });
    if (findreports) return failed(res, "You have already reported");
    const report = await Model.ReportGroup.create(data);

    //notification sends to group admin
    const group = await Model.Group.findOne({ _id: data.group_id }).populate(
      "members.user_id"
    );

    const user = await Model.Users.findOne({ _id: data.report_by });
    let userAdmin = await Model.Users.findOne({ role: "1" });

    let notificationmsg = `User ${user.userName} has reported in group ${group.group_name}`;
    // console.log(notificationmsg,'checkit')
    // return;
    let notification_data = {
      receiver_id: userAdmin._id,
      group_id: group._id,
      notification: notificationmsg,
    };
    sendNotification(userAdmin.deviceToken, notificationmsg);
    await Model.Notification.create(notification_data);

    return sendResponse.sendSuccessData(
      report,
      APP_CONSTANTS.STATUSCODE.SUCCESS,
      req.headers.language,
      RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
      res
    );
  },
  // ReportGroup: async (req, res) => {
  //   try {
  //     const { group_id } = req.body;
  //     const report_by = req.user._id;

  //     // Validate the request body
  //     const v = new Validator(req.body, {
  //       group_id: "required"
  //     });

  //     const errorResponse = await checkValidation(v);
  //     if (errorResponse) {
  //       return failed(res, errorResponse);
  //     }

  //     // Check if the user has already reported
  //     const existingReport = await Model.ReportGroup.findOne({
  //       group_id,
  //       report_by
  //     });
  //     if (existingReport) {
  //       return failed(res, "You have already reported");
  //     }

  //     // Create a new report
  //     const report = await Model.ReportGroup.create({
  //       group_id,
  //       report_by
  //     });

  //     // Get the group details and the reporting user
  //     const [group, user] = await Promise.all([
  //       Model.Group.findOne({ _id: group_id }).populate("members.user_id"),
  //       Model.Users.findOne({ _id: report_by })
  //     ]);

  //     const notificationmsg = `User ${user.userName} has reported in group ${group.group_name}`;

  //     // Send notifications to group admins
  //     const notificationData = [];
  //     for (const member of group.members) {
  //       if (member.is_admin) {
  //         notificationData.push({
  //           receiver_id: member.user_id._id,
  //           group_id: group._id,
  //           notification: notificationmsg,
  //           deviceToken:member.user_id.deviceToken
  //         });
  //       }
  //     }

  //     await Promise.all([
  //       sendNotification(notificationData.map((data) => data.deviceToken), notificationmsg),
  //       Model.Notification.create(notificationData)
  //     ]);

  //     return sendResponse.sendSuccessData(
  //       report,
  //       APP_CONSTANTS.STATUSCODE.SUCCESS,
  //       req.headers.language,
  //       RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
  //       res
  //     );
  //   } catch (error) {
  //     console.error(error);
  //     return failed(res, "An error occurred");
  //   }
  // },
  deleteGroup: async (req, res) => {
    let request = req.body;
    const v = new Validator(request, {
      group_id: "required",
    });

    const errorResponse = await checkValidation(v);
    if (errorResponse) {
      return failed(res, errorResponse);
    }

    await Model.Group.deleteOne({ _id: request.group_id });

    return sendResponse.sendSuccessData(
      {},
      APP_CONSTANTS.STATUSCODE.SUCCESS,
      req.headers.language,
      RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
      res
    );
  },
  getChatById: async (req, res) => {
    let request = req.params;
    // console.log(request,'fjdsklfh')
    const v = new Validator(request, {
      group_chat_id: "required",
    });

    const errorResponse = await checkValidation(v);
    if (errorResponse) {
      return failed(res, errorResponse);
    }
    //  console.log(req.params.group_chat_id ,"o")
    let groupchat = await Model.Message.find({
      group_chat_id: request.group_chat_id,
    }).sort({ createdAt: -1 });

    // console.log(groupchat,'chdjkfhksdfhksd')
    return sendResponse.sendSuccessData(
      groupchat,
      APP_CONSTANTS.STATUSCODE.SUCCESS,
      req.headers.language,
      RESPONSE_MESSAGES.STATUS_MSG.SUCCESS.SUCCESS,
      res
    );
  },
  //new tracking api
  tracking_status: async (req, res) => {
    // console.log(req.user._id, 'checkit');
    try {
      const status = req.body.status;
      console.log(req.body, "body is here");
      const v = new Validator(req.body, {
        group_id: "required",
        user_id: "required",
        status: "required",
        latitude: "required",
        longitude: "required",
      });
      const errorResponse = await checkValidation(v);
      if (errorResponse) {
        return failed(res, errorResponse);
      }

      const updateObject = {
        $set: {
          "members.$.tracking": parseInt(req.body.status),
          "members.$.onlineStatus": parseInt(req.body.onlineStatus),
          tracking_status: parseInt(1),
        },
      };

      if (req.body.status == 1) {
        updateObject.$set["members.$.destination_location"] = {
          type: "Point",
          coordinates: [
            parseFloat(req.body.longitude),
            parseFloat(req.body.latitude),
          ],
        };
      } else {
        updateObject.$set["members.$.current_location"] = {
          type: "Point",
          coordinates: [
            parseFloat(req.body.latitude),
            parseFloat(req.body.longitude),
          ],
        };
      }

      const trackingStatus = await Model.Group.updateOne(
        {
          _id: req.body.group_id,
          members: {
            $elemMatch: { user_id: req.user._id },
          },
        },
        updateObject
      );

      let updateUserLoc;
      if (trackingStatus.modifiedCount !== 0) {
        updateUserLoc = await Model.Users.updateOne(
          { _id: req.user._id },
          {
            $set: {
              location: {
                type: "Point",
                coordinates: [
                  parseFloat(req.body.longitude),
                  parseFloat(req.body.latitude),
                ],
              },
            },
          }
        );
      }

      console.log(updateUserLoc, "user updated long,lat");

      const updatedFields = {
        tracking: parseInt(req.body.status),
        onlineStatus: parseInt(req.body.onlineStatus),
      };

      const updatedGroup = await Model.Group.findById(req.body.group_id, {
        members: 0,
      });
      console.log(updatedGroup, "group is here");

      const groupAllMembers = await Model.Group.findById(
        req.body.group_id
      ).populate("members.user_id");
      let userDetail = null;

      if (groupAllMembers) {
        const members = groupAllMembers.members;
        const member = members.find(
          (member) => member.user_id._id.toString() === req.user._id.toString()
        );

        if (member) {
          userDetail = member;
          console.log(userDetail.destination_location, "user detail is here");
        }
      }
      if (req.body.status == 1) {
        // updatedFields.destination_location = {
        //   type: "Point",
        //   coordinates: [
        //     parseFloat(req.body.longitude),
        //     parseFloat(req.body.latitude),
        //   ],
        // };
        // updatedFields.destination_longitude = parseFloat(updatedFields.destination_location.coordinates[0]);
        // updatedFields.destination_latitude = parseFloat(updatedFields.destination_location.coordinates[1]);
        // delete updatedFields.destination_location;
      } else {
        updatedFields.current_location = {
          type: "Point",
          coordinates: [
            parseFloat(req.body.longitude),
            parseFloat(req.body.latitude),
          ],
        };
        updatedFields.start_longitude =
          userDetail.destination_location.coordinates[1].toString();
        updatedFields.start_latitude =
          userDetail.destination_location.coordinates[0].toString();
        delete updatedFields.current_location;
      }

      // Add the updatedFields object to the root of the updatedGroup object
      const groupWithUpdatedFields = {
        ...updatedGroup.toObject(),
        ...updatedFields,
      };

      const notificationMsg =
        req.body.status == 1
          ? `${req.user.userName} has started tracking ${groupAllMembers.group_name} group`
          : `${req.user.userName} has stopped tracking ${groupAllMembers.group_name} group`;

      const newAddedMemberArr = [];
      groupAllMembers.members.map((id) => {
        // console.log(id.user_id.status,'checkit')
        if (
          id.user_id &&
          id.user_id._id &&
          req.user._id &&
          req.user._id.toString() !== id.user_id._id.toString() &&
          id.status === 1
        ) {
          const o = {
            receiver_id: id.user_id._id,
            group_id: updatedGroup._id,
            type: 4,
            notification: notificationMsg,
          };
          newAddedMemberArr.push(o);
          sendNotification(id.user_id.deviceToken, notificationMsg);
        }
      });

      await Model.Notification.insertMany(newAddedMemberArr);
      return success(
        res,
        "Tracking Status Updated Successfully",
        groupWithUpdatedFields
      );
    } catch (error) {
      res.status(400).send(error.message);
    }
  },
  //old tracking status api
  // tracking_status: async (req, res) => {
  //   console.log(req.user._id,'checkit')
  //   try {
  //     const v = new Validator(req.body, {
  //       group_id: "required",
  //       user_id: "required",
  //       status: "required",
  //       latitude:"required",
  //       longitude:"required",
  //     });

  //     const errorResponse = await checkValidation(v);
  //     if (errorResponse) {
  //       return failed(res, errorResponse);
  //     }
  //     if(req.body.status==1){
  //      await Model.Group.updateOne(
  //       // $elemMatch finds docs containing an array with a matching element
  //       {
  //         _id: req.body.group_id,
  //         members: {
  //           $elemMatch: { user_id: req.body.user_id },
  //         },
  //       },

  //       // Positional operator $ is a placeholder for the first matching array element
  //       {
  //         $set: {
  //         "members.$.tracking": parseInt(req.body.status),
  //         "members.$.onlineStatus": parseInt(req.body.onlineStatus),
  //         "members.$.destination_location": {
  //           type: "Point",
  //           coordinates: [
  //             parseFloat(req.body.longitude),
  //             parseFloat(req.body.latitude),
  //           ],
  //         },
  //         tracking_status:parseInt(1)
  //       },
  //       }
  //     );

  //     }else{
  //          await Model.Group.updateOne(
  //         // $elemMatch finds docs containing an array with a matching element
  //         {
  //           _id: req.body.group_id,
  //           members: {
  //             $elemMatch: { user_id: req.body.user_id },
  //           },
  //         },

  //         // Positional operator $ is a placeholder for the first matching array element
  //         {
  //           $set: {
  //           "members.$.tracking": parseInt(req.body.status),
  //           "members.$.onlineStatus": parseInt(req.body.onlineStatus),
  //           "members.$.current_location": {
  //             type: "Point",
  //             coordinates: [
  //               parseFloat(req.body.start_longitude),
  //               parseFloat(req.body.start_latitude),
  //             ],
  //           },
  //           tracking_status:parseInt(1)
  //         },
  //         }
  //       );
  //     }

  //     let updateUserloc;
  //     if(trackingStatus.modifiedCount!==0){
  //     updateUserloc =  await Model.Users.updateOne({ _id: req.body.user_id },
  //     { $set: {
  //       location: {
  //       type: "Point",
  //       coordinates: [
  //         parseFloat(req.body.longitude),
  //         parseFloat(req.body.latitude),
  //       ],
  //     },
  //    } })
  //   }
  //     console.log(updateUserloc,'user updated long,lat')

  //     let group = await Model.Group.findById(req.body.group_id, {
  //       members: 0,
  //     });
  //     let groupallMember = await Model.Group.findById(req.body.group_id).populate("members.user_id");
  //     console.log(groupallMember,'dfhdhf')
  //     let notificationmsg2 = req.body.status==1?`${req.user.userName} has started tracking ${groupallMember.group_name} group`:`${req.user.userName} has Stopped tracking ${groupallMember.group_name} group`
  //     let newaddedmemberarr =[];
  //     if(req.body.status==1){
  //     groupallMember.members.map((id) => {
  //       // console.log(id,'checkit')
  //       if(id.user_id && id.user_id._id && req.user._id && req.user._id.toString() !== id.user_id._id.toString()){
  //         let o = {};
  //         o.receiver_id = id.user_id._id;
  //         o.group_id = group._id;
  //         o.type = 4;
  //         o.notification = notificationmsg2;
  //         newaddedmemberarr.push(o);
  //         sendNotification(id.user_id.deviceToken,notificationmsg2)
  //       }
  //       });
  //     }else{
  //       groupallMember.members.map((id) => {
  //         // console.log(id,'checkit')
  //         if(id.user_id && id.user_id._id && req.user._id && req.user._id.toString() !== id.user_id._id.toString()){
  //           let o = {};
  //           o.receiver_id = id.user_id._id;
  //           o.group_id = group._id;
  //           o.type = 4;
  //           o.notification = notificationmsg2;
  //           newaddedmemberarr.push(o);
  //           sendNotification(id.user_id.deviceToken,notificationmsg2)
  //         }
  //         });
  //     }

  //     await Model.Notification.insertMany(newaddedmemberarr);

  //     return success(res, "Tracking Status Updated Successfully ", group);
  //   } catch (error) {
  //     res.status(400).send(error.message);
  //   }
  // },

  //get tracking status data
  get_tracking_with_status: async (req, res) => {
    try {
      const v = new Validator(req.query, {
        group_id: "required",
        user_id: "required",
      });

      const errorResponse = await checkValidation(v);
      if (errorResponse) {
        return failed(res, errorResponse);
      }
      const group_id = req.query.group_id;
      const user_id = req.query.user_id;
      const trackingStatus = 1;
      const onlineStatus = 1;

      const member = await Model.Group.findOne(
        {
          _id: group_id,
          members: {
            $elemMatch: {
              user_id: user_id,
              tracking: trackingStatus,
              onlineStatus: onlineStatus,
            },
          },
        },
        { "members.$": 1 }
      )
        .populate({
          path: "members.user_id",
          model: "Users",
          select: "-_id",
          options: { lean: true },
          populate: {
            path: "user_id",
            model: "Users",
            select: "name",
            options: { lean: true },
          },
        })
        .lean();

      if (!member) {
        return failed(res, "Member not found");
      }

      const memberInfo = member.members[0];
      memberInfo.start_track_location = memberInfo.destination_location;
      memberInfo.userDetails = memberInfo.user_id;
      delete memberInfo.user_id;
      delete memberInfo.destination_location;
      return success(
        res,
        "Member Information Retrieved Successfully",
        memberInfo
      );
    } catch (error) {
      res.status(400).send(error.message);
    }
  },

  sos_status: async (req, res) => {
    console.log("check first");
    try {
      const v = new Validator(req.body, {
        group_id: "required",
        user_id: "required",
        sos_status: "required",
        longitude: "required",
        latitude: "required",
      });

      const errorResponse = await checkValidation(v);
      if (errorResponse) {
        return failed(res, errorResponse);
      }

      let trackingStatus = await Model.Group.updateOne(
        // $elemMatch finds docs containing an array with a matching element
        {
          _id: req.body.group_id,
          members: {
            $elemMatch: { user_id: req.body.user_id },
          },
        },

        // Positional operator $ is a placeholder for the first matching array element
        {
          $set: {
            "members.$.sos_status": parseInt(req.body.sos_status),
            "members.$.destination_location": {
              type: "Point",
              coordinates: [
                parseFloat(req.body.longitude),
                parseFloat(req.body.latitude),
              ],
            },
          },
        }
      );
      let updateUserloc;
      if (trackingStatus.modifiedCount !== 0) {
        updateUserloc = await Model.Users.updateOne(
          { _id: req.body.user_id },
          {
            $set: {
              location: {
                type: "Point",
                coordinates: [
                  parseFloat(req.body.longitude),
                  parseFloat(req.body.latitude),
                ],
              },
            },
          }
        );
      }
      console.log(updateUserloc, "user updated long,lat");

      let group = await Model.Group.findById(req.body.group_id, {
        members: 0,
      });

      let groupallMember = await Model.Group.findById(
        req.body.group_id
      ).populate("members.user_id");
      console.log(groupallMember, "checkit");
      let notificationmsg2 = `${req.user?.userName} has started SOS ${groupallMember?.group_name} group`;
      let newaddedmemberarr = [];
      groupallMember.members.map((id) => {
        if (
          id.user_id &&
          id.user_id._id &&
          req.user._id &&
          req.user._id.toString() !== id.user_id._id.toString() &&
          id.status === 1
        ) {
          let o = {};
          o.receiver_id = id.user_id._id;
          o.group_id = group._id;
          o.type = 4;
          o.notification = notificationmsg2;
          newaddedmemberarr.push(o);
          sendNotification(id.user_id.deviceToken, notificationmsg2);
        }
      });

      await Model.Notification.insertMany(newaddedmemberarr);

      return success(res, "Sos status Updated Successfully ", group);
    } catch (error) {
      console.log(error, "chchchh");
      res.status(400).send(error.message);
    }
  },
  uploadFile: async (req, res) => {
    try {
      if (req.files) {
        let filename = await file_uploads(req.files.file, "uploads");

        let filepath = `/uploads/${filename}`;

        return success(res, "File Uploaded", { filepath });
      }
    } catch (error) {
      res.status(400).send(error.message);
    }
  },
  verify_invitation: async (req, res) => {
    const { token } = req.query;
    const invitation = await Model.Group.findOne({ invitation_token: token });
    if (!invitation || invitation.invitation_token_expire < Date.now()) {
      return error(res, "Invalid or expired invitation");
    }

    success(res, "Link verified successfully");
  },
};

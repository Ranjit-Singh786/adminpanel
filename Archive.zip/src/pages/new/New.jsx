import "./new.scss";
import Sidebar from "../../components/sidebar/Sidebar";
import Navbar from "../../components/navbar/Navbar";
import DriveFolderUploadOutlinedIcon from "@mui/icons-material/DriveFolderUploadOutlined";
import { useState,useEffect } from "react";
import ApiClass from "../../api/api";
import swal from 'sweetalert';
import { useNavigate,useParams } from 'react-router-dom';

const New = ({ inputs, title,getreq, apiEndpoint }) => {
  const [file, setFile] = useState(null);
  const [formData, setFormData] = useState({});
  const navigate = useNavigate();
  const { sportsId } = useParams();
  // console.log(sportsId,'checkit')
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const form = new FormData();

      if (file) {
        form.append("logo", file);
      }

      for (const [key, value] of Object.entries(formData)) {
        form.append(key, value);
      }

      let response;
      if (sportsId) {
        console.log(sportsId,'update')
        // Update operation
        response = await ApiClass.putNodeRequest(apiEndpoint+'/'+sportsId, false, form);
      } else {
        console.log(sportsId,'add')
        // Create operation
        response = await ApiClass.postNodeRequest(apiEndpoint, false, form);
      }

      console.log(response?.data);

      setFile(null);
      setFormData({});

      swal({
        title: "Success",
        text: "Sport created/updated successfully",
        icon: "success",
        button: "OK",
      }).then(() => {
        navigate('/sports');
      });
  
    } catch (error) {
      console.error(error);
      swal({
        title: "Error",
        text: "An error occurred",
        icon: "error",
        button: "OK",
      });
    }
  };

  const fetchData = async () => {
    try {
      if (sportsId) {
        const response = await getreq(getreq + '/' + sportsId);
        const data = response?.data?.body;
        console.log(data,'data is here')
        setFormData(data);
      }
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    fetchData();
  }, [sportsId])
  

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [name]: value }));
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    setFile(selectedFile);
  };

  return (
    <div className="new">
      <Sidebar />
      <div className="newContainer">
        <Navbar />
        <div className="top">
          <h1>{title}</h1>
        </div>
        <div className="bottom">
          <div className="left">
            <img
              src={
                file
                  ? URL.createObjectURL(file)
                  : "https://icon-library.com/images/no-image-icon/no-image-icon-0.jpg"
              }
              alt=""
            />
          </div>
          <div className="right">
            <form onSubmit={handleSubmit}>
              <div className="formInput">
                <label htmlFor="file">
                  Image: <DriveFolderUploadOutlinedIcon className="icon" />
                </label>
                <input
                  type="file"
                  id="file"
                  onChange={handleFileChange}
                  style={{ display: "none" }}
                />
              </div>

              {inputs.map((input) => (
                <div className="formInput" key={input.id}>
                  <label>{input.label}</label>
                  <input
                    type={input.type}
                    name={input.name}
                    placeholder={input.placeholder}
                    value={formData[input.name] || ""}
                    onChange={handleInputChange}
                  />
                </div>
              ))}
              <button type="submit">Send</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default New;

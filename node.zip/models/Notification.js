let mongoose = require("mongoose");
let Schema = mongoose.Schema;

let NotificationsSchema = new Schema(
  {
    type: { type: Number },
    notification: { type: String, default: "" },
    group_id: { type: mongoose.Schema.Types.ObjectId, ref: "Group" },
    receiver_id : {type: mongoose.Schema.Types.ObjectId, ref: 'Users'}
  },
  { timestamps: true }
);

module.exports = mongoose.model("Notification", NotificationsSchema);

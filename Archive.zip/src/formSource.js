export const userInputs = [
    {
      id: 1,
      label: "Username",
      type: "text",
      placeholder: "john_doe",
    },
    {
      id: 2,
      label: "Name and surname",
      type: "text",
      placeholder: "John Doe",
    },
    {
      id: 3,
      label: "Email",
      type: "mail",
      placeholder: "john_doe@gmail.com",
    },
    {
      id: 4,
      label: "Phone",
      type: "text",
      placeholder: "+1 234 567 89",
    },
    {
      id: 5,
      label: "Password",
      type: "password",
    },
    {
      id: 6,
      label: "Address",
      type: "text",
      placeholder: "Elton St. 216 NewYork",
    },
    {
      id: 7,
      label: "Country",
      type: "text",
      placeholder: "USA",
    },
  ];

  export const sportInputs = [
    {
      id: 1,
      label: "Sport",
      type: "text",
      name:"sportname",
      placeholder: "@cricket,@football etc...",
    }
  ];
  export const teamInputs = [
    {
      id: 1,
      label: "Sport",
      type: "text",
      name:"teamname",
      placeholder: "@india,@srilanka etc...",
    },
    {
      id: 2,
      label: "Latitude",
      type: "number",
      name:"lat",
      placeholder: "@30.45 etc...",
    },
    {
      id: 3,
      label: "Longitude",
      type: "number",
      name:"long",
      placeholder: "@70.46 etc...",
    },
    {
      id: 4,
      label: "Email",
      type: "email",
      name:"email",
      placeholder: "demo@gmail.com",
    },
    {
      id: 5,
      label: "Address",
      type: "text",
      name:"address",
      placeholder: "@streetname,@city",
    },
    {
      id: 6,
      label: "Phone",
      type: "phone",
      name:"phone",
      placeholder: "@2334434232",
    },
    {
      id: 7,
      label: "Country",
      type: "text",
      name:"country",
      placeholder: "@india,@usa",
    }
  ];
  
  export const productInputs = [
    {
      id: 1,
      label: "Title",
      type: "text",
      placeholder: "Apple Macbook Pro",
    },
    {
      id: 2,
      label: "Description",
      type: "text",
      placeholder: "Description",
    },
    {
      id: 3,
      label: "Category",
      type: "text",
      placeholder: "Computers",
    },
    {
      id: 4,
      label: "Price",
      type: "text",
      placeholder: "100",
    },
    {
      id: 5,
      label: "Stock",
      type: "text",
      placeholder: "in stock",
    },
  ];
  
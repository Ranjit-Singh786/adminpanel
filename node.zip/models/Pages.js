let mongoose=require('mongoose');
let Schema=mongoose.Schema;

let PagesSchema = new Schema({
    accessor:               {type:String, default:""},
    title:                  {type:String, default:""},
    content:                {type:String, default:""},
    status:                 {type:String, default:"1"}, // 0: Hide , 1: show
    isDeleted: 		        {type: Boolean,default:false },
    
},{timestamps:true});

module.exports = mongoose.model('Pages',PagesSchema);
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import express from 'express';
import path from 'path';
import cookieParser from 'cookie-parser';
import morgan from 'morgan';
import fileUpload from 'express-fileupload';
import bodyParser from 'body-parser';
import compression from 'compression';
import cors from 'cors';
import { createServer } from 'http';

import { fileURLToPath } from 'url';
import { dirname } from 'path';
import AdminRoute from './Routes/AdminRoute.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);


dotenv.config();
const server = express();
const httpServer = createServer(server);
const port = process.env.PORT;
//  console.log(process.env.MONGODB_URI,'checkit')


server.enable('trust proxy');
server.use(cors());
server.use(fileUpload());
server.options('*', cors());
server.use(express.static(path.join(__dirname, 'public')));

if (process.env.NODE_ENV === 'development') {
  server.use(morgan('dev'));
}
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  // useFindAndModify: false,
  // useCreateIndex: true,
})
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('Failed to connect to MongoDB', error);
  });
server.use(bodyParser.json({ limit: '50mb' }));
server.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
server.use(cookieParser());
server.use(compression());
// Define your routes here
server.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

//admin routes
server.use('/admin', AdminRoute);
// Start the server
const app = httpServer.listen(port, () => {
  console.log(`App running on port http://localhost:${port}...`);
});

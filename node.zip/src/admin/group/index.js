/**
 * Makes all routes available outer modules.
 */

module.exports = {
    Routes : require('./routes'),
    swagger: require('./swagger.json')
};
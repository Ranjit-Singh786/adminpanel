
'use strict';

var STATUSCODE = {
    BAD_REQUEST: 400,
    INTERNAL_SERVER_ERROR: 500,
    SUCCESS: 200,
    UNAUTHORIZE: 401,
    CREATED: 201,
    APP_ERROR: 402,
    ROLE_CHANGE: 403
};

var SERVER = {
    APP_NAME: 'Acne Clear',
    TOKEN_EXPIRATION: 60 * 60 * 24 * 30, // expires in 24 hours * 7 days
    JWT_SECRET_KEY: 'csfAuthSecret',
    JWT_SECRET_KEY_ADMIN: 'PYj5YitbgSAgeVZVntAKh5LNGeCdIxZcJjez9azZhzHVBktkeTSarml7IW1y1otR',
    JWT_SECRET_VAL: 'whimManagementApp',
    PORT: 3002,
    GUEST_TOKEN: 'eyJlbWFpbCI6InRlc3RAZ21haWwuY29tIiwiX2lkIjoiNWNmZTIwY2E3ZTc4ZTU2ZDA1OWYyNjkyIiwibmFtZSI6IlRlc3QiLCJpYXQiOjE1NjA4NTM5NDMsImV4cCI6MTU2MTQ1ODc0M30',
    'THUMBNAIL_IMAGE_SIZE': 300,
    'THUMBNAIL_IMAGE_QUALITY': 100,
    'PAYMENT_GATEWAY': {
        URL: 'https://test.oppwa.com',
        BASIC_PATH: '/v1/checkouts',

    }

    /*GOOGLE_API_KEY : '',
    COUNTRY_CODE : '+91',
    MAX_DISTANCE_RADIUS_TO_SEARCH : '1',
    THUMB_WIDTH : 300,
    THUMB_HEIGHT : 300,*/
    /*DOMAIN_NAME : 'http://localhost:8001/',*/
};

var DATABASE = {

    USER_ROLES: {
        USER: 'USER',
        PROFESSIONAL: 'PROFESSIONAL',
        FACILITY: 'FACILITY',
        TEAM: 'TEAM',
        TEAM_HIRE: 'TEAM_HIRED',
        TEAM_HIRE_BY: 'TEAM_HIRED_BY',
        PATIENT: 'PATIENT'
    },

    DEVICE_TYPES: {
        IOS: 'IOS',
        ANDROID: 'ANDROID'
    },

    LANGUAGE: {
        EN: 'EN',
        AR: 'AR'
    },
    APPOINTMENT: {
        HOME: "HOME",
        ONLINE: "ONLINE",
        ONSITE: "ONSITE",
        SELF: "SELF"
    },
    APPOINTMENT_HOME: {
        CUSTOM: "CUSTOM",
        WEEKLY: "WEEKLY",
        EVERYDAY: "EVERYDAY"
    },

    APPOINTMENT_STATUS: {
        PLACED: "PLACED",
        STARTED: "STARTED",
        REJECTED: "REJECTED",
        CONFIRMED: "CONFIRMED",
        CANCELLED: "CANCELLED",
        COMPLETED: "COMPLETED"
    },
    STATUS: {
        ACTIVE: "ACTIVE",
        BLOCKED: "BLOCKED",
        DELETED: "DELETED",
        INACTIVE: "INACTIVE"
    },
    CONSULT: {
        VIDEO: 1,
        IMAGE: 2,
        CHAT: 3
    },
    CONSULT_TYPES: {
        ONLINE: 1,
        OFFSITE: 2,
        HOME: 3
    },
    FOLDERS: {
        /*DOCUMENTS: "Documents",
        PHOTOS: "Photos",
        VIDEOS: "Videos",
        AUDIOS: "Audios",
        LINKS: "Links",
        MEDICATIONS: "Medications",
        REQUESTS: "Requests",
        REPORTS: "Reports",
        RADIOLOGY: "Radiology",
        LABS: "Labs"*/
        /*MEDICATIONS: process.env.ENABLE_DB_ENCRYPTION=="1" ? "ORkPD9cMNMP2aG5EshS77BsHm+yZXEC/UphzDuRSR9FXa3mrotpBWqywQUQxwDAU5JDUTdUlt3ixmTlfTDDUf5Mkap6aQtP8nYXvEs7E83zcZ/jOUvz8bMrx+LLlzpD/4DX+ilWx5tLAgqcP6zf89PUGvdWtiuRBL9YltjA/IMNx6zmS56QREgbSM/1QC4ym3M6haTw/+B+8OQlkWnx6H6jJDDUNrbrtApFc4KtOmLlg+MlxN/dnafDcCF8mj5BM/gJe26/oy0bp9HCXG9Qvr95uX1YvpFrgOS/jppp205Q2KLfXFlF+UFeCoa0idlVWjozrPPKG3kVfnSdESp2Cnw==" : "Medications",
        REQUESTS: process.env.ENABLE_DB_ENCRYPTION=="1" ? "U5+z3q914sXIkdQkH7BwXXkQamHZciWznj2xqx015PHIUsbklT4bp9c/WWSjnZok6y8RnUlogp9cmhnWv/yGZa+V99BK+8Je9FCtRgzaME4fTZAJ0qZm6G8ldR/gctJp8gsQSHH36zOz+mhCbMn0nt2qnemINB9BuZro57BUJ68UNIn/OJ5EJJvLvBpKY6tJew7e+/YlH+TOuFwke+Zt7AOaZb7hSdIo4/5ArVXWcs/PRm1Re7E2iocSk+A62Z5EcUXzGxudsm6hYSplVYSIkoc9rNqePYoHNkNwa4+ca6Sa6VuzxwkhSMH+C64OOBsGg1iIfF06UWBzBxnJDHd/ng==" : "Requests",
        REPORTS: process.env.ENABLE_DB_ENCRYPTION=="1" ? "PykXhrMNIGhiOu7cTL8xjLbWxMsUOS9STUIxWeIPZIHDtLzhnmoXZr6m3zdzJ+NVG21tXx7pUaP29+6w2Cloi4hRJliHluG91QXf8DAHxJXpyxB8rb7I3I/j9RZs2xNHWiI9ed45Xg5CkHhdwxLxNr7aVA3kJQwKzlJVTGY7eujZl1Yy/lnSUetMeFehhcYYWssii7MP2SkHso0s8Z1a3bVkz+D7EjNaqDkyJYUd9bGo3f06DfDeH/cFiMBrXXJDd7mr6jESDEXSmvQZTsICp+CdtpwZIQJGZ9T4SspX+ZFgJ7NteQP9iLvECzyEZw49TfJXurXgytE6AfAgnJJvkQ==" : "Reports",
        RADIOLOGY: process.env.ENABLE_DB_ENCRYPTION=="1" ? "cOtvA9zAoOVimdkCANZscXphWzjNRNwddY471MArI1VEI+gVQfSHJEoj24Zj5M8BGyVfepeRUqVNKJdmvrV89LGmvdUnrEazuBrg37XMlHoebTrDJN7ouh8U9wMWwe0m2Papaos40nRI8RjLr2xAdfRVH+s3a+Piwh9/RIku284MR+VUlKrjnT2ML95OmZ8D+kPD4gZvv7Nlkk0EfPzJau9mo16F9lAn8/K1tV8JmkX+rffkOZBX0jmRgOaBxfIzdc8bXOh9g89n9Cav81mA2UzACMYnVj/zoc9XtiwwGWlJzXdaY7FMLshKuux2vx6NeVccUsK1IAFWN01BXDNndA==" : "Radiology",
        LABS: process.env.ENABLE_DB_ENCRYPTION=="1" ? "H4N5gFUpcCkgUP2muDcBnxlAcga1LVBZ37gwPfMupselq3Cm/G9q17+Ysctr0GeivsWD0s79gIusiPCOEvdsTDdwookPBwF6wISXrIe+CxOTRSkIg+kADzkbWcG3lCB2Mtx1SnXgqHKpDAnUolDKB23/cAFwqZfncKQZqx42S8c/zFi8CbR3xYtJQ3iqpPmPaHhOZxfg/EjxQkaZORKQwOGa0PSIYxlDqNhE73LU6Mjk8SlGp0KdeOmxmIB42JaZQPzNUzgaiy5lEYUlzr3tukHVEDMeKiTF8SbArzRbnG+c+L1P2zZMs9+oKi886jqyYIqkZi8knuZKafBD3Qh1aA==" : "Labs"*/
        DOCUMENTS: {
            "en": "Documents",
            "ar": "مستندات"
        },
        PHOTOS: {
            "en": "Photos",
            "ar": "الصور"
        },
        VIDEOS: {
            "en": "Videos",
            "ar": "مقاطع فيديو"
        },
        AUDIOS: {
            "en": "Audios",
            "ar": "صوتيات"
        },
        LINKS: {
            "en": "Links",
            "ar": "الروابط"
        },
        MEDICATIONS: {
            "en": "Medications",
            "ar": "الأدوية"
        },
        REQUESTS: {
            "en": "Requests",
            "ar": "طلبات"
        },
        REPORTS: {
            "en": "Reports",
            "ar": "تقارير"
        },
        RADIOLOGY: {
            "en": "Radiology",
            "ar": "طب إشعاعي"
        },
        LABS: {
            "en": "Labs",
            "ar": "مختبرات"
        }
    },
    MINUTE_SLOTS: {
        FULL_DAY: [0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330, 360, 390, 420, 450, 480, 510, 540, 570, 600, 630, 660, 690, 720, 750, 780, 810, 840, 870, 900, 930, 960, 990, 1020, 1050, 1080, 1110, 1140, 1170, 1200, 1230, 1260, 1290, 1320, 1350, 1380, 1410]
        /*FULL_DAY: '["0","30","60","90","120","150","180","210","240","270","05:00 AM","05:30 AM","06:00 AM","06:30 AM","07:00 AM","07:30 AM","08:00 AM","08:30 AM","09:00 AM","09:30 AM","10:00 AM","10:30 AM","11:00 AM","11:30 AM","12:00 PM","12:30 PM","1:00 PM","1:30 PM","02:00 PM","02:30 PM","03:00 PM","03:30 PM","04:00 PM","04:30 PM","05:00 PM","05:30 PM","06:00 PM","06:30 PM","07:00 PM","07:30 PM","08:00 PM","08:30 PM","09:00 PM","09:30 PM","10:00 PM","10:30 PM","11:00 PM","11:30 PM"]'*/
    },
    COMMON_SERVICE_TYPE: {
        'Diagnosis': 'diagnosis',
        'Labs': 'lab',
        'Radiology': 'radiology',
        'Special_Test': 'Special_Test',
        'CSFCONTRACT': 'CSF_CONTRACT'
    },
    REPORTS_STEPWISE: {
        "E_REPORT": 1,
        "TEST_REQ": 2,
        "E_PRESCRIPTION": 3,
        "FOLLOW_UP_APPOINTMENT": 4,
        "PROFESSIONAL_FACILTY": 5,
        "SKIP": 6,
        "VALIDATE": 7
    },
    MESSAGE_TYPE: {
        TEXT: 'TEXT',
        IMAGE: 'IMAGE',
        VIDEO: 'VIDEO',
        GROUP_CHAT: 'GROUP_CHAT',
        SINGLE_CHAT: 'SINGLE_CHAT',
        CALL: 'CALL',
        VIDEO_CALL: 'VIDEO_CALL',
        DOCUMENT: 'DOCUMENT',
        LOCATION: 'LOCATION',
        CONTACT: 'CONTACT',
        GROUP_NOTIFICATION: 'GROUP_NOTIFICATION'
    },
    MESSAGE_STATUS: {
        RECEIVED: 'RECEIVED',
        DELIVERED: 'DELIVERED',
        READ: 'READ'
    },
    DEFAULT_IMAGE: {
        original: "https://www.femina.in/images/default-user.png",
        thumbnail: "https://www.femina.in/images/default-user.png",
        mediaType: "IMAGE"
    },
    CHAT_TYPE: {
        ONE_TO_ONE_CHAT: 'ONE_TO_ONE_CHAT',
        GROUP_CHAT: 'GROUP_CHAT'
    },
    FOLLOW_UP_APPOINTMENT: {
        'FREE': 1,
        'PAID': 2
    },
    REPORT_TYPE: {
        "RECEIVED": 1,
        "SCANED": 2
    }
    /*
        PROFILE_SETUP_STEPS:{
            FIRST : 'FIRST',
            SECOND : 'SECOND',
        },
    
        BLOCK_TYPE:{
            BLOCK:'BLOCK',
            UNBLOCK:'UNBLOCK'
        },
        FILE_TYPES: {
            LOGO: 'LOGO',
            DOCUMENT: 'DOCUMENT',
            OTHERS: 'OTHERS'
        },
    
        MEETUP_CATEGORY:{
            SPORTING_EVENT : 'SPORTING_EVENT',
            PARTY : 'PARTY',
            CONCERT : 'CONCERT',
            CULINERY_EVENT : 'CULINERY_EVENT',
            OTHERS : 'OTHERS'
        },
    
        REPORT_REASON:{
            ABUSIVE : 'ABUSIVE',
            INAPPROPRIATE : 'INAPPROPRIATE',
            SEXUALLY_EXPLICIT : 'SEXUALLY_EXPLICIT',
            OTHERS : 'OTHERS'
        },*/

    /*FRIEND_REQUEST_ACTION : {
        PENDING : 'PENDING',
        CONFIRM : 'CONFIRM',
        DECLINE:'DECLINE',
        REMOVED:'REMOVED',
    },

    ACTIVITY_REQUEST_STATUS : {
        DOWN : 'DOWN',
        MAY_BE : 'MAY_BE',
        NOT_FREE:'NOT_FREE',
        PENDING:'PENDING',
        CANT_GO_ANYMORE:'CANT_GO_ANYMORE',
    },
    ACTIVITY_TYPE : {
        CUSTOM : 'CUSTOM',
        PREDEFINED : 'PREDEFINED',

    },
    LIKE_UNLIKE : {
        LIKE : 'LIKE',
        UNLIKE : 'UNLIKE',
    },
    VOTE_UNVOTE : {
        VOTE : 'VOTE',
        UNVOTE : 'UNVOTE',
    },
    BLOCK_BY_ADMIN : {
        BLOCK : 'BLOCK',
        UNBLOCK : 'UNBLOCK',
    },
    ACTIVITY_STATUS : {
        ALL : 'ALL',
        ACTIVE : 'ACTIVE',
        INACTIVE : 'INACTIVE'
    },
    ADD_OR_REMOVE_MEMBER : {
        ADD : 'ADD',
        REMOVE : 'REMOVE',

    },
    IS_OPEN: {
        TRUE: 'true',
        FALSE: 'false'
    },

    PROFILE_PIC_PREFIX : {
        ORIGINAL : 'profilePic_',
        THUMB : 'profileThumb_'
    },

    LOGO_PREFIX : {
        ORIGINAL : 'logo_',
        THUMB : 'logoThumb_'
    },

    CHAT_TYPE : {
        DIRECT :'DIRECT',
        GROUP :'GROUP',
        ACTIVITY:'ACTIVITY',
    },


    PAYMENT_OPTIONS : {
        CREDIT_DEBIT_CARD : 'CREDIT_DEBIT_CARD',
        PAYPAL : 'PAYPAL',
        BITCOIN : 'BITCOIN',
        GOOGLE_WALLET : 'GOOGLE_WALLET',
        APPLE_PAY : 'APPLE_PAY',
        EIYA_CASH : 'EIYA_CASH'
    },


    USER_TYPE : {
        NEW_USER       :  'NEW_USER',
        RETAINED_USER  :  'RETAINED_USER',
        CHURNED_USER   :  'CHURNED_USER',
        RESURRECTED_USER :'RESURRECTED_USER'
    },
    RETENTION_TYPE : {
     ALL:"ALL",
     DAILY:"DAILY",
     MONTHLY:"MONTHLY",
     WEEKLY:"WEEKLY",
    }*/
};


var APP_CONSTANTS = {
    SERVER: SERVER,
    DATABASE: DATABASE,
    STATUSCODE: STATUSCODE
};

module.exports = APP_CONSTANTS;

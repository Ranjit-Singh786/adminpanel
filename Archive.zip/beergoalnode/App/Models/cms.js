import mongoose from 'mongoose';
// let async = require('async'),
// randomstring = require("randomstring"),
// user_plugin = require("../plugins").userPlugin;         // import mongo plugin for pre save hook

let Schema = mongoose.Schema;

const CmsSchema = new Schema(
  {
    title: { type: String, default: "" },
    content: { type: String, default: "" },
  },
  { timestamps: true }
);
//0-off  , 1-on
const CmsModal = mongoose.model('cms', CmsSchema);
CmsModal.syncIndexes();
export default CmsModal;

import { useState, useEffect } from "react";
import { DataGrid } from "@mui/x-data-grid";
import { sportColumns } from "../../datatablesource";
import { Link } from "react-router-dom";
import ApiClass from "../../api/api.js";

const SportDatatable = () => {
  const [data, setData] = useState([]);

  const handleDelete = (id) => {
    setData(data.filter((item) => item.id !== id));
  };

  const fetchData = async () => {
    try {
      const response = await ApiClass.getNodeRequest("get_sports", false);
      const updatedData = response.data.body.map((item) => ({
        id: item._id,
        ...item,
      }));
      setData(updatedData);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const actionColumn = [
    {
      field: "action",
      headerName: "Action",
      width: 200,
      renderCell: (params) => {
        const sportID = params.row.id;
        return (
          <div className="cellAction">
            {/* Add team-specific actions here */}
            <Link to={`/sports/${sportID}`} style={{ textDecoration: "none" }}>
              <div className="viewButton">View</div>
            </Link>
            <div
              className="deleteButton"
              onClick={() => handleDelete(params.row.id)}
            >
              Delete
            </div>
          </div>
        );
      },
    },
  ];

  return (
    <div className="datatable">
       <div className="datatableTitle">
        Add New Sports
        <Link to="/sports/new" className="link">
          Add New
        </Link>
      </div>
      <DataGrid
        className="datagrid"
        rows={data}
        columns={sportColumns.concat(actionColumn)}
        pageSize={9}
        rowsPerPageOptions={[9]}
        checkboxSelection
      />
    </div>
  );
};

export default SportDatatable;

const mongoose = require('mongoose')

const ReportUserSchema = new mongoose.Schema({
    user_id:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'user'
    },
    group_id:{
        type:String
    },
    report_by:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'user'
    }
},{
    timestamps:true
})

module.exports = mongoose.model('report_users',ReportUserSchema)
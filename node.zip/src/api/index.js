const router = require('express').Router()

router.use('/', require('./api').Routes)

module.exports = {
    routes:[router],
}
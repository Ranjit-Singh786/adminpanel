/**
 * Makes all features available to outer modules.
 */

const express = require('express')
const router = express.Router();

router.use('/', require('./admin').Routes);
router.use('/', require('./users').Routes);
router.use('/', require('./pages').Routes);
router.use('/', require('./group').Routes);





module.exports = {
    routes: [router],
    swagger: [{
        ...require('./admin').swagger.paths,
        ...require('./users').swagger.paths,
        ...require('./pages').swagger.paths,
        ...require('./group').swagger.paths,
    
    }],



    swaggerSchemas: [{
        ...require('./admin').swagger.schemas,
        ...require('./users').swagger.schemas,
        ...require('./pages').swagger.schemas,
        ...require('./group').swagger.schemas,

    }]
};

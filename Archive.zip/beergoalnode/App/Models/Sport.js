import mongoose from 'mongoose';
// let async = require('async'),
// randomstring = require("randomstring"),
// user_plugin = require("../plugins").userPlugin;         // import mongo plugin for pre save hook

let Schema = mongoose.Schema;

const SportSchema = new Schema(
  {
    sportname: { type: String, index: true, default: "" },
    logo: { type: String, default: "" },
  },
  { timestamps: true }
);
//0-off  , 1-on
const SportModal = mongoose.model('Sports', SportSchema);
SportModal.syncIndexes();
export default SportModal;

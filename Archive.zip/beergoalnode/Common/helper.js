// import { v4 as uuid } from 'uuid';
// import path from 'path';
// import FCM from 'fcm-node';
// // import apn from 'apn';
// const serverKey = "AAAAj-DdARA:APA91bHL0_59UNpuaq7_Zoxd3mzbywD_3Wa3d27bEZWUNTS8vlyZYcgHa0hl-UlEuqOmN2_VjQXuBW9aXE__vs4JH53cRquMKdngHDnyygYINf5-Z6RVKJCOJoPhNI9Z_W__-AZTk7xH";
// const fcm = new FCM(serverKey);

export default {
  success: (res, message = "", body = {}) => {
    return res.status(200).json({
      success: true,
      code: 200,
      message: message,
      body: body,
    });
  },

  error: (res, err, req) => {
    // console.log(err, "===========================>error");
    let code = typeof err === "object" ? (err.code ? err.code : 403) : 403;
    let message =
      typeof err === "object" ? (err.message ? err.message : "") : err;

    if (req) {
      req.flash("flashMessage", {
        color: "error",
        message,
      });

      const originalUrl = req.originalUrl.split("/")[1];
      return res.redirect(`/${originalUrl}`);
    }

    return res.status(code).json({
      success: false,
      message: message,
      code: code,
      body: {},
    });
  },

  failed: (res, message = "") => {
    // console.log(message, "----------------failed");
    message =
      typeof message === "object"
        ? message.message
          ? message.message
          : ""
        : message;
    return res.status(400).json({
      success: false,
      code: 400,
      message: message,
      body: {},
    });
  },

  unixTimestamp: () => {
    var time = Date.now();
    var n = time / 1000;
    return (time = Math.floor(n));
  },

  checkValidation: async (v) => {
    var errorsResponse;

    await v.check().then(function (matched) {
      if (!matched) {
        var valdErrors = v.errors;
        var respErrors = [];
        Object.keys(valdErrors).forEach(function (key) {
          if (valdErrors && valdErrors[key] && valdErrors[key].message) {
            respErrors.push(valdErrors[key].message);
          }
        });
        // errorsResponse = respErrors.join(", ");
        errorsResponse = respErrors.length > 0 ? respErrors[0] : "";
      }
    });
    return errorsResponse;
  },

  file_uploads: (file, folder) => {
    try {
      if (file.name == "") return;

      let file_name_string = file.name;

      console.log(file_name_string);

      var file_name_array = file_name_string.split(".");

      var file_extension = file_name_array[file_name_array.length - 1];

      var letters = "ABCDE1234567890FGHJK1234567890MNPQRSTUXY";
      var result = "";

      result = uuid();

      let name = result + "." + file_extension;

      // console.log(name);return false;
      file.mv("public/" + folder + "/" + name, function (err) {
        if (err) throw err;
      });
      return name;
    } catch (error) {
      console.log(error);
    }
  },
  image_upload: async (file) => {
    try {
      let imageName = file?.name;
      let img = file;
      img?.mv(`public/uploads/user/${imageName}`, (err) => {
        if (err) {
          console.log(err);
          // return res.status(500).send(err);
        }
      });
      console.log(imageName, "---img------");
      return imageName;
    } catch (error) {
      console.log(error, ">>>>>>>>>>>>>>>>");
    }
  },

  sendNotification: (token, notificationmessage) => {
    var message = {
      to: token,
      notification: {
        title: "HuffDuff",
        body: notificationmessage,
      },
      data: {
        title: "HuffDuff",
        body: notificationmessage,
      },
    };
    console.log(message, 'check message');
    fcm.send(message, function (err, response) {
      if (err) {
        console.log("Something has gone wrong!");
      } else {
        console.log("Successfully sent with response: ", response);
      }
    });
  },
  sendGroupNotification: (tokenarr, notificationmessage) => {
    var message = {
      to: tokenarr,
      collapse_key: "huffduff2023",
      notification: {
        title: "HuffDuff",
        body: notificationmessage,
      },
    };

    fcm.send(message, function (err, response) {
      if (err) {
        console.log("Something has gone wrong!");
      } else {
        console.log("Successfully sent with response: ", response);
      }
    });
  },

  async sendPushNotificationToMultipleDevicesIos(token, data) {
    var note = new apn.Notification();
    note.expiry = Math.floor(Date.now() / 1000) + 3600;
    note.sound = "default";
    note.alert = data.message;
    note.title = data.title;
    note.payload = data;
    note.topic = "com.huffduffA";
    apnProvider.send(note, token).then((result) => {
      console.log(result, "---------------result----------------------");
    });
  },
};

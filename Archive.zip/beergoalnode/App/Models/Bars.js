import mongoose from 'mongoose';
// let async = require('async'),
// randomstring = require("randomstring"),
// user_plugin = require("../plugins").userPlugin;         // import mongo plugin for pre save hook

let Schema = mongoose.Schema;

const BarsSchema = new Schema(
  {
    barname: { type: String, index: true, default: "" },
    phone: { type: String, default: "", index: true },
    email: { type: String, index: true, default: "" },
    country: { type: String, default: "" },
    location: {
      type: { type: String },
      coordinates: [],
      //index: "2dsphere",
      //sparse: true,
    }, //[long, lat]
    address: { type: String, default: "" },
    image: {
      original: { type: String, default: "" },
      thumbnail: { type: String, default: "" },
    },
    barDetail: {    
        type: mongoose.Schema.Types.ObjectId,
        ref: 'baroffers', // Replace 'Sport' with the actual name of your sports model
        required: false
      },
  },
  { timestamps: true }
);
//0-off  , 1-on
const BarModal = mongoose.model('Bars', BarsSchema);
BarModal.syncIndexes();
export default BarModal;

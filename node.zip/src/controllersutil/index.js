/**
 * Makes all features of admin available to outer modules.
 */

module.exports = {
    appointmentUtil: require('./appointmentUtil')
};
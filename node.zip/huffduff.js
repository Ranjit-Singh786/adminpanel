require('./env-validation');
var createError = require('http-errors');
var express = require('express');
const cors = require('cors');
var app = express();
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
const server = require('http').Server(app);
var io = require('socket.io')(server);
const passport = require('passport');
const mongoose = require('mongoose');
// const socket = require("./src/api/api/socket")
const swaggerUi = require('swagger-ui-express');
const swaggerDocumentUser = require('./config/swagger.json');
var Constants = require('./config/appConstants');
const multipart = require('connect-multiparty');
let file_upload = require('express-fileupload')
// const multipartMiddleware =   multipart();
const bodyParser = require('body-parser');

global.ObjectId = mongoose.Types.ObjectId;

var mongoURI = require('./config/dbConfig').mongo;


// require all routes and de structure the array
const [user_api, admin_api, common_api] = require('./src').routes;
const [api_router] = require('./src/api').routes
// console.log("user_api", user_api)
const [userSwagger, adminSwagger, commonSwagger] = require('./src').swagger;
// console.log(userSwagger," ============== ", common_api," ===================== ", commonSwagger)
const [userSwaggerSchemas, adminSwaggerSchemas, commonSwaggerSchemas] = require('./src').swaggerSchemas;
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.get('/privacy', (req, res) => {
    res.sendFile(__dirname + '/index.html');
  });
app.get('/terms', (req, res) => {
    res.sendFile(__dirname + '/terms.html');
  });
  app.get('/cookies', (req, res) => {
    res.sendFile(__dirname + '/cookies.html');
  });

app.set(Constants.SERVER.JWT_SECRET_KEY, Constants.SERVER.JWT_SECRET_VAL);


app.use(passport.initialize());
app.use(cors());
app.use(logger('dev'));
app.use(express.json());
// app.use(file_upload())   // support parsing of application/json type post data
app.use(express.urlencoded({ extended: false })); //support parsing of application/x-www-form-urlencoded post data
app.use(cookieParser());
// app.use(multipart());
app.use(file_upload({
    useTempFiles : true,
    tempFileDir : '/tmp/'
}));


app.use('/node_modules_url', express.static(path.join(__dirname, 'node_modules')));
app.use('/', express.static(path.join(__dirname, 'admin-login')));

app.use(express.static(path.join(__dirname, 'public')));

// app.use(file_upload()) 

// assign path and schema in swagger file
swaggerDocumentUser.paths = { ...swaggerDocumentUser.paths, ...userSwagger, ...adminSwagger, ...commonSwagger };
swaggerDocumentUser.components.schemas = { ...swaggerDocumentUser.components.schemas, ...userSwaggerSchemas, ...adminSwaggerSchemas, ...commonSwaggerSchemas };

mongoose.Promise = global.Promise;

mongoose.connect(mongoURI, { useNewUrlParser: true, useFindAndModify: false, useCreateIndex: true, useUnifiedTopology: true });
mongoose.connection.on('error', function (err) {
    console.log(err);
    console.log('error in connecting, process is exiting ...');
    process.exit();
});

mongoose.connection.once('open', function () {
    console.log(`Successfully connected to ${process.env.NODE_ENV} database`);
});

mongoose.set('debug', true);

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocumentUser));
app.use('/api', user_api);
// console.log("admin_api ========== ",user_api)
app.use('/admin', admin_api);
app.use('/common', common_api);
app.use('/api',api_router)
// app.use('/auth-api', auth_api);

// console.log("1111111111111111 ", typeof admin_api)
app.use(function (err, req, res, next) {
    console.log("errr----");
    let status = 500, json = {
        status: 0,
        message: err.message.en || err.message
    };
    if (err.isBoom) {
        //json = err.output.payload;
        json = { status: 0, message: err.data[0].message }
        status = err.output.statusCode;
    }
    return res.status(status).json(json);
});

// socket.startSocketServer(io);
require("./src/api/api/socket")(io);

app.options('/*', cors()) // enable pre-flight request for DELETE request

// SocketManager.connectSocket(server,redisClient);
server.listen(process.env.PORT, function () {
    console.log('Node app is running on port', process.env.PORT);
});
module.exports = app;

import express from 'express';
import UserController from '../App/Controllers/AdminController.js'
import auth from '../Middleware/auth.js';

const router = express.Router();
// Define user routes
router.post('/login', UserController.login);
router.get('/get_profile',auth.authenticateToken, UserController.get_profile);
router.put('/edit_profile',auth.authenticateToken, UserController.edit_profile);
router.put('/change_password',auth.authenticateToken, UserController.change_password);
router.get('/get_users', UserController.get_users);
router.get('/get_bars', UserController.get_bars);
router.post('/create_team', UserController.create_team);
router.get('/get_teams', UserController.get_teams);
router.delete('/delete_team/:id', UserController.delete_team);
router.put('/update_team/:id', UserController.update_team);
router.post('/create_sport', UserController.create_sports);
router.get('/get_sports', UserController.get_sports);
router.put('/update_sports/:id', UserController.update_sports);
router.delete('/delete_sports/:id', UserController.delete_sports);
router.post('/bar_offers', UserController.bar_offers);
router.get('/getbars_with_offers', UserController.getbars_with_offers);
router.get('/total_count', UserController.total_count);
router.get('/get_cms', UserController.cms);
router.post('/update_cms/:id', UserController.update_cms);
router.post('/delete_cms/:id', UserController.delete_cms);



export default router;
